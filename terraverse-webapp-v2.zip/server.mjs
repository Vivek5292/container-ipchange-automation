// Production server for Terraverse 2.0: serves the static Vite build (dist/) with zero dependencies.
//
// - Listens on process.env.PORT (set by Azure App Service), falling back to WEBSITES_PORT. If neither is set it asks
//   the OS for a free port (PORT=0 semantics) and logs it. No port number is hard-coded anywhere.
// - On App Service, TLS ends at the front end on 443 and requests reach this process as plain HTTP on that port.
// - The app uses hash routing (#/p/<id>), so every page is "/"; unknown non-asset paths still fall back to index.html.
// - Adds security headers (CSP, HSTS, nosniff, frame-ancestors, ...), long-lived caching for hashed assets,
//   no-cache + ETag for index.html, and pre-compressed gzip/brotli for text files.
// - API: GET /api/ado/config and POST /api/ado/pr (Azure DevOps pull request from the generated .tf files). The logic lives
//   in server/ado.ts (Node 22.18+/24 runs it directly). Credentials come per request or from app settings
//   ADO_TENANT_ID / ADO_CLIENT_ID / ADO_CLIENT_SECRET (Key Vault references work: App Service resolves them into env).
//   The client secret is used for one token request and is never stored, logged or sent back.
import { createServer } from 'node:http';
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { brotliCompressSync, gzipSync, constants as zc } from 'node:zlib';
import { extname, join, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createPullRequest, credentialsFromEnv, endpointsFromEnv, validatePrRequest } from './server/ado.ts';

const here = fileURLToPath(new URL('.', import.meta.url));
const ROOT = resolve(process.env.STATIC_DIR ?? join(here, 'dist'));

const TYPES = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.ico': 'image/x-icon',
  '.woff2': 'font/woff2', '.woff': 'font/woff', '.txt': 'text/plain; charset=utf-8', '.map': 'application/json; charset=utf-8',
};
const COMPRESSIBLE = new Set(['.html', '.js', '.mjs', '.css', '.json', '.svg', '.txt', '.map']);

export const SECURITY_HEADERS = {
  'Content-Security-Policy': [
    "default-src 'self'",
    "script-src 'self'",
    "style-src 'self' 'unsafe-inline'", // React / React Flow set inline style attributes
    "img-src 'self' data: blob:", // inlined SVG icons, image export
    "font-src 'self' data:",
    "connect-src 'self' data: blob:", // diagram export fetches its own data: URL
    "worker-src 'self' blob:",
    "object-src 'none'",
    "base-uri 'self'",
    "form-action 'self'",
    "frame-ancestors 'none'",
  ].join('; '),
  'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'no-referrer',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=(), usb=()',
  'Cross-Origin-Opener-Policy': 'same-origin',
};

/** Read the whole build into memory once (about 2 MB): fast, and nothing on disk is touched per request. */
function loadFiles(root) {
  const files = new Map();
  const walk = (dir) => {
    for (const name of readdirSync(dir)) {
      const full = join(dir, name);
      if (statSync(full).isDirectory()) { walk(full); continue; }
      const ext = extname(name).toLowerCase();
      const body = readFileSync(full);
      const url = '/' + full.slice(root.length + 1).split(sep).join('/');
      const zip = COMPRESSIBLE.has(ext) && body.length > 1024;
      files.set(url, {
        body, type: TYPES[ext] ?? 'application/octet-stream',
        etag: `"${createHash('sha1').update(body).digest('base64url')}"`,
        gzip: zip ? gzipSync(body, { level: 9 }) : null,
        br: zip ? brotliCompressSync(body, { params: { [zc.BROTLI_PARAM_QUALITY]: 11 } }) : null,
        immutable: url.startsWith('/assets/'), // Vite content-hashes everything under assets/
      });
    }
  };
  try { walk(root); } catch { /* no build yet */ }
  return files;
}

const MAX_BODY = 3_000_000;
const json = (res, status, obj) => {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }).end(JSON.stringify(obj));
};

/** POST /api/ado/pr and GET /api/ado/config. Never logs request bodies; the secret only lives in this function's scope. */
async function handleApi(req, res, path, { env, fetchImpl, log }) {
  const serverCreds = credentialsFromEnv(env);
  if (path === '/api/ado/config' && req.method === 'GET') return json(res, 200, { serverCredentials: !!serverCreds });
  if (path !== '/api/ado/pr') return json(res, 404, { error: 'Not found' });
  // HTTPS only: behind App Service the front end sets X-Forwarded-Proto; plain-HTTP requests never carry a secret here
  if (String(req.headers['x-forwarded-proto'] ?? '').split(',')[0].trim() === 'http') return json(res, 403, { error: 'HTTPS is required' });
  if (req.method !== 'POST') { res.setHeader('Allow', 'POST'); return json(res, 405, { error: 'Use POST' }); }
  // same-origin JSON only (a cross-site form post can't send application/json without a CORS preflight, which we never grant)
  if (!String(req.headers['content-type'] ?? '').startsWith('application/json')) return json(res, 415, { error: 'Send application/json' });
  const origin = req.headers.origin;
  if (origin && new URL(origin).host !== req.headers.host) return json(res, 403, { error: 'Cross-origin requests are not allowed' });
  let size = 0;
  const chunks = [];
  for await (const c of req) {
    size += c.length;
    if (size > MAX_BODY) return json(res, 413, { error: 'Request too large' });
    chunks.push(c);
  }
  let body;
  try { body = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { return json(res, 400, { error: 'Invalid JSON' }); }
  if (!body || typeof body !== 'object') return json(res, 400, { error: 'Invalid request' });
  const { tenantId, clientId, clientSecret, ...prReq } = body;
  const creds = serverCreds ?? { tenantId: String(tenantId ?? ''), clientId: String(clientId ?? ''), clientSecret: String(clientSecret ?? '') };
  const fields = validatePrRequest(prReq, creds);
  if (Object.keys(fields).length) return json(res, 400, { ok: false, stage: 'validate', error: 'Some fields need attention', fields });
  let endpoints;
  try { endpoints = endpointsFromEnv(env); } catch (e) { log(`ado pr: bad endpoint config (${e.message})`); return json(res, 500, { ok: false, error: 'Server misconfigured' }); }
  try {
    const r = await createPullRequest(prReq, creds, { fetch: fetchImpl, endpoints });
    if (r.ok) { log(`ado pr: opened #${r.pullRequestId}`); return json(res, 201, r); }
    log(`ado pr: failed at ${r.stage} (HTTP ${r.status})`);
    return json(res, r.stage === 'validate' ? 400 : 502, { ...r, adoStatus: r.status });
  } catch (e) {
    log(`ado pr: network error (${e?.name ?? 'Error'})`);
    return json(res, 502, { ok: false, stage: 'network', error: 'Could not reach Azure DevOps or Microsoft Entra ID from the server' });
  }
}

/**
 * @param {string} [root] build folder (dist/)
 * @param {{ env?: Record<string, string | undefined>, fetch?: typeof fetch, log?: (line: string) => void, apiOnly?: boolean }} [opts]
 */
export function createApp(root = ROOT, opts = {}) {
  const files = opts.apiOnly ? new Map() : loadFiles(root);
  const api = { env: opts.env ?? process.env, fetchImpl: opts.fetch ?? globalThis.fetch, log: opts.log ?? ((l) => console.log(l)) };
  if (!files.has('/index.html') && !opts.apiOnly) api.log(`No build found in ${root}: serving the API only (run "npm run build" for the app)`);
  return createServer((req, res) => {
    for (const [k, v] of Object.entries(SECURITY_HEADERS)) res.setHeader(k, v);
    const path = (() => { try { return decodeURIComponent(new URL(req.url ?? '/', 'http://x').pathname); } catch { return null; } })();
    if (path === null || path.includes('\0')) { res.writeHead(400).end('Bad request'); return; }
    if (path === '/healthz') { res.writeHead(200, { 'Content-Type': 'text/plain', 'Cache-Control': 'no-store' }).end('ok'); return; }
    if (path.startsWith('/api/')) { handleApi(req, res, path, api).catch(() => { if (!res.headersSent) json(res, 500, { ok: false, error: 'Internal error' }); }); return; }
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405, { Allow: 'GET, HEAD' }).end(); return; }
    // Files come only from the in-memory map, so "../" cannot escape the build folder.
    let f = files.get(path === '/' ? '/index.html' : path);
    if (!f && !files.has('/index.html')) { res.writeHead(503, { 'Content-Type': 'text/plain' }).end('No build: run "npm run build"'); return; }
    if (!f) {
      // SPA fallback for page-like paths; a missing asset is a real 404 (so a stale chunk fails loudly).
      if (path.startsWith('/assets/') || extname(path)) { res.writeHead(404, { 'Content-Type': 'text/plain' }).end('Not found'); return; }
      f = files.get('/index.html');
    }
    const headers = {
      'Content-Type': f.type,
      'Cache-Control': f.immutable ? 'public, max-age=31536000, immutable' : 'no-cache',
      ETag: f.etag,
      Vary: 'Accept-Encoding',
    };
    if (req.headers['if-none-match'] === f.etag) { res.writeHead(304, headers).end(); return; }
    const accept = String(req.headers['accept-encoding'] ?? '');
    let body = f.body;
    if (f.br && /\bbr\b/.test(accept)) { body = f.br; headers['Content-Encoding'] = 'br'; }
    else if (f.gzip && /\bgzip\b/.test(accept)) { body = f.gzip; headers['Content-Encoding'] = 'gzip'; }
    headers['Content-Length'] = body.length;
    res.writeHead(200, headers);
    res.end(req.method === 'HEAD' ? undefined : body);
  });
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const port = Number(process.env.PORT || process.env.WEBSITES_PORT || 0);
  const apiOnly = process.argv.includes('--api-only');
  const server = createApp(ROOT, { apiOnly });
  server.listen(port, () => {
    const addr = server.address();
    console.log(`Terraverse 2.0 ${apiOnly ? 'API (/api only)' : `serving ${ROOT}`} on port ${typeof addr === 'object' && addr ? addr.port : port}`);
  });
  const stop = () => server.close(() => process.exit(0));
  process.on('SIGTERM', stop);
  process.on('SIGINT', stop);
}

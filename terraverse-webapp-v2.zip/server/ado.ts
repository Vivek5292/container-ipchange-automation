/**
 * Azure DevOps pull-request flow, server-side only (never bundled into the browser app).
 *
 * createPullRequest(): client-credentials token from Microsoft Entra ID → resolve repo → read the target branch →
 * push the generated files to a new branch in one commit → open a PR. Every HTTP call goes through the injected
 * `fetch`, so tests drive it against a mocked ADO/Entra API. The client secret is used for the token request only:
 * it is never stored, logged, or echoed back (any occurrence in upstream error text is redacted).
 *
 * Plain erasable TypeScript, so Node 22.18+/24 runs it directly (type stripping) from server.mjs.
 */

export type FetchLike = (url: string, init?: { method?: string; headers?: Record<string, string>; body?: string }) => Promise<{
  ok: boolean; status: number; text(): Promise<string>;
}>;

export interface AdoEndpoints {
  /** Entra ID authority, default https://login.microsoftonline.com */
  loginBase: string;
  /** Azure DevOps services, default https://dev.azure.com */
  adoBase: string;
}

export const DEFAULT_ENDPOINTS: AdoEndpoints = { loginBase: 'https://login.microsoftonline.com', adoBase: 'https://dev.azure.com' };
/** Azure DevOps first-party resource id: the scope for service-principal tokens. */
export const ADO_SCOPE = '499b84ac-1321-427f-aa17-267ca6975798/.default';
export const API_VERSION = '7.1';

export interface Credentials { tenantId: string; clientId: string; clientSecret: string }

export interface PrRequest {
  organization: string;
  project: string;
  repository: string;
  targetBranch: string;
  newBranch: string;
  title: string;
  description?: string;
  /** folder inside the repo for the files ('' = repo root) */
  folder?: string;
  /** relative path → file content */
  files: Record<string, string>;
}

export type PrResult =
  | { ok: true; pullRequestId: number; url: string; branch: string }
  | { ok: false; status: number; stage: 'validate' | 'token' | 'repository' | 'branch' | 'push' | 'pullrequest'; error: string; fields?: Record<string, string> };

const GUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const NAME = /^[\w.-][\w .-]{0,63}$/; // org / project / repo names
const ORG = /^[A-Za-z0-9][A-Za-z0-9-]{0,48}[A-Za-z0-9]?$/;
/** A safe subset of git ref names: segments of [A-Za-z0-9._-], separated by '/', no '..', no leading '-' or trailing '.lock'. */
export function validBranch(b: string): boolean {
  if (!b || b.length > 200 || b.includes('..') || b.endsWith('/') || b.startsWith('/') || b.endsWith('.lock')) return false;
  return b.split('/').every((seg) => /^[A-Za-z0-9_][A-Za-z0-9._-]*$/.test(seg));
}
/** relative path; dot-files (.gitignore) are fine, "." and ".." segments are not */
const FILE = /^(?!\.\.?(?:\/|$))[\w.-]+(?:\/(?!\.\.?(?:\/|$))[\w.-]+)*$/;
const MAX_FILES = 200;
const MAX_BYTES = 2_000_000;

/** Required-field and format checks. Returns field → message (empty when valid). */
export function validatePrRequest(r: Partial<PrRequest>, creds: Partial<Credentials> | null): Record<string, string> {
  const e: Record<string, string> = {};
  const s = (v: unknown) => (typeof v === 'string' ? v.trim() : '');
  if (!ORG.test(s(r.organization))) e.organization = 'Organization is required (letters, digits and dashes)';
  if (!NAME.test(s(r.project))) e.project = 'Project name is required';
  if (!NAME.test(s(r.repository))) e.repository = 'Repository name is required';
  if (!validBranch(s(r.targetBranch))) e.targetBranch = 'Target branch is required, e.g. main';
  if (!validBranch(s(r.newBranch))) e.newBranch = 'New branch name is required, e.g. terraverse/update';
  else if (s(r.newBranch) === s(r.targetBranch)) e.newBranch = 'New branch must differ from the target branch';
  if (!s(r.title) || s(r.title).length > 400) e.title = 'PR title is required';
  if (r.folder && !(r.folder === '' || FILE.test(r.folder.replace(/^\/+|\/+$/g, '')))) e.folder = 'Folder must be a relative path';
  const files = r.files && typeof r.files === 'object' ? Object.entries(r.files) : [];
  if (!files.length) e.files = 'Nothing to push: the design generated no files';
  else if (files.length > MAX_FILES || files.some(([p, c]) => !FILE.test(p) || typeof c !== 'string')) e.files = 'Invalid file list';
  else if (files.reduce((a, [, c]) => a + c.length, 0) > MAX_BYTES) e.files = 'Files are too large (2 MB max)';
  if (creds) {
    if (!GUID.test(s(creds.tenantId))) e.tenantId = 'Tenant ID must be a GUID';
    if (!GUID.test(s(creds.clientId))) e.clientId = 'Client ID must be a GUID';
    if (!s(creds.clientSecret)) e.clientSecret = 'Client secret is required';
  }
  return e;
}

/** Credentials configured on the host (App Service app settings, optionally Key Vault references). */
export function credentialsFromEnv(env: Record<string, string | undefined>): Credentials | null {
  const tenantId = env.ADO_TENANT_ID?.trim(), clientId = env.ADO_CLIENT_ID?.trim(), clientSecret = env.ADO_CLIENT_SECRET;
  return tenantId && clientId && clientSecret ? { tenantId, clientId, clientSecret } : null;
}

/** Endpoint overrides are for tests only; anything but https must point at the loopback interface. */
export function endpointsFromEnv(env: Record<string, string | undefined>): AdoEndpoints {
  const pick = (v: string | undefined, d: string) => {
    if (!v) return d;
    const u = new URL(v);
    if (u.protocol !== 'https:' && !['127.0.0.1', 'localhost', '[::1]'].includes(u.hostname)) throw new Error('ADO endpoint overrides must use https');
    return v.replace(/\/+$/, '');
  };
  return { loginBase: pick(env.ADO_LOGIN_BASE, DEFAULT_ENDPOINTS.loginBase), adoBase: pick(env.ADO_API_BASE, DEFAULT_ENDPOINTS.adoBase) };
}

const enc = encodeURIComponent;

/** Pull a readable message out of an Entra/ADO error body. */
function errorText(body: string, status: number): string {
  try {
    const j = JSON.parse(body) as { message?: string; error_description?: string; error?: string | { message?: string } };
    const m = j.message ?? j.error_description ?? (typeof j.error === 'string' ? j.error : j.error?.message);
    if (m) return String(m).slice(0, 600);
  } catch { /* not JSON */ }
  return (body.trim() || `HTTP ${status}`).slice(0, 600);
}

export async function createPullRequest(req: PrRequest, creds: Credentials, opts: { fetch: FetchLike; endpoints?: AdoEndpoints }): Promise<PrResult> {
  const fields = validatePrRequest(req, creds);
  if (Object.keys(fields).length) return { ok: false, status: 400, stage: 'validate', error: 'Some fields need attention', fields };
  const { loginBase, adoBase } = opts.endpoints ?? DEFAULT_ENDPOINTS;
  const redact = (t: string) => (creds.clientSecret ? t.split(creds.clientSecret).join('***') : t);
  const fail = (stage: Exclude<PrResult, { ok: true }>['stage'], status: number, body: string): PrResult =>
    ({ ok: false, status, stage, error: redact(errorText(body, status)) });

  // 1. token (client credentials)
  const tokenRes = await opts.fetch(`${loginBase}/${enc(creds.tenantId.trim())}/oauth2/v2.0/token`, {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ grant_type: 'client_credentials', client_id: creds.clientId.trim(), client_secret: creds.clientSecret, scope: ADO_SCOPE }).toString(),
  });
  const tokenBody = await tokenRes.text();
  if (!tokenRes.ok) return fail('token', tokenRes.status, tokenBody);
  let token = '';
  try { token = String((JSON.parse(tokenBody) as { access_token?: string }).access_token ?? ''); } catch { /* handled below */ }
  if (!token) return fail('token', 502, 'Token response had no access_token');

  const org = req.organization.trim(), project = req.project.trim(), repo = req.repository.trim();
  const base = `${adoBase}/${enc(org)}/${enc(project)}/_apis/git/repositories`;
  const auth = { authorization: `Bearer ${token}`, accept: 'application/json' };
  const json = async (stage: Exclude<PrResult, { ok: true }>['stage'], url: string, method = 'GET', body?: unknown) => {
    const r = await opts.fetch(url, { method, headers: body ? { ...auth, 'content-type': 'application/json' } : auth, body: body ? JSON.stringify(body) : undefined });
    const t = await r.text();
    if (!r.ok) return { err: fail(stage, r.status, t) };
    try { return { data: JSON.parse(t) as Record<string, unknown> }; } catch { return { err: fail(stage, 502, 'Unexpected response from Azure DevOps') }; }
  };

  // 2. repository
  const repoRes = await json('repository', `${base}/${enc(repo)}?api-version=${API_VERSION}`);
  if (repoRes.err) return repoRes.err;
  const repoId = String(repoRes.data.id ?? '');

  // 3. target branch head
  const target = req.targetBranch.trim(), branch = req.newBranch.trim();
  const refs = await json('branch', `${base}/${enc(repoId)}/refs?filter=${enc(`heads/${target}`)}&api-version=${API_VERSION}`);
  if (refs.err) return refs.err;
  const head = ((refs.data.value as { name: string; objectId: string }[] | undefined) ?? []).find((x) => x.name === `refs/heads/${target}`);
  if (!head) return { ok: false, status: 404, stage: 'branch', error: `Target branch "${target}" was not found in ${repo}` };

  // existing files under the folder decide add vs edit
  const folder = (req.folder ?? '').replace(/^\/+|\/+$/g, '');
  const existing = new Set<string>();
  const items = await opts.fetch(`${base}/${enc(repoId)}/items?scopePath=${enc(`/${folder}`)}&recursionLevel=Full&versionDescriptor.version=${enc(target)}&api-version=${API_VERSION}`, { headers: auth });
  if (items.ok) {
    try {
      for (const it of ((JSON.parse(await items.text()) as { value?: { path: string }[] }).value ?? [])) existing.add(it.path);
    } catch { /* treat as empty */ }
  }

  // 4. push one commit on a new branch
  const changes = Object.entries(req.files).sort(([a], [b]) => a.localeCompare(b)).map(([p, content]) => {
    const path = `/${folder ? `${folder}/` : ''}${p}`;
    return { changeType: existing.has(path) ? 'edit' : 'add', item: { path }, newContent: { content, contentType: 'rawtext' } };
  });
  const push = await json('push', `${base}/${enc(repoId)}/pushes?api-version=${API_VERSION}`, 'POST', {
    refUpdates: [{ name: `refs/heads/${branch}`, oldObjectId: '0000000000000000000000000000000000000000' }],
    commits: [{ comment: req.title.trim(), parents: [head.objectId], changes }],
  });
  if (push.err) return push.err;

  // 5. pull request
  const pr = await json('pullrequest', `${base}/${enc(repoId)}/pullrequests?api-version=${API_VERSION}`, 'POST', {
    sourceRefName: `refs/heads/${branch}`, targetRefName: `refs/heads/${target}`, title: req.title.trim(), description: (req.description ?? '').slice(0, 4000),
  });
  if (pr.err) return pr.err;
  const id = Number(pr.data.pullRequestId);
  return { ok: true, pullRequestId: id, branch, url: `${adoBase}/${enc(org)}/${enc(project)}/_git/${enc(repo)}/pullrequest/${id}` };
}

import { collectSnapshot, isStale, openStore, readSnapshot, REFRESH_INTERVAL_MS, writeIfBetter } from "./collect.ts";
import { loadConfig, type AppConfig } from "./config.ts";
import type { SnapshotStore } from "./store.ts";
import type { Snapshot, SnapshotStatus } from "./types.ts";

export type RefreshPhase = "idle" | "running" | "done" | "failed";

export interface RefreshStatus {
  phase: RefreshPhase;
  running: boolean;
  startedAt: string | null;
  finishedAt: string | null;
  message: string;
  snapshot: {
    generatedAt: string;
    finishedAt: string;
    status: SnapshotStatus;
    source: string;
    error: string | null;
    warnings: string[];
    stats: Snapshot["stats"];
    loadIssues: Snapshot["loadIssues"];
  } | null;
}

export interface RefreshResult {
  code: 202 | 409;
  status: RefreshStatus;
}

type Collect = () => Promise<Snapshot>;

interface Runtime {
  config: AppConfig;
  store: SnapshotStore;
  collect: Collect;
  phase: RefreshPhase;
  message: string;
  startedAt: string | null;
  finishedAt: string | null;
  inflight: Promise<void> | null;
}

let runtime: Runtime | null = null;

export function resetRuntime(): void {
  runtime = null;
}

export function getRuntime(): Runtime {
  if (!runtime) {
    const config = loadConfig();
    runtime = {
      config,
      store: openStore(config),
      collect: () => collectSnapshot(config),
      phase: "idle",
      message: "",
      startedAt: null,
      finishedAt: null,
      inflight: null,
    };
  }
  return runtime;
}

/** Tests inject a store and a collector. Production uses the process-wide runtime. */
export function useRuntime(partial: Partial<Pick<Runtime, "config" | "store" | "collect">>): Runtime {
  const current = getRuntime();
  Object.assign(current, partial);
  return current;
}

export async function statusSnapshot(): Promise<RefreshStatus> {
  const current = getRuntime();
  let snapshot: Snapshot | null = null;
  let readError = "";
  try {
    snapshot = await readSnapshot(current.config, current.store);
  } catch (error) {
    readError = error instanceof Error ? error.message : "Could not read the snapshot.";
  }
  return {
    phase: current.phase,
    running: current.inflight != null,
    startedAt: current.startedAt,
    finishedAt: current.finishedAt ?? snapshot?.finishedAt ?? null,
    message: current.message || readError,
    snapshot: snapshot
      ? {
          generatedAt: snapshot.generatedAt,
          finishedAt: snapshot.finishedAt,
          status: snapshot.status,
          source: snapshot.source,
          error: snapshot.error ?? null,
          warnings: snapshot.warnings,
          stats: snapshot.stats,
          loadIssues: snapshot.loadIssues ?? [],
        }
      : null,
  };
}

/**
 * Start a collection unless one is already running.
 * 202 means this call started it. 409 means the in-process run or the blob lease is held.
 */
export async function requestRefresh(owner: string): Promise<RefreshResult> {
  const current = getRuntime();
  if (current.inflight) return { code: 409, status: await statusSnapshot() };
  let release = () => {};
  current.inflight = new Promise<void>((resolve) => { release = resolve; });
  current.phase = "running";
  current.startedAt = new Date().toISOString();
  current.message = "Refresh is running";
  let lock: Awaited<ReturnType<SnapshotStore["acquireLock"]>> = null;
  try {
    lock = await current.store.acquireLock(owner, 15 * 60 * 1000);
  } catch (error) {
    current.inflight = null;
    release();
    current.phase = "failed";
    current.finishedAt = new Date().toISOString();
    current.message = error instanceof Error ? error.message : "Could not acquire the collector lease.";
    return { code: 409, status: await statusSnapshot() };
  }
  if (!lock) {
    current.inflight = null;
    release();
    current.phase = "running";
    current.message = "A refresh is already running";
    return { code: 409, status: await statusSnapshot() };
  }
  const held = lock;
  const work = (async () => {
    const renew = setInterval(() => {
      void held.renew().catch((error: unknown) => {
        console.error(`[refresh] lease renew failed: ${error instanceof Error ? error.message : error}`);
      });
    }, 20_000);
    renew.unref();
    try {
      const snapshot = await writeIfBetter(current.store, await current.collect());
      const failed = snapshot.status === "error";
      current.phase = failed ? "failed" : "done";
      current.finishedAt = snapshot.finishedAt;
      current.message = failed
        ? (snapshot.error ?? "Refresh failed")
        : `Refresh finished with ${snapshot.stats.rules} rules`;
    } catch (error) {
      current.phase = "failed";
      current.finishedAt = new Date().toISOString();
      current.message = error instanceof Error ? error.message : "Refresh failed";
      console.error(`[refresh] ${current.message}`);
    } finally {
      clearInterval(renew);
      await held.release().catch(() => undefined);
      current.inflight = null;
      release();
    }
  })();
  void work;
  return { code: 202, status: await statusSnapshot() };
}

/** First pass about 30s after listen when the snapshot is missing or older than 4 hours, then every 4 hours. */
export function startScheduler(): void {
  const kick = setTimeout(() => {
    void maybeScheduled("startup");
  }, 30_000);
  const timer = setInterval(() => {
    void maybeScheduled("interval");
  }, REFRESH_INTERVAL_MS);
  kick.unref();
  timer.unref();
}

async function maybeScheduled(reason: "startup" | "interval"): Promise<void> {
  if (reason === "startup") {
    try {
      const current = getRuntime();
      const snapshot = await current.store.readLatest();
      if (!isStale(snapshot)) return;
    } catch (error) {
      console.error(`[refresh] could not check the snapshot: ${error instanceof Error ? error.message : error}`);
    }
  }
  const result = await requestRefresh(`scheduler:${reason}`);
  if (result.code === 409) console.log("[refresh] skipped; a refresh is already running");
}

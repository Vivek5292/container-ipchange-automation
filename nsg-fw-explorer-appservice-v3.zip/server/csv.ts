import type { RuleRow } from "./types.ts";

const NSG_COLUMNS: { key: keyof RuleRow; header: string }[] = [
  { key: "ruleName", header: "ruleName" },
  { key: "subscriptionName", header: "subscriptionName" },
  { key: "subscriptionId", header: "subscriptionId" },
  { key: "resourceGroup", header: "resourceGroup" },
  { key: "location", header: "location" },
  { key: "vnet", header: "vnet" },
  { key: "subnets", header: "subnets" },
  { key: "nic", header: "nic" },
  { key: "vmName", header: "vmName" },
  { key: "nsgOrFirewallName", header: "nsg" },
  { key: "direction", header: "direction" },
  { key: "action", header: "action" },
  { key: "priority", header: "priority" },
  { key: "protocols", header: "protocols" },
  { key: "sourceAddresses", header: "sourceAddresses" },
  { key: "destinationAddresses", header: "destinationAddresses" },
  { key: "sourcePorts", header: "sourcePorts" },
  { key: "destinationPorts", header: "destinationPorts" },
  { key: "isDefault", header: "isDefault" },
  { key: "description", header: "description" },
  { key: "resourceId", header: "resourceId" },
];

const FIREWALL_COLUMNS: { key: keyof RuleRow; header: string }[] = [
  { key: "ruleName", header: "ruleName" },
  { key: "sourceType", header: "sourceType" },
  { key: "subscriptionName", header: "subscriptionName" },
  { key: "subscriptionId", header: "subscriptionId" },
  { key: "resourceGroup", header: "resourceGroup" },
  { key: "nsgOrFirewallName", header: "firewall" },
  { key: "policyName", header: "policyName" },
  { key: "collectionGroupName", header: "collectionGroupName" },
  { key: "collectionGroupPriority", header: "collectionGroupPriority" },
  { key: "collectionName", header: "collectionName" },
  { key: "collectionPriority", header: "collectionPriority" },
  { key: "ruleType", header: "ruleType" },
  { key: "direction", header: "direction" },
  { key: "action", header: "action" },
  { key: "priority", header: "priority" },
  { key: "protocols", header: "protocols" },
  { key: "sourceAddresses", header: "sourceAddresses" },
  { key: "destinationAddresses", header: "destinationAddresses" },
  { key: "destinationPorts", header: "destinationPorts" },
  { key: "translatedAddress", header: "translatedAddress" },
  { key: "translatedPort", header: "translatedPort" },
  { key: "description", header: "description" },
  { key: "resourceId", header: "resourceId" },
];

function cell(value: unknown): string {
  if (Array.isArray(value)) return value.join("; ");
  if (value == null) return "";
  if (typeof value === "boolean") return value ? "true" : "false";
  return String(value);
}

function escapeCsv(value: string): string {
  if (/[",\n\r]/.test(value)) return `"${value.replaceAll('"', '""')}"`;
  return value;
}

export function rulesToCsv(rules: RuleRow[], view: "nsg" | "firewall" | "" = ""): string {
  const columns = view === "firewall" ? FIREWALL_COLUMNS : view === "nsg" ? NSG_COLUMNS : NSG_COLUMNS;
  const headers = columns.map((column) => column.header);
  const lines = [headers.join(",")];
  for (const rule of rules) {
    lines.push(columns.map((column) => escapeCsv(cell(rule[column.key]))).join(","));
  }
  return `\uFEFF${lines.join("\n")}\n`;
}

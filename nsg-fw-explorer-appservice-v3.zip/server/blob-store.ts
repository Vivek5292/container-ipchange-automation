import { randomUUID } from "node:crypto";
import { gunzipSync, gzipSync } from "node:zlib";
import { STORAGE_RESOURCE, accessToken } from "./identity.ts";
import type { SnapshotLock, SnapshotStore } from "./store.ts";
import type { Snapshot } from "./types.ts";

const VERSION = "2023-11-03";

/**
 * Blob data-plane calls with a bearer token. No storage key and no SDK.
 * The collector lease is on locks/collector.lock.
 */
export class BlobSnapshotStore implements SnapshotStore {
  private readonly accountUrl: string;
  private readonly container: string;

  constructor(accountUrl: string, container: string) {
    this.accountUrl = accountUrl;
    this.container = container;
  }

  async readLatest(): Promise<Snapshot | null> {
    const response = await this.request("GET", "snapshots/latest.json.gz");
    if (response.status === 404) {
      const plain = await this.request("GET", "snapshots/latest.json");
      if (plain.status === 404) return null;
      if (!plain.ok) throw new Error(`Could not read snapshot (${plain.status})`);
      return JSON.parse(await plain.text()) as Snapshot;
    }
    if (!response.ok) throw new Error(`Could not read snapshot (${response.status})`);
    const bytes = Buffer.from(await response.arrayBuffer());
    const json = gunzipSync(bytes).toString("utf8");
    return JSON.parse(json) as Snapshot;
  }

  async write(snapshot: Snapshot): Promise<void> {
    const body = gzipSync(Buffer.from(JSON.stringify(snapshot)));
    const stamp = snapshot.generatedAt.replaceAll(":", "-");
    await this.putBlob(`snapshots/history/${stamp}.json.gz`, body);
    await this.putBlob("snapshots/latest.json.gz", body);
  }

  async acquireLock(_owner: string, ttlMs: number): Promise<SnapshotLock | null> {
    const duration = Math.min(60, Math.max(15, Math.ceil(ttlMs / 1000)));
    await this.ensureLockBlob();
    const leaseId = randomUUID();
    const response = await this.request("PUT", "locks/collector.lock", {
      query: { comp: "lease" },
      headers: {
        "x-ms-lease-action": "acquire",
        "x-ms-lease-duration": String(duration),
        "x-ms-proposed-lease-id": leaseId,
      },
    });
    if (response.status === 409) return null;
    if (!response.ok) throw new Error(`Could not acquire collector lease (${response.status})`);
    const id = response.headers.get("x-ms-lease-id") || leaseId;
    return {
      renew: async () => {
        const renewed = await this.request("PUT", "locks/collector.lock", {
          query: { comp: "lease" },
          headers: { "x-ms-lease-action": "renew", "x-ms-lease-id": id },
        });
        if (!renewed.ok) throw new Error(`Could not renew collector lease (${renewed.status})`);
      },
      release: async () => {
        await this.request("PUT", "locks/collector.lock", {
          query: { comp: "lease" },
          headers: { "x-ms-lease-action": "release", "x-ms-lease-id": id },
        }).catch(() => undefined);
      },
    };
  }

  private async ensureLockBlob(): Promise<void> {
    const existing = await this.request("HEAD", "locks/collector.lock");
    if (existing.ok || existing.status === 200) return;
    await this.putBlob("locks/collector.lock", Buffer.from("lock"));
  }

  private async putBlob(name: string, body: Buffer): Promise<void> {
    const response = await this.request("PUT", name, {
      body,
      headers: { "x-ms-blob-type": "BlockBlob", "Content-Type": "application/octet-stream" },
    });
    if (!response.ok) throw new Error(`Could not write ${name} (${response.status})`);
  }

  private async request(method: string, blob: string, init: { query?: Record<string, string>; headers?: Record<string, string>; body?: Buffer } = {}): Promise<Response> {
    const token = await accessToken(STORAGE_RESOURCE);
    const url = new URL(`${this.accountUrl}/${this.container}/${blob}`);
    for (const [key, value] of Object.entries(init.query ?? {})) url.searchParams.set(key, value);
    return fetch(url, {
      method,
      headers: {
        Authorization: `Bearer ${token}`,
        "x-ms-version": VERSION,
        ...init.headers,
      },
      body: init.body,
      signal: AbortSignal.timeout(30_000),
    });
  }
}

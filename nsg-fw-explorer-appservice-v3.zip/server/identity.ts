import { spawn } from "node:child_process";

const cache = new Map<string, { token: string; expires: number }>();

export const ARM_RESOURCE = "https://management.azure.com";
export const STORAGE_RESOURCE = "https://storage.azure.com";

/** Managed identity via IDENTITY_ENDPOINT, or `az account get-access-token` on a workstation. */
export async function accessToken(resource: string): Promise<string> {
  const hit = cache.get(resource);
  if (hit && hit.expires > Date.now() + 60_000) return hit.token;
  const token = process.env.IDENTITY_ENDPOINT && process.env.IDENTITY_HEADER
    ? await tokenFromIdentity(resource)
    : await tokenFromCli(resource);
  return token;
}

async function tokenFromIdentity(resource: string): Promise<string> {
  const url = new URL(process.env.IDENTITY_ENDPOINT ?? "");
  url.searchParams.set("resource", resource);
  url.searchParams.set("api-version", "2019-08-01");
  const response = await fetch(url, {
    headers: { "X-IDENTITY-HEADER": process.env.IDENTITY_HEADER ?? "" },
    signal: AbortSignal.timeout(10_000),
  });
  if (!response.ok) throw new Error(`Managed identity token request failed (${response.status})`);
  const body = await response.json() as { access_token?: string; expires_on?: string };
  if (!body.access_token) throw new Error("Managed identity returned no access token");
  const expires = body.expires_on ? Number(body.expires_on) * 1000 : Date.now() + 10 * 60_000;
  cache.set(resource, { token: body.access_token, expires: Number.isFinite(expires) ? expires : Date.now() + 10 * 60_000 });
  return body.access_token;
}

function tokenFromCli(resource: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const child = spawn("az", ["account", "get-access-token", "--resource", resource, "--query", "accessToken", "-o", "tsv"], {
      stdio: ["ignore", "pipe", "pipe"],
    });
    let out = "";
    let err = "";
    child.stdout.on("data", (chunk: Buffer) => { out += chunk.toString(); });
    child.stderr.on("data", (chunk: Buffer) => { err += chunk.toString(); });
    child.on("error", () => reject(new Error("Azure CLI is not available and IDENTITY_ENDPOINT is not set")));
    child.on("close", (code) => {
      const token = out.trim();
      if (code !== 0 || !token) {
        reject(new Error(err.trim() || "Azure CLI did not return an access token"));
        return;
      }
      cache.set(resource, { token, expires: Date.now() + 10 * 60_000 });
      resolve(token);
    });
  });
}

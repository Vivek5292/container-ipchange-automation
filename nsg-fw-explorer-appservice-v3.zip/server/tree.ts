import type { RuleRow } from "./types.ts";

const DIRECTION_ORDER = ["Inbound", "Outbound", "n/a"];
const ACTION_ORDER = ["Allow", "Deny", "DNAT"];

export interface ActionGroup {
  label: string;
  rules: RuleRow[];
}

export interface NsgNode {
  name: string;
  actions: ActionGroup[];
  count: number;
}

export interface SubscriptionNode {
  id: string;
  name: string;
  nsgs: NsgNode[];
  count: number;
}

export interface CollectionNode {
  name: string;
  groupName: string;
  groupPriority: number | null;
  collectionPriority: number | null;
  actions: ActionGroup[];
  count: number;
}

export interface PolicyNode {
  name: string;
  classic: boolean;
  collections: CollectionNode[];
  count: number;
}

export interface FirewallNode {
  name: string;
  subscriptionName: string;
  policies: PolicyNode[];
  count: number;
}

/** The rule's own Azure description. A blank value or a copy of the rule name is not a description. */
export function ruleDescription(rule: Pick<RuleRow, "ruleName" | "description">): string {
  const text = rule.description.trim();
  if (!text || text.toLowerCase() === rule.ruleName.trim().toLowerCase()) return "";
  return text;
}

export function sortRulesForTree(rules: RuleRow[]): RuleRow[] {
  return [...rules].sort((left, right) => {
    const direction = rank(DIRECTION_ORDER, left.direction) - rank(DIRECTION_ORDER, right.direction);
    if (direction !== 0) return direction;
    const priority = (left.priority ?? Number.POSITIVE_INFINITY) - (right.priority ?? Number.POSITIVE_INFINITY);
    if (priority !== 0) return priority;
    return left.ruleName.localeCompare(right.ruleName);
  });
}

export function groupNsgTree(rules: RuleRow[]): SubscriptionNode[] {
  const subscriptions = new Map<string, { name: string; nsgs: Map<string, RuleRow[]> }>();
  for (const rule of rules) {
    if (rule.sourceType !== "nsg") continue;
    const sub = subscriptions.get(rule.subscriptionId) ?? { name: rule.subscriptionName || rule.subscriptionId, nsgs: new Map() };
    const list = sub.nsgs.get(rule.nsgOrFirewallName) ?? [];
    list.push(rule);
    sub.nsgs.set(rule.nsgOrFirewallName, list);
    subscriptions.set(rule.subscriptionId, sub);
  }
  return [...subscriptions.entries()]
    .map(([id, sub]) => {
      const nsgs = [...sub.nsgs.entries()]
        .sort(([left], [right]) => left.localeCompare(right))
        .map(([name, grouped]) => {
          const actions = groupByAction(grouped);
          return { name, actions, count: grouped.length };
        });
      return { id, name: sub.name, nsgs, count: nsgs.reduce((sum, nsg) => sum + nsg.count, 0) };
    })
    .sort((left, right) => left.name.localeCompare(right.name));
}

export function groupFirewallTree(rules: RuleRow[]): FirewallNode[] {
  const firewalls = new Map<string, { name: string; subscriptionName: string; policies: Map<string, { classic: boolean; collections: Map<string, RuleRow[]> }> }>();
  for (const rule of rules) {
    if (rule.sourceType === "nsg") continue;
    const key = `${rule.subscriptionId}|${rule.nsgOrFirewallName}`;
    const firewall = firewalls.get(key) ?? { name: rule.nsgOrFirewallName, subscriptionName: rule.subscriptionName, policies: new Map() };
    const classic = rule.sourceType === "firewall-classic" || !rule.policyName;
    const policyKey = classic ? "classic" : rule.policyName;
    const policy = firewall.policies.get(policyKey) ?? { classic, collections: new Map() };
    const collectionKey = `${rule.collectionGroupName}|${rule.collectionName}`;
    const list = policy.collections.get(collectionKey) ?? [];
    list.push(rule);
    policy.collections.set(collectionKey, list);
    firewall.policies.set(policyKey, policy);
    firewalls.set(key, firewall);
  }
  return [...firewalls.values()]
    .map((firewall) => {
      const policies = [...firewall.policies.entries()]
        .sort(([leftKey, left], [rightKey, right]) => {
          if (left.classic !== right.classic) return left.classic ? 1 : -1;
          return leftKey.localeCompare(rightKey);
        })
        .map(([key, policy]) => {
          const collections = [...policy.collections.values()]
            .map((grouped) => collectionNode(grouped))
            .sort((left, right) => (left.groupPriority ?? Number.POSITIVE_INFINITY) - (right.groupPriority ?? Number.POSITIVE_INFINITY) || (left.collectionPriority ?? 0) - (right.collectionPriority ?? 0) || left.name.localeCompare(right.name));
          return {
            name: policy.classic ? "Classic rules" : key,
            classic: policy.classic,
            collections,
            count: collections.reduce((sum, collection) => sum + collection.count, 0),
          };
        });
      return {
        name: firewall.name,
        subscriptionName: firewall.subscriptionName,
        policies,
        count: policies.reduce((sum, policy) => sum + policy.count, 0),
      };
    })
    .sort((left, right) => left.name.localeCompare(right.name) || left.subscriptionName.localeCompare(right.subscriptionName));
}

function collectionNode(rules: RuleRow[]): CollectionNode {
  const sample = rules[0];
  const actions = groupByAction(rules);
  return {
    name: sample.collectionName || "Collection",
    groupName: sample.collectionGroupName,
    groupPriority: sample.collectionGroupPriority,
    collectionPriority: sample.collectionPriority,
    actions,
    count: rules.length,
  };
}

function groupByAction(rules: RuleRow[]): ActionGroup[] {
  const groups = new Map<string, RuleRow[]>();
  for (const rule of rules) {
    const label = rule.action || "Allow";
    const list = groups.get(label) ?? [];
    list.push(rule);
    groups.set(label, list);
  }
  return [...groups.entries()]
    .sort(([left], [right]) => rank(ACTION_ORDER, left) - rank(ACTION_ORDER, right) || left.localeCompare(right))
    .map(([label, grouped]) => ({ label, rules: sortRulesForTree(grouped) }));
}

function rank(order: string[], value: string): number {
  const index = order.indexOf(value);
  return index === -1 ? order.length : index;
}

export function nsgNodeIds(tree: SubscriptionNode[]): string[] {
  const ids: string[] = [];
  for (const sub of tree) {
    ids.push(`sub:${sub.id}`);
    for (const nsg of sub.nsgs) {
      ids.push(`nsg:${sub.id}|${nsg.name}`);
      for (const action of nsg.actions) ids.push(`nsg-action:${sub.id}|${nsg.name}|${action.label}`);
    }
  }
  return ids;
}

export function firewallNodeIds(tree: FirewallNode[]): string[] {
  const ids: string[] = [];
  for (const firewall of tree) {
    const root = `fw:${firewall.subscriptionName}|${firewall.name}`;
    ids.push(root);
    for (const policy of firewall.policies) {
      const policyId = `${root}|${policy.name}`;
      ids.push(policyId);
      for (const collection of policy.collections) {
        const collectionId = `${policyId}|${collection.groupName}|${collection.name}`;
        ids.push(collectionId);
        for (const action of collection.actions) ids.push(`${collectionId}|${action.label}`);
      }
    }
  }
  return ids;
}

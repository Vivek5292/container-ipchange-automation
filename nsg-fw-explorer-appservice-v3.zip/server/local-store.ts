import { mkdir, open, readdir, readFile, rename, rm, stat, unlink, writeFile } from "node:fs/promises";
import path from "node:path";
import type { Snapshot } from "./types.ts";
import type { SnapshotLock, SnapshotStore } from "./store.ts";

interface LockFile {
  owner: string;
  expiresAt: number;
}

export class LocalSnapshotStore implements SnapshotStore {
  private cache: { mtimeMs: number; snapshot: Snapshot } | null = null;
  private readonly directory: string;

  constructor(directory: string) {
    this.directory = directory;
  }

  async readLatest(): Promise<Snapshot | null> {
    const file = this.latestPath();
    try {
      const info = await stat(file);
      if (this.cache && this.cache.mtimeMs === info.mtimeMs) return this.cache.snapshot;
      const snapshot = JSON.parse(await readFile(file, "utf8")) as Snapshot;
      this.cache = { mtimeMs: info.mtimeMs, snapshot };
      return snapshot;
    } catch (error) {
      if (isNotFound(error)) return null;
      throw error;
    }
  }

  async write(snapshot: Snapshot): Promise<void> {
    await mkdir(this.historyDir(), { recursive: true });
    const payload = JSON.stringify(snapshot);
    const stamp = snapshot.generatedAt.replaceAll(":", "-");
    await this.atomicWrite(path.join(this.historyDir(), `${stamp}.json`), payload);
    await this.atomicWrite(this.latestPath(), payload);
    const info = await stat(this.latestPath());
    this.cache = { mtimeMs: info.mtimeMs, snapshot };
    await this.pruneHistory(48);
  }

  async acquireLock(owner: string, ttlMs: number): Promise<SnapshotLock | null> {
    await mkdir(this.directory, { recursive: true });
    const lockPath = path.join(this.directory, "collector.lock");
    const writeNew = async () => {
      const handle = await open(lockPath, "wx");
      try {
        await handle.writeFile(JSON.stringify({ owner, expiresAt: Date.now() + ttlMs } satisfies LockFile));
      } finally {
        await handle.close();
      }
    };
    try {
      await writeNew();
    } catch (error) {
      if (!isAlreadyExists(error)) throw error;
      const current = await readLock(lockPath);
      if (current && current.expiresAt > Date.now()) return null;
      await unlink(lockPath).catch(() => undefined);
      try {
        await writeNew();
      } catch (retryError) {
        if (isAlreadyExists(retryError)) return null;
        throw retryError;
      }
    }
    return {
      renew: async () => {
        await writeFile(lockPath, JSON.stringify({ owner, expiresAt: Date.now() + ttlMs } satisfies LockFile));
      },
      release: async () => {
        await unlink(lockPath).catch(() => undefined);
      },
    };
  }

  private latestPath(): string {
    return path.join(this.directory, "latest.json");
  }

  private historyDir(): string {
    return path.join(this.directory, "history");
  }

  private async atomicWrite(file: string, payload: string): Promise<void> {
    const temporary = `${file}.${process.pid}.tmp`;
    await writeFile(temporary, payload);
    await rename(temporary, file);
  }

  private async pruneHistory(keep: number): Promise<void> {
    const entries = await readdir(this.historyDir());
    const json = entries.filter((name) => name.endsWith(".json")).sort();
    const extra = json.length - keep;
    if (extra <= 0) return;
    await Promise.all(json.slice(0, extra).map((name) => rm(path.join(this.historyDir(), name), { force: true })));
  }
}

async function readLock(file: string): Promise<LockFile | null> {
  try {
    const parsed = JSON.parse(await readFile(file, "utf8")) as LockFile;
    if (!parsed || typeof parsed.expiresAt !== "number") return null;
    return parsed;
  } catch {
    return null;
  }
}

function isNotFound(error: unknown): boolean {
  return isCode(error, "ENOENT");
}

function isAlreadyExists(error: unknown): boolean {
  return isCode(error, "EEXIST");
}

function isCode(error: unknown, code: string): boolean {
  return typeof error === "object" && error !== null && "code" in error && error.code === code;
}

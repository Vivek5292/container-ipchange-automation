import { childProps, isRecord, parentResourceId } from "./arm.ts";

export function ruleCollectionGroupNeedsDetail(group: unknown): boolean {
  const collections = childProps(group).ruleCollections;
  if (!Array.isArray(collections) || collections.length === 0) return true;
  return collections.some((collection) => !Array.isArray(childProps(collection).rules));
}

export function groupPolicyId(group: unknown): string {
  if (!isRecord(group) || typeof group.id !== "string") return "";
  return parentResourceId(group.id, "ruleCollectionGroups").toLowerCase();
}

/**
 * Resource Graph often lists firewall policy rule collection groups without rule bodies.
 * Keep complete groups and replace incomplete ones with an ARM list for that policy.
 */
export async function resolveRuleCollectionGroups(
  graphGroups: unknown[],
  policyIds: string[],
  loadDetail: (policyId: string) => Promise<unknown[]>,
): Promise<{ groups: unknown[]; warnings: string[] }> {
  const warnings: string[] = [];
  const byPolicy = new Map<string, unknown[]>();
  for (const group of graphGroups) {
    const policyId = groupPolicyId(group);
    const list = byPolicy.get(policyId) ?? [];
    list.push(group);
    byPolicy.set(policyId, list);
  }

  const groups: unknown[] = [];
  const seen = new Set<string>();
  for (const policyId of policyIds) {
    const key = policyId.toLowerCase();
    seen.add(key);
    const existing = byPolicy.get(key) ?? [];
    if (existing.length > 0 && existing.every((group) => !ruleCollectionGroupNeedsDetail(group))) {
      groups.push(...existing);
      continue;
    }
    try {
      const detailed = await loadDetail(policyId);
      if (detailed.length === 0 && existing.length > 0) {
        warnings.push(`ARM returned no rule collection groups for ${policyId}; keeping the Resource Graph summary.`);
        groups.push(...existing);
      } else {
        groups.push(...detailed);
      }
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      warnings.push(`Could not read firewall policy rule collection groups for ${policyId}: ${message}`);
      groups.push(...existing);
    }
  }

  for (const [policyId, existing] of byPolicy) {
    if (seen.has(policyId)) continue;
    groups.push(...existing);
  }
  return { groups, warnings };
}

import type { Snapshot } from "./types.ts";

export interface SnapshotLock {
  renew(): Promise<void>;
  release(): Promise<void>;
}

export interface SnapshotStore {
  readLatest(): Promise<Snapshot | null>;
  write(snapshot: Snapshot): Promise<void>;
  acquireLock(owner: string, ttlMs: number): Promise<SnapshotLock | null>;
}

import { childProps, linkedIds, parseAzureId, resourceName } from "../arm.ts";
import type { ArmResource, NicRef, NormalizeContext } from "../types.ts";

function indexKey(id: string): string {
  return id.trim().toLowerCase();
}

function subnetFromNic(nic: ArmResource): string {
  const configs = childProps(nic).ipConfigurations;
  if (!Array.isArray(configs)) return "";
  for (const config of configs) {
    const body = childProps(config);
    const subnet = body.subnet;
    if (subnet && typeof subnet === "object" && "id" in subnet && typeof subnet.id === "string") return subnet.id;
  }
  return "";
}

function nicRef(nic: ArmResource): NicRef {
  const props = childProps(nic);
  const vm = props.virtualMachine;
  const nsg = props.networkSecurityGroup;
  const vmId = vm && typeof vm === "object" && "id" in vm && typeof vm.id === "string" ? vm.id : "";
  const nsgId = nsg && typeof nsg === "object" && "id" in nsg && typeof nsg.id === "string" ? nsg.id : "";
  return {
    id: nic.id,
    name: nic.name || resourceName(nic.id),
    vmName: vmId ? resourceName(vmId) : "",
    subnetId: subnetFromNic(nic),
    nsgId,
  };
}

export function buildContext(input: {
  subscriptions: { subscriptionId: string; name: string }[];
  vnets: ArmResource[];
  nics: ArmResource[];
}): NormalizeContext {
  const subscriptionNames = new Map<string, string>();
  for (const subscription of input.subscriptions) {
    subscriptionNames.set(subscription.subscriptionId.toLowerCase(), subscription.name || subscription.subscriptionId);
  }

  const subnetsById = new Map<string, { vnet: string; subnet: string }>();
  for (const vnet of input.vnets) {
    const subnets = childProps(vnet).subnets;
    if (!Array.isArray(subnets)) continue;
    for (const subnet of subnets) {
      if (!subnet || typeof subnet !== "object") continue;
      const record = subnet as { id?: string; name?: string };
      const name = record.name || (record.id ? resourceName(record.id) : "");
      const id = record.id || (name ? `${vnet.id}/subnets/${name}` : "");
      if (!id || !name) continue;
      subnetsById.set(indexKey(id), { vnet: vnet.name || resourceName(vnet.id), subnet: name });
    }
  }

  const nicsById = new Map<string, NicRef>();
  const nicsByNsgId = new Map<string, NicRef[]>();
  for (const nic of input.nics) {
    const ref = nicRef(nic);
    nicsById.set(indexKey(nic.id), ref);
    if (!ref.nsgId) continue;
    const key = indexKey(ref.nsgId);
    const list = nicsByNsgId.get(key) ?? [];
    list.push(ref);
    nicsByNsgId.set(key, list);
  }

  return { subscriptionNames, subnetsById, nicsById, nicsByNsgId };
}

export function subscriptionName(ctx: NormalizeContext, subscriptionId: string): string {
  if (!subscriptionId) return "";
  return ctx.subscriptionNames.get(subscriptionId.toLowerCase()) ?? subscriptionId;
}

export function describeSubnet(ctx: NormalizeContext, subnetId: string): { vnet: string; subnet: string } {
  const known = ctx.subnetsById.get(indexKey(subnetId));
  if (known) return known;
  const match = /\/virtualNetworks\/([^/]+)\/subnets\/([^/]+)/i.exec(subnetId);
  if (!match) return { vnet: "", subnet: "" };
  return { vnet: match[1], subnet: match[2] };
}

export function placementForNsg(nsg: ArmResource, ctx: NormalizeContext): {
  vnet: string;
  subnets: string[];
  nic: string;
  vmName: string;
} {
  const props = childProps(nsg);
  const nicIds = new Set(linkedIds(props.networkInterfaces).map(indexKey));
  const nics = [...(ctx.nicsByNsgId.get(indexKey(nsg.id)) ?? [])];
  for (const id of nicIds) {
    const nic = ctx.nicsById.get(id);
    if (nic && !nics.some((item) => indexKey(item.id) === id)) nics.push(nic);
  }

  const subnetIds = [...linkedIds(props.subnets), ...nics.map((nic) => nic.subnetId).filter(Boolean)];
  const vnets: string[] = [];
  const subnets: string[] = [];
  for (const subnetId of subnetIds) {
    const described = describeSubnet(ctx, subnetId);
    if (described.vnet && !vnets.includes(described.vnet)) vnets.push(described.vnet);
    if (described.subnet && !subnets.includes(described.subnet)) subnets.push(described.subnet);
  }

  return {
    vnet: vnets.join(", "),
    subnets,
    nic: nics.map((nic) => nic.name).filter(Boolean).join(", "),
    vmName: nics.map((nic) => nic.vmName).filter(Boolean).join(", "),
  };
}

export function placementForFirewall(firewall: ArmResource, ctx: NormalizeContext): { vnet: string; subnets: string[] } {
  const configs = childProps(firewall).ipConfigurations;
  if (!Array.isArray(configs)) return { vnet: "", subnets: [] };
  const vnets: string[] = [];
  const subnets: string[] = [];
  for (const config of configs) {
    const subnet = childProps(config).subnet;
    const subnetId = subnet && typeof subnet === "object" && "id" in subnet && typeof subnet.id === "string" ? subnet.id : "";
    if (!subnetId) continue;
    const described = describeSubnet(ctx, subnetId);
    if (described.vnet && !vnets.includes(described.vnet)) vnets.push(described.vnet);
    if (described.subnet && !subnets.includes(described.subnet)) subnets.push(described.subnet);
  }
  return { vnet: vnets.join(", "), subnets };
}

export function resourceIdentity(resource: ArmResource): { subscriptionId: string; resourceGroup: string; location: string } {
  const parsed = parseAzureId(resource.id ?? "");
  return {
    subscriptionId: resource.subscriptionId || parsed.subscriptionId,
    resourceGroup: resource.resourceGroup || parsed.resourceGroup,
    location: resource.location ?? "",
  };
}

import {
  asNumber,
  asString,
  buildSearchText,
  childProps,
  normalizeAction,
  normalizeDirection,
  readProtocols,
  readResourceRefs,
  readStrings,
  ruleId,
} from "../arm.ts";
import type { ArmResource, NormalizeContext, RuleRow } from "../types.ts";
import { placementForNsg, resourceIdentity, subscriptionName } from "./context.ts";

function nsgRuleRow(
  nsg: ArmResource,
  rule: unknown,
  isDefault: boolean,
  ctx: NormalizeContext,
): RuleRow | null {
  if (!rule || typeof rule !== "object") return null;
  const record = rule as { name?: string };
  const props = childProps(rule);
  const action = normalizeAction(props.access ?? props.action);
  if (!action || action === "DNAT") return null;
  const identity = resourceIdentity(nsg);
  const placement = placementForNsg(nsg, ctx);
  const protocolInfo = readProtocols(props.protocol ?? props.protocols);
  const sourcePorts = readStrings(props, "sourcePortRange", "sourcePortRanges", "sourcePorts");
  const destinationPorts = readStrings(props, "destinationPortRange", "destinationPortRanges", "destinationPorts");
  const sourceAddresses = [
    ...readStrings(props, "sourceAddressPrefix", "sourceAddressPrefixes", "sourceAddresses"),
    ...readResourceRefs(props.sourceApplicationSecurityGroups, "asg:"),
    ...readResourceRefs(props.sourceIpGroups, "ip-group:"),
  ];
  const destinationAddresses = [
    ...readStrings(props, "destinationAddressPrefix", "destinationAddressPrefixes", "destinationAddresses"),
    ...readResourceRefs(props.destinationApplicationSecurityGroups, "asg:"),
    ...readResourceRefs(props.destinationIpGroups, "ip-group:"),
  ];
  const ruleName = asString(record.name) || asString(props.name) || "unnamed";
  const priority = asNumber(props.priority);
  const direction = normalizeDirection(props.direction);
  const description = asString(props.description);
  const ruleType = isDefault ? "default" : "security";
  const row: RuleRow = {
    id: ruleId(["nsg", nsg.id, ruleName, direction, ruleType, String(priority ?? "")]),
    sourceType: "nsg",
    subscriptionId: identity.subscriptionId,
    subscriptionName: subscriptionName(ctx, identity.subscriptionId),
    resourceGroup: identity.resourceGroup,
    location: identity.location,
    vnet: placement.vnet,
    subnets: placement.subnets,
    nic: placement.nic,
    vmName: placement.vmName,
    nsgOrFirewallName: nsg.name,
    resourceId: nsg.id,
    policyName: "",
    collectionGroupName: "",
    collectionGroupPriority: null,
    collectionName: "",
    collectionPriority: null,
    ruleName,
    ruleType,
    direction,
    action,
    priority,
    priorityLabel: priority == null ? "" : String(priority),
    protocols: protocolInfo.protocols,
    sourceAddresses,
    destinationAddresses,
    sourcePorts,
    destinationPorts: destinationPorts.length ? destinationPorts : protocolInfo.ports,
    translatedAddress: "",
    translatedPort: "",
    isDefault,
    description,
    raw: rule,
    searchText: "",
  };
  row.searchText = buildSearchText([row, row.raw]);
  return row;
}

export function normalizeNsg(nsg: ArmResource, ctx: NormalizeContext): RuleRow[] {
  const props = childProps(nsg);
  const custom = Array.isArray(props.securityRules) ? props.securityRules : [];
  const defaults = Array.isArray(props.defaultSecurityRules) ? props.defaultSecurityRules : [];
  const rows: RuleRow[] = [];
  for (const rule of custom) {
    const row = nsgRuleRow(nsg, rule, false, ctx);
    if (row) rows.push(row);
  }
  for (const rule of defaults) {
    const row = nsgRuleRow(nsg, rule, true, ctx);
    if (row) rows.push(row);
  }
  return rows;
}

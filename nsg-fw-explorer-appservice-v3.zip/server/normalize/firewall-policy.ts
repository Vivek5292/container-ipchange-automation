import {
  asNumber,
  asString,
  buildSearchText,
  childProps,
  normalizeAction,
  readProtocols,
  readResourceRefs,
  readStrings,
  ruleId,
} from "../arm.ts";
import type { ArmResource, NormalizeContext, RuleKind, RuleRow } from "../types.ts";
import { placementForFirewall, resourceIdentity, subscriptionName } from "./context.ts";

function policyRuleRow(
  group: ArmResource,
  policy: ArmResource,
  firewall: ArmResource | null,
  collection: Record<string, unknown>,
  rule: unknown,
  ctx: NormalizeContext,
): RuleRow | null {
  if (!rule || typeof rule !== "object") return null;
  const record = rule as Record<string, unknown>;
  const props = childProps(rule);
  const collectionProps = childProps(collection);
  const groupProps = childProps(group);
  const ruleTypeName = asString(record.ruleType ?? props.ruleType).toLowerCase();
  const collectionType = asString(collection.ruleCollectionType ?? collectionProps.ruleCollectionType).toLowerCase();
  let ruleType: RuleKind = "network";
  if (ruleTypeName.includes("application") || collectionType.includes("application")) ruleType = "application";
  else if (ruleTypeName.includes("nat") || collectionType.includes("nat")) ruleType = "nat";

  const action = normalizeAction(collectionProps.action ?? collection.action) ?? (ruleType === "nat" ? "DNAT" : null);
  if (!action) return null;

  const protocolSource = props.ipProtocols ?? props.protocols ?? record.ipProtocols ?? record.protocols;
  const protocolInfo = readProtocols(protocolSource);
  const sourceAddresses = [
    ...readStrings(props, "sourceAddresses", "sourceAddressPrefix", "sourceAddressPrefixes"),
    ...readResourceRefs(props.sourceIpGroups, "ip-group:"),
  ];
  const destinationAddresses = [
    ...readStrings(props, "destinationAddresses", "destinationAddressPrefix", "destinationAddressPrefixes", "destinationFqdns", "targetFqdns"),
    ...readResourceRefs(props.destinationIpGroups, "ip-group:"),
    ...readResourceRefs(props.fqdnTags, "fqdn-tag:"),
  ];
  const destinationPorts = dedupePorts([
    ...readStrings(props, "destinationPorts", "destinationPortRange", "destinationPortRanges"),
    ...protocolInfo.ports,
  ]);
  const sourcePorts = readStrings(props, "sourcePorts", "sourcePortRange", "sourcePortRanges");
  const groupPriority = asNumber(groupProps.priority);
  const collectionPriority = asNumber(collectionProps.priority ?? collection.priority);
  const ruleName = asString(record.name) || asString(props.name) || "unnamed";
  const collectionName = asString(collection.name) || asString(collectionProps.name) || "collection";
  const identity = resourceIdentity(firewall ?? policy);
  const placement = firewall ? placementForFirewall(firewall, ctx) : { vnet: "", subnets: [] as string[] };
  const translatedAddress = asString(props.translatedAddress) || asString(props.translatedFqdn);
  const translatedPort = asString(props.translatedPort);
  const description = asString(props.description);
  const direction = action === "DNAT" || ruleType === "nat" ? "Inbound" : "Outbound";
  const priorityLabel = [groupPriority, collectionPriority].filter((value) => value != null).join(" / ");

  const row: RuleRow = {
    id: ruleId([
      "firewall-policy",
      firewall?.id ?? policy.id,
      group.name ?? "",
      collectionName,
      ruleName,
      direction,
    ]),
    sourceType: "firewall-policy",
    subscriptionId: identity.subscriptionId,
    subscriptionName: subscriptionName(ctx, identity.subscriptionId),
    resourceGroup: identity.resourceGroup,
    location: (firewall ?? policy).location ?? identity.location,
    vnet: placement.vnet,
    subnets: placement.subnets,
    nic: "",
    vmName: "",
    nsgOrFirewallName: firewall?.name ?? "",
    resourceId: firewall?.id ?? policy.id,
    policyName: policy.name,
    collectionGroupName: group.name ?? "",
    collectionGroupPriority: groupPriority,
    collectionName,
    collectionPriority,
    ruleName,
    ruleType,
    direction,
    action,
    priority: groupPriority,
    priorityLabel,
    protocols: protocolInfo.protocols,
    sourceAddresses,
    destinationAddresses,
    sourcePorts,
    destinationPorts,
    translatedAddress,
    translatedPort,
    isDefault: false,
    description,
    raw: { ruleCollectionGroup: group.name, collection: collectionName, rule },
    searchText: "",
  };
  row.searchText = buildSearchText([row]);
  return row;
}

function dedupePorts(values: string[]): string[] {
  return [...new Set(values.map((value) => value.trim()).filter(Boolean))];
}

export function normalizePolicyGroup(
  group: ArmResource,
  policy: ArmResource,
  firewall: ArmResource | null,
  ctx: NormalizeContext,
): RuleRow[] {
  const collections = childProps(group).ruleCollections;
  if (!Array.isArray(collections)) return [];
  const rows: RuleRow[] = [];
  for (const collection of collections) {
    if (!collection || typeof collection !== "object") continue;
    const body = childProps(collection);
    const rules = Array.isArray(body.rules) ? body.rules : [];
    for (const rule of rules) {
      const row = policyRuleRow(group, policy, firewall, collection as Record<string, unknown>, rule, ctx);
      if (row) rows.push(row);
    }
  }
  return rows;
}

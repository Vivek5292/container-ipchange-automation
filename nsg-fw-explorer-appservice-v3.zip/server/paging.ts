export interface PageResult {
  data: unknown;
  skipToken?: string;
}

/** Follow a Resource Graph skipToken until the result set is exhausted. */
export async function queryAllPages(fetchPage: (skipToken?: string) => Promise<PageResult>): Promise<unknown[]> {
  const rows: unknown[] = [];
  const seen = new Set<string>();
  let skipToken: string | undefined;
  do {
    const page = await fetchPage(skipToken);
    if (Array.isArray(page.data)) rows.push(...page.data);
    const next = page.skipToken?.trim();
    if (!next || seen.has(next)) return rows;
    seen.add(next);
    skipToken = next;
  } while (skipToken);
  return rows;
}

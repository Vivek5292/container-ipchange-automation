export type SourceType = "nsg" | "firewall-policy" | "firewall-classic";

export type Direction = "Inbound" | "Outbound" | "n/a";

export type RuleAction = "Allow" | "Deny" | "DNAT";

export type RuleKind = "security" | "default" | "network" | "application" | "nat";

export type SnapshotStatus = "ok" | "partial" | "error";

export type DataSource = "mock" | "azure" | "csv";

/** One searchable row. NSG, firewall policy, and classic firewall rules share this shape. */
export interface RuleRow {
  id: string;
  sourceType: SourceType;
  subscriptionId: string;
  subscriptionName: string;
  resourceGroup: string;
  location: string;
  vnet: string;
  subnets: string[];
  nic: string;
  vmName: string;
  nsgOrFirewallName: string;
  resourceId: string;
  policyName: string;
  collectionGroupName: string;
  collectionGroupPriority: number | null;
  collectionName: string;
  collectionPriority: number | null;
  ruleName: string;
  ruleType: RuleKind;
  direction: Direction;
  action: RuleAction;
  /** NSG rule priority, firewall policy collection-group priority, or classic collection priority. */
  priority: number | null;
  priorityLabel: string;
  protocols: string[];
  sourceAddresses: string[];
  destinationAddresses: string[];
  sourcePorts: string[];
  destinationPorts: string[];
  translatedAddress: string;
  translatedPort: string;
  isDefault: boolean;
  description: string;
  raw: unknown;
  searchText: string;
}

export type RuleListItem = Omit<RuleRow, "raw" | "searchText">;

export interface ArmResource {
  id: string;
  name: string;
  type?: string;
  subscriptionId?: string;
  resourceGroup?: string;
  location?: string;
  properties?: Record<string, unknown>;
}

export interface SubscriptionRef {
  subscriptionId: string;
  name: string;
}

/** Raw inventory, whether it came from Resource Graph, ARM, or fixtures. */
export interface Inventory {
  subscriptions: SubscriptionRef[];
  vnets: ArmResource[];
  nsgs: ArmResource[];
  nics: ArmResource[];
  firewalls: ArmResource[];
  policies: ArmResource[];
  ruleCollectionGroups: ArmResource[];
}

export interface SnapshotStats {
  subscriptions: number;
  nsgs: number;
  firewalls: number;
  policies: number;
  rules: number;
  durationMs: number;
}

export interface CsvLoadIssue {
  file: string;
  row: number;
  message: string;
}

export interface Snapshot {
  version: 1;
  generatedAt: string;
  finishedAt: string;
  source: DataSource;
  status: SnapshotStatus;
  warnings: string[];
  error?: string;
  stats: SnapshotStats;
  rules: RuleRow[];
  /** CSV rows that were not imported. Empty for Azure and mock snapshots. */
  loadIssues?: CsvLoadIssue[];
}

export interface NormalizeContext {
  subscriptionNames: Map<string, string>;
  subnetsById: Map<string, { vnet: string; subnet: string }>;
  nicsById: Map<string, NicRef>;
  nicsByNsgId: Map<string, NicRef[]>;
}

export interface NicRef {
  id: string;
  name: string;
  vmName: string;
  subnetId: string;
  nsgId: string;
}

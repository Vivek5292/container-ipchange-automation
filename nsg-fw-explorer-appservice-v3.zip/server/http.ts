import type { IncomingMessage, ServerResponse } from "node:http";
import { loadConfig } from "./config.ts";
import { importUploadedCsvs } from "./csv-store.ts";
import { rulesToCsv } from "./csv.ts";
import { buildFacets, filterRules, paginate, parseRuleQuery, toListItem, viewOnlyQuery } from "./filter.ts";
import { getRuntime, requestRefresh, statusSnapshot } from "./refresh.ts";
import { readSnapshot } from "./collect.ts";

const MAX_BODY = 8_000_000;

export function sendJson(res: ServerResponse, status: number, body: unknown): void {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "Content-Length": Buffer.byteLength(payload),
  }).end(payload);
}

async function readBody(req: IncomingMessage, res: ServerResponse): Promise<Buffer | null> {
  if (String(req.headers["x-forwarded-proto"] ?? "").split(",")[0].trim() === "http") {
    sendJson(res, 403, { error: "HTTPS is required" });
    return null;
  }
  const chunks: Buffer[] = [];
  let size = 0;
  for await (const chunk of req) {
    const buf = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
    size += buf.length;
    if (size > MAX_BODY) {
      sendJson(res, 413, { error: "Request too large" });
      return null;
    }
    chunks.push(buf);
  }
  return Buffer.concat(chunks);
}

export async function handleApi(req: IncomingMessage, res: ServerResponse, path: string, search: URLSearchParams): Promise<void> {
  if (path === "/api/status" && req.method === "GET") {
    sendJson(res, 200, await statusSnapshot());
    return;
  }
  if (path === "/api/refresh" && req.method === "POST") {
    await readBody(req, res);
    const result = await requestRefresh("manual");
    sendJson(res, result.code, result.status);
    return;
  }
  if (path === "/api/rules" && req.method === "GET") {
    const snapshot = await readSnapshot();
    const query = parseRuleQuery(search);
    const matched = filterRules(snapshot.rules, query);
    const scoped = filterRules(snapshot.rules, viewOnlyQuery(query));
    const page = search.get("all") === "1"
      ? { items: matched, page: 1, pageSize: matched.length, total: matched.length, pageCount: matched.length === 0 ? 0 : 1 }
      : paginate(matched, query.page, query.pageSize);
    sendJson(res, 200, {
      meta: publicMeta(snapshot),
      facets: buildFacets(scoped),
      ...page,
      rules: page.items.map(toListItem),
    });
    return;
  }
  if (path === "/api/rule" && req.method === "GET") {
    const id = search.get("id") ?? "";
    const snapshot = await readSnapshot();
    const rule = snapshot.rules.find((item) => item.id === id);
    if (!rule) {
      sendJson(res, 404, { error: "Rule not found" });
      return;
    }
    sendJson(res, 200, { rule });
    return;
  }
  if (path === "/api/export" && req.method === "GET") {
    const snapshot = await readSnapshot();
    const query = parseRuleQuery(search);
    const matched = filterRules(snapshot.rules, query);
    const view = query.view === "firewall" ? "firewall" : "nsg";
    const csv = rulesToCsv(matched, view);
    res.writeHead(200, {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": "attachment; filename=\"nsg-firewall-rules.csv\"",
      "Cache-Control": "no-store",
      "Content-Length": Buffer.byteLength(csv),
    }).end(csv);
    return;
  }
  if (path === "/api/upload" && req.method === "POST") {
    const config = loadConfig();
    if (config.dataSource !== "csv") {
      sendJson(res, 404, { error: "CSV upload is only available in the local build." });
      return;
    }
    const body = await readBody(req, res);
    if (!body) return;
    let parsed: { files?: { name?: string; text?: string }[] };
    try {
      parsed = JSON.parse(body.toString("utf8")) as { files?: { name?: string; text?: string }[] };
    } catch {
      sendJson(res, 400, { error: "Send JSON { files: [{ name, text }] }" });
      return;
    }
    const files = (parsed.files ?? []).flatMap((file) => {
      if (!file || typeof file.name !== "string" || typeof file.text !== "string") return [];
      return [{ name: file.name, text: file.text }];
    });
    if (files.length === 0) {
      sendJson(res, 400, { error: "Choose at least one CSV file." });
      return;
    }
    const runtime = getRuntime();
    const result = await importUploadedCsvs(runtime.store, files);
    sendJson(res, 200, { ok: true, rules: result.snapshot.stats.rules, issues: result.issues });
    return;
  }
  sendJson(res, 404, { error: "Not found" });
}

function publicMeta(snapshot: Awaited<ReturnType<typeof readSnapshot>>) {
  return {
    generatedAt: snapshot.generatedAt,
    finishedAt: snapshot.finishedAt,
    status: snapshot.status,
    source: snapshot.source,
    error: snapshot.error ?? null,
    warnings: snapshot.warnings,
    stats: snapshot.stats,
    loadIssues: snapshot.loadIssues ?? [],
  };
}

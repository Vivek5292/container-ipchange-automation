import type { AppConfig } from "./config.ts";
import { isRecord } from "./arm.ts";
import { queryAllPages } from "./paging.ts";
import { resolveRuleCollectionGroups } from "./rule-groups.ts";
import { ARM_RESOURCE, accessToken } from "./identity.ts";
import type { ArmResource, Inventory, SubscriptionRef } from "./types.ts";

const NSG_QUERY = `Resources
| where type =~ 'microsoft.network/networksecuritygroups'
| project id, name, type, subscriptionId, resourceGroup, location, properties`;

const NIC_QUERY = `Resources
| where type =~ 'microsoft.network/networkinterfaces'
| project id, name, type, subscriptionId, resourceGroup, location, properties`;

const VNET_QUERY = `Resources
| where type =~ 'microsoft.network/virtualnetworks'
| project id, name, type, subscriptionId, resourceGroup, location, properties`;

const FIREWALL_QUERY = `Resources
| where type =~ 'microsoft.network/azurefirewalls'
| project id, name, type, subscriptionId, resourceGroup, location, properties`;

const POLICY_QUERY = `Resources
| where type =~ 'microsoft.network/firewallpolicies'
| project id, name, type, subscriptionId, resourceGroup, location, properties`;

const GROUP_QUERY = `Resources
| where type =~ 'microsoft.network/firewallpolicies/rulecollectiongroups'
| project id, name, type, subscriptionId, resourceGroup, location, properties`;

const SUBSCRIPTION_QUERY = `ResourceContainers
| where type =~ 'microsoft.resources/subscriptions'
| project subscriptionId, name = tostring(properties.displayName)`;

const GRAPH_URL = `${ARM_RESOURCE}/providers/Microsoft.ResourceGraph/resources?api-version=2022-10-01`;
const ARM_API = "2024-05-01";

export interface GraphScope {
  subscriptions?: string[];
  managementGroups?: string[];
}

export interface AzureScopeChoice {
  scope: GraphScope;
  subscriptions: SubscriptionRef[];
  warnings: string[];
}

/**
 * Subscription ids win. A management group is next. With neither, use every
 * subscription the identity can see. An empty result is a warning, not an error.
 */
export function selectAzureScope(input: {
  subscriptionIds: string[];
  managementGroupId: string;
  listed: SubscriptionRef[] | null;
  discovered: SubscriptionRef[] | null;
  listError?: string;
}): AzureScopeChoice {
  const warnings: string[] = [];
  if (input.listError) warnings.push(`Listing subscriptions failed: ${input.listError}`);
  if (input.subscriptionIds.length > 0) {
    return { scope: { subscriptions: input.subscriptionIds }, subscriptions: input.listed ?? [], warnings };
  }
  if (input.managementGroupId) {
    return {
      scope: { managementGroups: [input.managementGroupId] },
      subscriptions: input.listed ?? input.discovered ?? [],
      warnings,
    };
  }
  const found = input.listed && input.listed.length > 0 ? input.listed : input.discovered;
  if (found && found.length > 0) {
    const via = input.listed && input.listed.length > 0 ? "the subscription list" : "a tenant Resource Graph query";
    warnings.push(`No subscription or management group was configured. Querying ${found.length} subscriptions from ${via}.`);
    return {
      scope: { subscriptions: found.map((subscription) => subscription.subscriptionId) },
      subscriptions: found,
      warnings,
    };
  }
  warnings.push("No accessible subscriptions were found. Set AZURE_SUBSCRIPTION_IDS or AZURE_MANAGEMENT_GROUP_ID, or grant the identity Reader.");
  return { scope: {}, subscriptions: [], warnings };
}

export interface AzureDependencies {
  listSubscriptions: () => Promise<SubscriptionRef[]>;
  discoverSubscriptions: () => Promise<SubscriptionRef[]>;
  query: (kql: string, scope: GraphScope) => Promise<unknown[]>;
  listRuleGroups: (policyId: string) => Promise<unknown[]>;
  readResource?: (id: string) => Promise<unknown>;
}

/** Read-only inventory. Lists and GETs only. Never creates, updates, or deletes a network resource. */
export async function loadAzureInventory(config: AppConfig, warnings: string[], dependencies?: AzureDependencies): Promise<Inventory> {
  const choice = await chooseScope(config, warnings, dependencies);
  warnings.push(...choice.warnings);
  if (!choice.scope.subscriptions?.length && !choice.scope.managementGroups?.length) {
    return emptyInventory(choice.subscriptions);
  }
  const deps = dependencies ?? await liveDependencies(warnings);
  return inventoryFromQueries(choice, deps, warnings);
}

async function chooseScope(config: AppConfig, warnings: string[], dependencies?: AzureDependencies): Promise<AzureScopeChoice> {
  if (config.subscriptionIds.length > 0 || config.managementGroupId) {
    return selectAzureScope({
      subscriptionIds: config.subscriptionIds,
      managementGroupId: config.managementGroupId,
      listed: null,
      discovered: null,
    });
  }
  const deps = dependencies ?? await liveDependencies(warnings);
  let listed: SubscriptionRef[] | null = null;
  let listError = "";
  try {
    listed = await deps.listSubscriptions();
  } catch (error) {
    listError = error instanceof Error ? error.message : String(error);
  }
  let discovered: SubscriptionRef[] | null = null;
  if (!listed || listed.length === 0) {
    try {
      discovered = await deps.discoverSubscriptions();
    } catch (error) {
      warnings.push(`Tenant Resource Graph discovery failed: ${error instanceof Error ? error.message : String(error)}`);
    }
  }
  return selectAzureScope({ subscriptionIds: [], managementGroupId: "", listed, discovered, listError });
}

async function liveDependencies(warnings: string[]): Promise<AzureDependencies> {
  return {
    listSubscriptions: listAccessibleSubscriptions,
    discoverSubscriptions: () => discoverSubscriptions(warnings),
    query: (kql, scope) => queryGraph(kql, scope, warnings),
    listRuleGroups: (policyId) => listPolicyRuleCollectionGroups(policyId),
    readResource: readArmResource,
  };
}

async function inventoryFromQueries(choice: AzureScopeChoice, deps: AzureDependencies, warnings: string[]): Promise<Inventory> {
  const scope = choice.scope;
  const query = (kql: string) => deps.query(kql, scope);
  const [subscriptionRows, vnetRows, nsgRows, nicRows, firewallRows, policyRows, graphGroups] = await Promise.all([
    query(SUBSCRIPTION_QUERY),
    query(VNET_QUERY),
    query(NSG_QUERY),
    query(NIC_QUERY),
    query(FIREWALL_QUERY),
    query(POLICY_QUERY),
    query(GROUP_QUERY),
  ]);
  let nsgs = nsgRows.filter(isArmResource);
  if (deps.readResource) nsgs = await fillNsgDetails(nsgs, deps.readResource, warnings);
  const policies = policyRows.filter(isArmResource);
  const resolved = await resolveRuleCollectionGroups(
    graphGroups,
    policies.map((policy) => policy.id),
    deps.listRuleGroups,
  );
  warnings.push(...resolved.warnings);
  return {
    subscriptions: mergeSubscriptions(choice.scope.subscriptions ?? choice.subscriptions.map((item) => item.subscriptionId), subscriptionRows),
    vnets: vnetRows.filter(isArmResource),
    nsgs,
    nics: nicRows.filter(isArmResource),
    firewalls: firewallRows.filter(isArmResource),
    policies,
    ruleCollectionGroups: resolved.groups.filter(isArmResource),
  };
}

function nsgNeedsDetail(nsg: ArmResource): boolean {
  const props = nsg.properties ?? {};
  return !Array.isArray(props.securityRules) && !Array.isArray(props.defaultSecurityRules);
}

async function fillNsgDetails(nsgs: ArmResource[], readResource: (id: string) => Promise<unknown>, warnings: string[]): Promise<ArmResource[]> {
  const out: ArmResource[] = [];
  for (const nsg of nsgs) {
    if (!nsgNeedsDetail(nsg)) {
      out.push(nsg);
      continue;
    }
    try {
      const detail = await readResource(nsg.id);
      out.push(isArmResource(detail) ? detail : nsg);
    } catch (error) {
      warnings.push(`Could not read NSG ${nsg.id} from ARM: ${error instanceof Error ? error.message : String(error)}`);
      out.push(nsg);
    }
  }
  return out;
}

function emptyInventory(subscriptions: SubscriptionRef[]): Inventory {
  return { subscriptions, vnets: [], nsgs: [], nics: [], firewalls: [], policies: [], ruleCollectionGroups: [] };
}

export async function armGet(path: string): Promise<unknown> {
  const token = await accessToken(ARM_RESOURCE);
  const url = path.startsWith("http") ? path : `${ARM_RESOURCE}${path.startsWith("/") ? "" : "/"}${path}`;
  const response = await fetch(url, {
    headers: { Authorization: `Bearer ${token}` },
    signal: AbortSignal.timeout(60_000),
  });
  if (!response.ok) throw new Error(`ARM ${response.status} for ${path}`);
  return response.json();
}

async function readArmResource(id: string): Promise<unknown> {
  const path = id.includes("?") ? id : `${id}?api-version=${ARM_API}`;
  return armGet(path);
}

async function listAccessibleSubscriptions(): Promise<SubscriptionRef[]> {
  const found: SubscriptionRef[] = [];
  let path: string | null = "/subscriptions?api-version=2022-12-01";
  while (path) {
    const body = await armGet(path) as { value?: unknown; nextLink?: string };
    if (Array.isArray(body.value)) {
      for (const row of body.value) {
        if (!isRecord(row) || typeof row.subscriptionId !== "string") continue;
        const name = typeof row.displayName === "string" && row.displayName ? row.displayName : row.subscriptionId;
        found.push({ subscriptionId: row.subscriptionId, name });
      }
    }
    path = typeof body.nextLink === "string" && body.nextLink ? body.nextLink : null;
  }
  return found;
}

async function discoverSubscriptions(warnings: string[]): Promise<SubscriptionRef[]> {
  const rows = await queryGraph(SUBSCRIPTION_QUERY, {}, warnings);
  return rows.flatMap((row) => {
    if (!isRecord(row) || typeof row.subscriptionId !== "string") return [];
    const name = typeof row.name === "string" && row.name ? row.name : row.subscriptionId;
    return [{ subscriptionId: row.subscriptionId, name }];
  });
}

async function queryGraph(kql: string, scope: GraphScope, warnings: string[]): Promise<unknown[]> {
  try {
    return await queryAllPages(async (skipToken) => {
      const options: Record<string, unknown> = { $top: 1000, resultFormat: "objectArray", allowPartialScopes: true };
      if (skipToken) options.$skipToken = skipToken;
      const payload: Record<string, unknown> = { query: kql, options };
      if (scope.subscriptions?.length) payload.subscriptions = scope.subscriptions;
      if (scope.managementGroups?.length) payload.managementGroups = scope.managementGroups;
      const token = await accessToken(ARM_RESOURCE);
      const response = await fetch(GRAPH_URL, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(60_000),
      });
      if (!response.ok) throw new Error(`Resource Graph ${response.status}`);
      const body = await response.json() as { data?: unknown; skipToken?: string; $skipToken?: string };
      const next = body.$skipToken || body.skipToken;
      return { data: body.data, skipToken: typeof next === "string" ? next : undefined };
    });
  } catch (error) {
    warnings.push(`Resource Graph query failed: ${error instanceof Error ? error.message : String(error)}`);
    return [];
  }
}

async function listPolicyRuleCollectionGroups(policyId: string): Promise<unknown[]> {
  const groups: unknown[] = [];
  let path: string | null = `${policyId}/ruleCollectionGroups?api-version=${ARM_API}`;
  while (path) {
    const body = await armGet(path) as { value?: unknown; nextLink?: string };
    if (Array.isArray(body.value)) groups.push(...body.value);
    path = typeof body.nextLink === "string" && body.nextLink ? body.nextLink : null;
  }
  return groups;
}

function mergeSubscriptions(ids: string[], rows: unknown[]): SubscriptionRef[] {
  const names = new Map<string, string>();
  for (const row of rows) {
    if (!isRecord(row) || typeof row.subscriptionId !== "string") continue;
    const name = typeof row.name === "string" && row.name ? row.name : row.subscriptionId;
    names.set(row.subscriptionId.toLowerCase(), name);
  }
  const source = ids.length > 0 ? ids : [...names.keys()];
  return source.map((id) => ({ subscriptionId: id, name: names.get(id.toLowerCase()) || id }));
}

function isArmResource(value: unknown): value is ArmResource {
  if (!isRecord(value) || typeof value.id !== "string" || typeof value.name !== "string") return false;
  const props = value.properties;
  return props == null || isRecord(props);
}

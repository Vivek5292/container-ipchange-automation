import type { DataSource } from "./types.ts";

export interface AppConfig {
  dataSource: DataSource;
  subscriptionIds: string[];
  managementGroupId: string;
  snapshotStorageAccountUrl: string;
  snapshotContainer: string;
  localSnapshotDir: string;
}

function env(name: string): string {
  const value = process.env[name];
  return typeof value === "string" ? value.trim() : "";
}

/** Explicit azure|mock|csv wins. On App Service, WEBSITE_SITE_NAME means Azure. Otherwise CSV. */
export function resolveDataSource(): DataSource {
  const value = env("DATA_SOURCE").toLowerCase();
  if (value === "azure" || value === "mock" || value === "csv") return value;
  if (env("WEBSITE_SITE_NAME")) return "azure";
  return "csv";
}

export function loadConfig(): AppConfig {
  const url = env("SNAPSHOT_STORAGE_ACCOUNT_URL").replace(/\/+$/, "");
  return {
    dataSource: resolveDataSource(),
    subscriptionIds: env("AZURE_SUBSCRIPTION_IDS").split(/[,;\s]+/).map((id) => id.trim()).filter(Boolean),
    managementGroupId: env("AZURE_MANAGEMENT_GROUP_ID"),
    snapshotStorageAccountUrl: url,
    snapshotContainer: env("SNAPSHOT_CONTAINER") || "nsg-firewall-snapshots",
    localSnapshotDir: env("LOCAL_SNAPSHOT_DIR") || "data/snapshots",
  };
}

import type { AppConfig } from "./config.ts";
import { loadConfig } from "./config.ts";
import { loadAzureInventory } from "./azure.ts";
import { BlobSnapshotStore } from "./blob-store.ts";
import { ensureCsvSnapshot } from "./csv-store.ts";
import { LocalSnapshotStore } from "./local-store.ts";
import { loadMockInventory } from "./mock.ts";
import { normalizeInventory } from "./normalize/inventory.ts";
import type { SnapshotStore } from "./store.ts";
import type { DataSource, Snapshot } from "./types.ts";

const FOUR_HOURS = 4 * 60 * 60 * 1000;

export function openStore(config: AppConfig = loadConfig()): SnapshotStore {
  if (config.snapshotStorageAccountUrl) return new BlobSnapshotStore(config.snapshotStorageAccountUrl, config.snapshotContainer);
  return new LocalSnapshotStore(config.localSnapshotDir);
}

export async function collectSnapshot(config: AppConfig = loadConfig()): Promise<Snapshot> {
  const started = Date.now();
  const generatedAt = new Date(started).toISOString();
  const warnings: string[] = [];
  const source: DataSource = config.dataSource;
  try {
    if (source === "csv") return ensureCsvSnapshot(openStore(config));
    const inventory = source === "azure" ? await loadAzureInventory(config, warnings) : await loadMockInventory();
    if (source === "azure" && !config.snapshotStorageAccountUrl) {
      warnings.push("SNAPSHOT_STORAGE_ACCOUNT_URL is empty. The snapshot was written next to the app and is not shared across instances.");
    }
    const rules = normalizeInventory(inventory);
    const finished = Date.now();
    return {
      version: 1,
      generatedAt,
      finishedAt: new Date(finished).toISOString(),
      source,
      status: warnings.length > 0 ? "partial" : "ok",
      warnings,
      stats: {
        subscriptions: inventory.subscriptions.length,
        nsgs: inventory.nsgs.length,
        firewalls: inventory.firewalls.length,
        policies: inventory.policies.length,
        rules: rules.length,
        durationMs: finished - started,
      },
      rules,
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    const finished = Date.now();
    return {
      version: 1,
      generatedAt,
      finishedAt: new Date(finished).toISOString(),
      source,
      status: "error",
      warnings,
      error: message,
      stats: { subscriptions: 0, nsgs: 0, firewalls: 0, policies: 0, rules: 0, durationMs: finished - started },
      rules: [],
    };
  }
}

export function emptySnapshot(source: DataSource, message: string): Snapshot {
  const now = new Date().toISOString();
  return {
    version: 1,
    generatedAt: now,
    finishedAt: now,
    source,
    status: "error",
    warnings: [message],
    error: message,
    stats: { subscriptions: 0, nsgs: 0, firewalls: 0, policies: 0, rules: 0, durationMs: 0 },
    rules: [],
  };
}

/** Read the snapshot for the page. Storage failures become an empty snapshot and never throw. */
export async function readSnapshot(config: AppConfig = loadConfig(), store: SnapshotStore = openStore(config)): Promise<Snapshot> {
  if (config.dataSource === "csv") {
    try {
      return await ensureCsvSnapshot(store);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Could not read the local CSV snapshot.";
      return emptySnapshot("csv", message);
    }
  }
  try {
    const existing = await store.readLatest();
    if (existing) return existing;
    return emptySnapshot(config.dataSource, "No snapshot yet. The collector has not written one, or snapshot storage could not be read. Azure network resources were not changed.");
  } catch (error) {
    const message = error instanceof Error ? error.message : "Could not read the snapshot.";
    return emptySnapshot(config.dataSource, `Snapshot storage could not be read. ${message}`);
  }
}

export function isStale(snapshot: Snapshot | null, now = Date.now()): boolean {
  if (!snapshot || snapshot.status === "error" || snapshot.rules.length === 0) return true;
  const generated = Date.parse(snapshot.generatedAt);
  if (!Number.isFinite(generated)) return true;
  return now - generated >= FOUR_HOURS;
}

/**
 * Write the new snapshot unless the run failed and a good snapshot is already stored.
 * A failed run never replaces a good snapshot.
 */
export async function writeIfBetter(store: SnapshotStore, snapshot: Snapshot): Promise<Snapshot> {
  const failed = snapshot.status === "error" || (snapshot.rules.length === 0 && snapshot.warnings.length > 0);
  if (failed) {
    try {
      const current = await store.readLatest();
      if (current && current.rules.length > 0 && current.status !== "error") {
        console.error(`[refresh] collection failed and the previous snapshot was kept: ${snapshot.error ?? snapshot.warnings[0] ?? "no rules"}`);
        return current;
      }
    } catch (error) {
      console.error(`[refresh] could not read the previous snapshot: ${error instanceof Error ? error.message : error}`);
    }
  }
  await store.write(snapshot);
  console.log(`[refresh] ${snapshot.status} ${snapshot.stats.rules} rules in ${snapshot.stats.durationMs}ms`);
  return snapshot;
}

export const REFRESH_INTERVAL_MS = FOUR_HOURS;

// App Service process: static Vite build plus JSON APIs. Zero npm dependencies.
// Listens on process.env.PORT with no host (all interfaces). App Service terminates TLS on 443
// and forwards plain HTTP to that port. Do not set WEBSITES_PORT or a port in app settings.
import { createServer } from "node:http";
import { existsSync, readdirSync, readFileSync, statSync } from "node:fs";
import { createHash } from "node:crypto";
import { brotliCompressSync, gzipSync, constants as zc } from "node:zlib";
import { extname, join, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";
import { handleApi, sendJson } from "./server/http.ts";
import { startScheduler } from "./server/refresh.ts";

const here = fileURLToPath(new URL(".", import.meta.url));
const ROOT = resolve(process.env.STATIC_DIR ?? join(here, "dist"));

const TYPES = {
  ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".mjs": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8", ".json": "application/json; charset=utf-8", ".svg": "image/svg+xml",
  ".png": "image/png", ".jpg": "image/jpeg", ".webp": "image/webp", ".ico": "image/x-icon",
  ".woff2": "font/woff2", ".txt": "text/plain; charset=utf-8", ".map": "application/json; charset=utf-8",
};
const COMPRESSIBLE = new Set([".html", ".js", ".mjs", ".css", ".json", ".svg", ".txt", ".map"]);

export const SECURITY_HEADERS = {
  "Content-Security-Policy": [
    "default-src 'self'",
    "script-src 'self'",
    "style-src 'self' 'unsafe-inline'",
    "img-src 'self' data: blob:",
    "font-src 'self' data:",
    "connect-src 'self'",
    "object-src 'none'",
    "base-uri 'self'",
    "form-action 'self'",
    "frame-ancestors 'none'",
  ].join("; "),
  "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
  "X-Content-Type-Options": "nosniff",
  "X-Frame-Options": "DENY",
  "Referrer-Policy": "no-referrer",
  "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
};

function loadFiles(root) {
  const files = new Map();
  const walk = (dir) => {
    for (const name of readdirSync(dir)) {
      const full = join(dir, name);
      if (statSync(full).isDirectory()) { walk(full); continue; }
      const ext = extname(name).toLowerCase();
      const body = readFileSync(full);
      const url = "/" + full.slice(root.length + 1).split(sep).join("/");
      const zip = COMPRESSIBLE.has(ext) && body.length > 1024;
      files.set(url, {
        body,
        type: TYPES[ext] ?? "application/octet-stream",
        etag: `"${createHash("sha1").update(body).digest("base64url")}"`,
        gzip: zip ? gzipSync(body, { level: 9 }) : null,
        br: zip ? brotliCompressSync(body, { params: { [zc.BROTLI_PARAM_QUALITY]: 11 } }) : null,
        immutable: url.startsWith("/assets/"),
      });
    }
  };
  try { walk(root); } catch { /* no build yet: API still answers */ }
  return files;
}

export function createApp(root = ROOT) {
  const files = loadFiles(existsSync(root) ? root : ROOT);
  return createServer((req, res) => {
    for (const [key, value] of Object.entries(SECURITY_HEADERS)) res.setHeader(key, value);
    const url = (() => { try { return new URL(req.url ?? "/", "http://localhost"); } catch { return null; } })();
    if (!url) { res.writeHead(400).end("Bad request"); return; }
    const path = url.pathname;
    if (path.includes("\0")) { res.writeHead(400).end("Bad request"); return; }
    if (path === "/healthz") {
      res.writeHead(200, { "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "no-store" }).end("ok");
      return;
    }
    if (path.startsWith("/api/")) {
      handleApi(req, res, path, url.searchParams).catch((error) => {
        console.error(error instanceof Error ? error.message : error);
        if (!res.headersSent) sendJson(res, 500, { error: "Internal error" });
      });
      return;
    }
    if (req.method !== "GET" && req.method !== "HEAD") { res.writeHead(405, { Allow: "GET, HEAD" }).end(); return; }
    let file = files.get(path === "/" ? "/index.html" : path);
    if (!file && !files.has("/index.html")) {
      res.writeHead(200, { "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "no-store" }).end("NSG & Firewall rules. Build the UI with npm run build.");
      return;
    }
    if (!file) {
      if (path.startsWith("/assets/") || extname(path)) { res.writeHead(404, { "Content-Type": "text/plain" }).end("Not found"); return; }
      file = files.get("/index.html");
    }
    const headers = {
      "Content-Type": file.type,
      "Cache-Control": file.immutable ? "public, max-age=31536000, immutable" : "no-cache",
      ETag: file.etag,
      Vary: "Accept-Encoding",
    };
    if (req.headers["if-none-match"] === file.etag) { res.writeHead(304, headers).end(); return; }
    const accept = String(req.headers["accept-encoding"] ?? "");
    let body = file.body;
    if (file.br && /\bbr\b/.test(accept)) { body = file.br; headers["Content-Encoding"] = "br"; }
    else if (file.gzip && /\bgzip\b/.test(accept)) { body = file.gzip; headers["Content-Encoding"] = "gzip"; }
    headers["Content-Length"] = body.length;
    res.writeHead(200, headers);
    res.end(req.method === "HEAD" ? undefined : body);
  });
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const port = Number(process.env.PORT);
  if (!Number.isInteger(port) || port < 0 || port > 65535) {
    console.error("Set PORT to the port App Service assigns. This process does not pick a port and does not read WEBSITES_PORT.");
    process.exit(1);
  }
  const server = createApp();
  server.listen(port, () => {
    const address = server.address();
    const actual = address && typeof address === "object" ? address.port : port;
    console.log(`NSG & Firewall rules serving ${ROOT} on port ${actual}`);
    startScheduler();
  });
  const stop = () => { server.close(() => process.exit(0)); };
  process.on("SIGTERM", stop);
  process.on("SIGINT", stop);
}

import type { RuleRow } from "./types.ts";

const COLUMNS: { key: keyof RuleRow | "subnets" | "protocols" | "sourceAddresses" | "destinationAddresses" | "sourcePorts" | "destinationPorts"; header: string }[] = [
  { key: "ruleName", header: "ruleName" },
  { key: "sourceType", header: "sourceType" },
  { key: "subscriptionName", header: "subscriptionName" },
  { key: "subscriptionId", header: "subscriptionId" },
  { key: "resourceGroup", header: "resourceGroup" },
  { key: "location", header: "location" },
  { key: "vnet", header: "vnet" },
  { key: "subnets", header: "subnets" },
  { key: "nic", header: "nic" },
  { key: "vmName", header: "vmName" },
  { key: "nsgOrFirewallName", header: "nsgOrFirewallName" },
  { key: "policyName", header: "policyName" },
  { key: "collectionGroupName", header: "collectionGroupName" },
  { key: "collectionGroupPriority", header: "collectionGroupPriority" },
  { key: "collectionName", header: "collectionName" },
  { key: "collectionPriority", header: "collectionPriority" },
  { key: "ruleType", header: "ruleType" },
  { key: "direction", header: "direction" },
  { key: "action", header: "action" },
  { key: "priority", header: "priority" },
  { key: "priorityLabel", header: "priorityLabel" },
  { key: "protocols", header: "protocols" },
  { key: "sourceAddresses", header: "sourceAddresses" },
  { key: "destinationAddresses", header: "destinationAddresses" },
  { key: "sourcePorts", header: "sourcePorts" },
  { key: "destinationPorts", header: "destinationPorts" },
  { key: "translatedAddress", header: "translatedAddress" },
  { key: "translatedPort", header: "translatedPort" },
  { key: "isDefault", header: "isDefault" },
  { key: "description", header: "description" },
  { key: "resourceId", header: "resourceId" },
];

function cell(value: unknown): string {
  if (Array.isArray(value)) return value.join("; ");
  if (value == null) return "";
  if (typeof value === "boolean") return value ? "true" : "false";
  return String(value);
}

function escapeCsv(value: string): string {
  if (/[",\n\r]/.test(value)) return `"${value.replaceAll('"', '""')}"`;
  return value;
}

export function rulesToCsv(rules: RuleRow[]): string {
  const headers = [...COLUMNS.map((column) => column.header), "raw"];
  const lines = [headers.join(",")];
  for (const rule of rules) {
    const values = COLUMNS.map((column) => escapeCsv(cell(rule[column.key as keyof RuleRow])));
    values.push(escapeCsv(JSON.stringify(rule.raw)));
    lines.push(values.join(","));
  }
  return `\uFEFF${lines.join("\n")}\n`;
}

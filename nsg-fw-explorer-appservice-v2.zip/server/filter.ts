import type { RuleListItem, RuleRow } from "./types.ts";

export interface RuleQuery {
  q: string;
  subscriptionId: string;
  vnet: string;
  subnet: string;
  target: string;
  direction: string;
  action: string;
  protocol: string;
  port: string;
  priorityMin: number | null;
  priorityMax: number | null;
  source: string;
  destination: string;
  page: number;
  pageSize: number;
  sort: string;
  sortDir: "asc" | "desc";
  /** "" shows every rule. "nsg" and "firewall" are the two views. */
  view: string;
}

export interface FacetOption {
  /** Value sent to the filter. */
  id: string;
  /** Unique key for the option list. */
  key: string;
  label: string;
  subscriptionId?: string;
  vnet?: string;
}

export interface Facets {
  subscriptions: FacetOption[];
  vnets: FacetOption[];
  subnets: FacetOption[];
  targets: FacetOption[];
  protocols: string[];
  directions: string[];
  actions: string[];
}

const SORT_FIELDS = new Set([
  "ruleName",
  "subscriptionName",
  "vnet",
  "nsgOrFirewallName",
  "direction",
  "action",
  "priority",
  "protocol",
]);

export function parseRuleQuery(params: URLSearchParams): RuleQuery {
  const page = positiveInt(params.get("page"), 1);
  const pageSize = Math.min(positiveInt(params.get("pageSize"), 25), 100);
  const sort = params.get("sort") ?? "priority";
  const sortDir = params.get("sortDir") === "desc" ? "desc" : "asc";
  return {
    q: params.get("q")?.trim() ?? "",
    subscriptionId: params.get("subscriptionId")?.trim() ?? "",
    vnet: params.get("vnet")?.trim() ?? "",
    subnet: params.get("subnet")?.trim() ?? "",
    target: params.get("target")?.trim() ?? "",
    direction: params.get("direction")?.trim() ?? "",
    action: params.get("action")?.trim() ?? "",
    protocol: params.get("protocol")?.trim() ?? "",
    port: params.get("port")?.trim() ?? "",
    priorityMin: optionalNumber(params.get("priorityMin")),
    priorityMax: optionalNumber(params.get("priorityMax")),
    source: params.get("source")?.trim() ?? "",
    destination: params.get("destination")?.trim() ?? "",
    page,
    pageSize,
    sort: SORT_FIELDS.has(sort) ? sort : "priority",
    sortDir,
    view: params.get("view") === "nsg" || params.get("view") === "firewall" ? params.get("view")! : "",
  };
}

export function queryToParams(query: RuleQuery, opts?: { page?: boolean }): URLSearchParams {
  const params = new URLSearchParams();
  const set = (key: string, value: string) => {
    if (value) params.set(key, value);
  };
  set("q", query.q);
  set("subscriptionId", query.subscriptionId);
  set("vnet", query.vnet);
  set("subnet", query.subnet);
  set("target", query.target);
  set("direction", query.direction);
  set("action", query.action);
  set("protocol", query.protocol);
  set("port", query.port);
  set("source", query.source);
  set("destination", query.destination);
  if (query.priorityMin != null) params.set("priorityMin", String(query.priorityMin));
  if (query.priorityMax != null) params.set("priorityMax", String(query.priorityMax));
  if (query.sort !== "priority") params.set("sort", query.sort);
  if (query.sortDir !== "asc") params.set("sortDir", query.sortDir);
  if (query.view === "nsg" || query.view === "firewall") params.set("view", query.view);
  if (opts?.page !== false && query.page > 1) params.set("page", String(query.page));
  if (query.pageSize !== 25) params.set("pageSize", String(query.pageSize));
  return params;
}

function positiveInt(value: string | null, fallback: number): number {
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed < 1) return fallback;
  return parsed;
}

function optionalNumber(value: string | null): number | null {
  if (value == null || value.trim() === "") return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

export function ipv4ToInt(ip: string): number | null {
  const match = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(ip.trim());
  if (!match) return null;
  const parts = match.slice(1).map(Number);
  if (parts.some((part) => part > 255)) return null;
  return (((parts[0] << 24) | (parts[1] << 16) | (parts[2] << 8) | parts[3]) >>> 0);
}

export interface ParsedCidr {
  base: number;
  bits: number;
}

export function parseCidr(value: string): ParsedCidr | null {
  const [address, bitsText] = value.trim().split("/");
  if (!address || bitsText == null || bitsText === "") return null;
  const base = ipv4ToInt(address);
  const bits = Number(bitsText);
  if (base == null || !Number.isInteger(bits) || bits < 0 || bits > 32) return null;
  return { base, bits };
}

export function cidrContains(cidr: ParsedCidr, ip: number): boolean {
  if (cidr.bits === 0) return true;
  const mask = cidr.bits === 32 ? 0xffffffff : (~0 << (32 - cidr.bits)) >>> 0;
  return (ip & mask) === (cidr.base & mask);
}

function tokenMatchesIp(token: string, ip: number): boolean {
  const trimmed = token.trim();
  const lower = trimmed.toLowerCase();
  if (lower === "*" || lower === "any" || lower === "0.0.0.0/0") return true;
  const exact = ipv4ToInt(trimmed);
  if (exact != null) return exact === ip;
  const cidr = parseCidr(trimmed);
  return cidr != null && cidrContains(cidr, ip);
}

export function addressQueryMatches(query: string, addresses: string[]): boolean {
  const needle = query.trim();
  if (!needle) return true;
  const ip = ipv4ToInt(needle);
  if (ip != null) return addresses.some((address) => tokenMatchesIp(address, ip));

  const cidr = parseCidr(needle);
  if (cidr) {
    return addresses.some((address) => {
      if (address.toLowerCase().includes(needle.toLowerCase())) return true;
      const tokenIp = ipv4ToInt(address);
      if (tokenIp != null) return cidrContains(cidr, tokenIp);
      const tokenCidr = parseCidr(address);
      if (!tokenCidr) return false;
      return cidrContains(cidr, tokenCidr.base) || cidrContains(tokenCidr, cidr.base);
    });
  }

  const folded = needle.toLowerCase();
  return addresses.some((address) => address.toLowerCase().includes(folded));
}

export function portListMatches(ports: string[], query: string): boolean {
  const needle = query.trim();
  if (!needle) return true;
  const asNumber = Number(needle);
  const numeric = Number.isInteger(asNumber) && asNumber >= 0 && asNumber <= 65535 && String(asNumber) === needle;
  for (const token of ports) {
    const value = token.trim();
    const lower = value.toLowerCase();
    if (lower === "*" || lower === "any" || value === "0-65535") {
      if (numeric) return true;
    }
    if (numeric && value.includes("-")) {
      const [startText, endText] = value.split("-");
      const start = Number(startText);
      const end = Number(endText);
      if (Number.isFinite(start) && Number.isFinite(end) && asNumber >= Math.min(start, end) && asNumber <= Math.max(start, end)) {
        return true;
      }
    } else if (numeric && Number(value) === asNumber) return true;
    else if (!numeric && lower.includes(needle.toLowerCase())) return true;
  }
  return false;
}

export function ruleMatches(rule: RuleRow, query: RuleQuery): boolean {
  if (query.view === "nsg" && rule.sourceType !== "nsg") return false;
  if (query.view === "firewall" && rule.sourceType === "nsg") return false;
  if (query.q && !rule.searchText.includes(query.q.toLowerCase())) return false;
  if (query.subscriptionId && rule.subscriptionId.toLowerCase() !== query.subscriptionId.toLowerCase()) return false;
  if (query.vnet && rule.vnet !== query.vnet) return false;
  if (query.subnet && !rule.subnets.includes(query.subnet)) return false;
  if (query.target && rule.nsgOrFirewallName !== query.target) return false;
  if (query.direction && rule.direction !== query.direction) return false;
  if (query.action && rule.action !== query.action) return false;
  if (query.protocol && !rule.protocols.some((protocol) => protocol.toLowerCase() === query.protocol.toLowerCase())) return false;
  if (query.port && !portListMatches(rule.destinationPorts, query.port)) return false;
  if (query.priorityMin != null && (rule.priority == null || rule.priority < query.priorityMin)) return false;
  if (query.priorityMax != null && (rule.priority == null || rule.priority > query.priorityMax)) return false;
  if (query.source && !addressQueryMatches(query.source, rule.sourceAddresses)) return false;
  if (query.destination && !addressQueryMatches(query.destination, rule.destinationAddresses)) return false;
  return true;
}

function sortValue(rule: RuleRow, sort: string): string | number {
  if (sort === "priority") return rule.priority ?? Number.POSITIVE_INFINITY;
  if (sort === "protocol") return rule.protocols.join(",");
  const value = rule[sort as keyof RuleRow];
  return typeof value === "string" || typeof value === "number" ? value : "";
}

export function filterRules(rules: RuleRow[], query: RuleQuery): RuleRow[] {
  const matched = rules.filter((rule) => ruleMatches(rule, query));
  const direction = query.sortDir === "desc" ? -1 : 1;
  matched.sort((left, right) => {
    const a = sortValue(left, query.sort);
    const b = sortValue(right, query.sort);
    const compared = typeof a === "number" && typeof b === "number" ? a - b : String(a).localeCompare(String(b));
    if (compared !== 0) return compared * direction;
    return left.ruleName.localeCompare(right.ruleName);
  });
  return matched;
}

export function paginate<T>(items: T[], page: number, pageSize: number): {
  items: T[];
  page: number;
  pageSize: number;
  total: number;
  pageCount: number;
} {
  const total = items.length;
  const pageCount = total === 0 ? 0 : Math.ceil(total / pageSize);
  const safePage = pageCount === 0 ? 1 : Math.min(page, pageCount);
  const start = (safePage - 1) * pageSize;
  return { items: items.slice(start, start + pageSize), page: safePage, pageSize, total, pageCount };
}

export function buildFacets(rules: RuleRow[]): Facets {
  const subscriptions = new Map<string, FacetOption>();
  const vnets = new Map<string, FacetOption>();
  const subnets = new Map<string, FacetOption>();
  const targets = new Map<string, FacetOption>();
  const protocols = new Set<string>();
  for (const rule of rules) {
    if (rule.subscriptionId) {
      subscriptions.set(rule.subscriptionId, {
        id: rule.subscriptionId,
        key: rule.subscriptionId,
        label: rule.subscriptionName || rule.subscriptionId,
      });
    }
    if (rule.vnet) {
      const key = `${rule.subscriptionId}|${rule.vnet}`;
      vnets.set(key, {
        id: rule.vnet,
        key,
        label: rule.vnet,
        subscriptionId: rule.subscriptionId,
      });
    }
    for (const subnet of rule.subnets) {
      const key = `${rule.subscriptionId}|${rule.vnet}|${subnet}`;
      subnets.set(key, {
        id: subnet,
        key,
        label: subnet,
        subscriptionId: rule.subscriptionId,
        vnet: rule.vnet,
      });
    }
    if (rule.nsgOrFirewallName) {
      const key = `${rule.subscriptionId}|${rule.nsgOrFirewallName}`;
      targets.set(key, {
        id: rule.nsgOrFirewallName,
        key,
        label: rule.nsgOrFirewallName,
        subscriptionId: rule.subscriptionId,
      });
    }
    for (const protocol of rule.protocols) protocols.add(protocol);
  }
  const byLabel = (left: FacetOption, right: FacetOption) => left.label.localeCompare(right.label);
  return {
    subscriptions: [...subscriptions.values()].sort(byLabel),
    vnets: [...vnets.values()].sort(byLabel),
    subnets: [...subnets.values()].sort(byLabel),
    targets: [...targets.values()].sort(byLabel),
    protocols: [...protocols].sort(),
    directions: ["Inbound", "Outbound", "n/a"],
    actions: ["Allow", "Deny", "DNAT"],
  };
}

export function toListItem(rule: RuleRow): RuleListItem {
  const copy = { ...rule };
  delete (copy as Partial<RuleRow>).raw;
  delete (copy as Partial<RuleRow>).searchText;
  return copy;
}

#!/usr/bin/env bash
# Creates the deny definition and its assignment at the TENANT ROOT management group
# (effect Audit). INHERIT=1 also creates the optional inherit-from-RG Modify assignment.
# REVIEW ONLY: not run against any tenant or subscription.
#
# RBAC at the tenant root group (no one has access there by default):
#   1. A Global Administrator elevates access (Entra ID > Properties > Access management for
#      Azure resources), which grants User Access Administrator at root "/".
#   2. Assign at /providers/Microsoft.Management/managementGroups/<tenantId>:
#        Resource Policy Contributor -> governance pipeline/group (definitions, assignments,
#        allow-list updates). Only needed extra for INHERIT=1: User Access Administrator or
#        RBAC Administrator limited to Tag Contributor, to grant the Modify identity its role.
#   3. Remove the elevated access afterwards.
set -euo pipefail
cd "$(dirname "$0")"; source ./lib.sh
validate_list

DEF=policy-definition-deny-bau-funded-not-allowlisted.json
az policy definition create --management-group "$TENANT_ID" \
  --name "$(jq -r .name $DEF)" --display-name "$(jq -r .properties.displayName $DEF)" \
  --description "$(jq -r .properties.description $DEF)" --mode Indexed \
  --metadata category=Tags version=1.0.0 \
  --rules "$(jq -c .properties.policyRule $DEF)" --params "$(jq -c .properties.parameters $DEF)"

ASG=policy-assignment-root.json
az policy assignment create --name "$ASSIGNMENT_NAME" --scope "$ROOT_SCOPE" \
  --display-name "$(jq -r .properties.displayName $ASG)" \
  --policy "${ROOT_SCOPE}/providers/Microsoft.Authorization/policyDefinitions/deny-bau-funded-not-allowlisted" \
  --params "$(params_file Audit)" \
  --non-compliance-messages "$(jq -c .properties.nonComplianceMessages $ASG)" \
  --enforcement-mode Default

if [[ "${INHERIT:-0}" == "1" ]]; then
  INH=policy-definition-inherit-project-funding-from-rg.json
  az policy definition create --management-group "$TENANT_ID" \
    --name "$(jq -r .name $INH)" --display-name "$(jq -r .properties.displayName $INH)" \
    --description "$(jq -r .properties.description $INH)" --mode Indexed \
    --rules "$(jq -c .properties.policyRule $INH)" --params "$(jq -c .properties.parameters $INH)"
  az policy assignment create --name inherit-proj-funding --scope "$ROOT_SCOPE" \
    --policy "${ROOT_SCOPE}/providers/Microsoft.Authorization/policyDefinitions/inherit-project-funding-from-rg" \
    --params "$(jq -c .properties.parameters policy-assignment-inherit-root.json)" \
    --mi-system-assigned --location australiaeast \
    --identity-scope "$ROOT_SCOPE" --role "Tag Contributor"
fi

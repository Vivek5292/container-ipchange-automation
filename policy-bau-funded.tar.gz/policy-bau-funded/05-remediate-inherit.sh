#!/usr/bin/env bash
# OPTIONAL: switch the inherit assignment to Modify and stamp existing resources that are
# missing project-funding (max 50,000 resources per remediation task). With the default
# excludedValues = ["bau-funded"], bau-funded is never copied, so no new bau-funded tags
# appear and the allow-list is unaffected. REVIEW ONLY.
set -euo pipefail
cd "$(dirname "$0")"; source ./lib.sh
INH_ID="${ROOT_SCOPE}/providers/Microsoft.Authorization/policyAssignments/inherit-proj-funding"
az policy assignment update --name inherit-proj-funding --scope "$ROOT_SCOPE" \
  --params '{"tagName":{"value":"project-funding"},"effect":{"value":"Modify"},"excludedValues":{"value":["bau-funded"]}}'
az policy remediation create --name "inherit-project-funding-$(date +%Y%m%d)" \
  --management-group "$TENANT_ID" --policy-assignment "$INH_ID" \
  --resource-discovery-mode ReEvaluateCompliance

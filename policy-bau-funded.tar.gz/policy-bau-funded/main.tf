# Terraform (azurerm ~> 4.x) - REVIEW ONLY, not planned or applied anywhere.
# One deny policy, assigned at the TENANT ROOT management group (ID = tenant ID), so it covers
# every subscription including new ones. The allow-list lives in git (allowed-resource-ids.json);
# changing it changes only the assignment parameter, never the definition.
# Identity running this needs Resource Policy Contributor at the tenant root group
# (+ User Access Administrator / RBAC Administrator for Tag Contributor if enable_inherit = true).

variable "tenant_id" {
  description = "Microsoft Entra tenant ID = tenant root management group ID"
  type        = string
}
variable "effect" {
  description = "Audit | Deny | Disabled"
  type        = string
  default     = "Audit"
}
variable "allow_list_file" {
  type    = string
  default = "allowed-resource-ids.json"
}
variable "enable_inherit" {
  description = "Optional Modify policy that copies project-funding from the RG (bau-funded excluded)"
  type        = bool
  default     = false
}
variable "inherit_effect" {
  type    = string
  default = "Audit"
}

data "azurerm_management_group" "root" {
  name = var.tenant_id
}

locals {
  root        = data.azurerm_management_group.root.id
  deny_def    = jsondecode(file("${path.module}/policy-definition-deny-bau-funded-not-allowlisted.json")).properties
  inherit_def = jsondecode(file("${path.module}/policy-definition-inherit-project-funding-from-rg.json")).properties
  asg         = jsondecode(file("${path.module}/policy-assignment-root.json")).properties
  allow_list  = [for id in jsondecode(file("${path.module}/${var.allow_list_file}")) : lower(id)]
}

check "allow_list_size" {
  assert {
    condition     = length(jsonencode(local.allow_list)) < 900000
    error_message = "Allow-list is close to the 1,048,576-byte assignment body limit; split per subscription."
  }
}

resource "azurerm_policy_definition" "deny" {
  name                = "deny-bau-funded-not-allowlisted"
  policy_type         = "Custom"
  mode                = "Indexed"
  display_name        = local.deny_def.displayName
  description         = local.deny_def.description
  management_group_id = local.root
  metadata            = jsonencode(local.deny_def.metadata)
  parameters          = jsonencode(local.deny_def.parameters)
  policy_rule         = jsonencode(local.deny_def.policyRule)
}

resource "azurerm_management_group_policy_assignment" "deny" {
  name                 = "deny-bau-funded" # max 24 characters
  display_name         = local.asg.displayName
  description          = local.asg.description
  management_group_id  = local.root
  policy_definition_id = azurerm_policy_definition.deny.id
  enforce              = true

  parameters = jsonencode({
    tagName            = { value = "project-funding" }
    tagValue           = { value = "bau-funded" }
    allowedResourceIds = { value = local.allow_list }
    effect             = { value = var.effect }
  })

  non_compliance_message {
    content = local.asg.nonComplianceMessages[0].message
  }

  # Pilot: Deny only in Australia Southeast while var.effect = "Audit"
  # overrides {
  #   value = "Deny"
  #   selectors {
  #     kind = "resourceLocation"
  #     in   = ["australiasoutheast"]
  #   }
  # }
}

# ---- Optional: inherit project-funding from the RG (bau-funded is excluded by default) ----
resource "azurerm_policy_definition" "inherit" {
  count               = var.enable_inherit ? 1 : 0
  name                = "inherit-project-funding-from-rg"
  policy_type         = "Custom"
  mode                = "Indexed"
  display_name        = local.inherit_def.displayName
  description         = local.inherit_def.description
  management_group_id = local.root
  metadata            = jsonencode(local.inherit_def.metadata)
  parameters          = jsonencode(local.inherit_def.parameters)
  policy_rule         = jsonencode(local.inherit_def.policyRule)
}

resource "azurerm_management_group_policy_assignment" "inherit" {
  count                = var.enable_inherit ? 1 : 0
  name                 = "inherit-proj-funding"
  management_group_id  = local.root
  policy_definition_id = azurerm_policy_definition.inherit[0].id
  location             = "australiaeast"
  identity {
    type = "SystemAssigned"
  }
  parameters = jsonencode({
    tagName        = { value = "project-funding" }
    effect         = { value = var.inherit_effect }
    excludedValues = { value = ["bau-funded"] }
  })
}

resource "azurerm_role_assignment" "inherit_tag_contributor" {
  count              = var.enable_inherit ? 1 : 0
  scope              = local.root
  role_definition_id = "/providers/Microsoft.Authorization/roleDefinitions/4a9ae827-6dc8-4573-8ac7-8239d42aa03f" # Tag Contributor
  principal_id       = azurerm_management_group_policy_assignment.inherit[0].identity[0].principal_id
}

#!/usr/bin/env bash
# Builds allowed-resource-ids.json from Azure Resource Graph: the UNION of the current file
# and every resource now tagged project-funding = bau-funded. Never drops IDs on its own,
# because deleted resources must stay listed so a recreate with the same ID keeps working.
# Removals happen only by an approved PR. REVIEW ONLY (read-only ARG queries).
set -euo pipefail
cd "$(dirname "$0")"; source ./lib.sh
Q='resources | where isnotempty(tags) | mv-expand tags | extend k = tostring(bag_keys(tags)[0]) | extend v = tostring(tags[k]) | where k =~ "project-funding" and v =~ "bau-funded" | project id = tolower(id)'
tmp=$(mktemp); tok=""
while :; do
  if [[ -z "$tok" ]]; then out=$(az graph query -q "$Q" --management-groups "$TENANT_ID" --first 1000 -o json)
  else out=$(az graph query -q "$Q" --management-groups "$TENANT_ID" --first 1000 --skip-token "$tok" -o json); fi
  jq -r '.data[].id' <<<"$out" >> "$tmp"
  tok=$(jq -r '.skip_token // empty' <<<"$out"); [[ -z "$tok" ]] && break
done
[[ -f "$LIST_FILE" ]] || echo '[]' > "$LIST_FILE"
jq -r '.[]' "$LIST_FILE" >> "$tmp"
sort -u "$tmp" | jq -R . | jq -s . > "${LIST_FILE}.new" && mv "${LIST_FILE}.new" "$LIST_FILE"
validate_list
echo "Review the diff (git diff $LIST_FILE), raise a PR, then run 03-update-allowlist.sh after approval."

#!/usr/bin/env bash
# Pushes allowed-resource-ids.json (from git, after PR approval) into the assignment parameter,
# keeping the current effect. Only the assignment changes; the definition is untouched.
# REVIEW ONLY. Caller needs Resource Policy Contributor at the tenant root group.
set -euo pipefail
cd "$(dirname "$0")"; source ./lib.sh
validate_list
EFFECT=$(az policy assignment show --name "$ASSIGNMENT_NAME" --scope "$ROOT_SCOPE" --query "parameters.effect.value" -o tsv)
az policy assignment update --name "$ASSIGNMENT_NAME" --scope "$ROOT_SCOPE" --params "$(params_file "${EFFECT:-Audit}")"
echo "Updated. Learn: an updated assignment takes about five minutes to apply."

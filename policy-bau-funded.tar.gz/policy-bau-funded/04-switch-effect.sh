#!/usr/bin/env bash
# pilot | deny | audit (rollback) | disable (emergency). REVIEW ONLY.
set -euo pipefail
cd "$(dirname "$0")"; source ./lib.sh
case "${1:?pilot|deny|audit|disable}" in
  pilot)   az policy assignment update --name "$ASSIGNMENT_NAME" --scope "$ROOT_SCOPE" \
             --overrides "$(jq -c . assignment-overrides-deny-pilot.json)" ;;
  deny)    validate_list
           az policy assignment update --name "$ASSIGNMENT_NAME" --scope "$ROOT_SCOPE" \
             --params "$(params_file Deny)" --overrides '[]' ;;
  audit)   validate_list
           az policy assignment update --name "$ASSIGNMENT_NAME" --scope "$ROOT_SCOPE" \
             --params "$(params_file Audit)" --overrides '[]' ;;
  disable) az policy assignment update --name "$ASSIGNMENT_NAME" --scope "$ROOT_SCOPE" --enforcement-mode DoNotEnforce ;;
esac

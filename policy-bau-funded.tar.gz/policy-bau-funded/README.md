# Deny new bau-funded resources (allow-list design) - REVIEW ONLY, nothing deployed

Primary design: ONE Indexed deny policy at the tenant root management group.
Deny when tags['project-funding'] equals 'bau-funded' AND id notIn allowedResourceIds.

| File | What |
|---|---|
| policy-definition-deny-bau-funded-not-allowlisted.json | The deny definition (tagName, tagValue, allowedResourceIds, effect) |
| policy-assignment-root.json | Tenant-root assignment, Audit, nonComplianceMessage (list injected from git) |
| allowed-resource-ids.example.json | Shape of the git-managed allow-list (copy to allowed-resource-ids.json) |
| assignment-overrides-deny-pilot.json | Effect override: Deny in australiasoutheast only |
| inventory-bau-funded.kql | ARG: initial list, near-misses, list size, compliance gate |
| lib.sh | Shared helpers: list validation + size check, parameter file builder |
| 01-create-definitions-and-assignment.sh | Definition + root assignment (INHERIT=1 adds the optional Modify) |
| 02-build-allowlist-from-arg.sh | Union of current list + ARG hits, lower-cased, sorted; never auto-removes |
| 03-update-allowlist.sh | Push the approved list into the assignment parameter (keeps effect) |
| 04-switch-effect.sh | pilot / deny / audit (rollback) / disable |
| 05-remediate-inherit.sh | Optional: Modify + remediation for inherit-from-RG |
| policy-definition-inherit-project-funding-from-rg.json | Optional Modify (bau-funded excluded from inheritance) |
| policy-assignment-inherit-root.json | Optional Modify assignment (system identity, Tag Contributor) |
| main.tf + providers.tf | Terraform azurerm ~> 4.x (terraform validate passes; needs allowed-resource-ids.json) |
| alternatives/policy-exemption-resource.example.json | Compared alternative: per-resource exemption |

Placeholders: {tenantId}, {changeTicket}, {approver}.

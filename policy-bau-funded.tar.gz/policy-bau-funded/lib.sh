# Shared helpers. REVIEW ONLY.
: "${TENANT_ID:?set TENANT_ID (tenant root management group ID = Entra tenant ID)}"
ROOT_SCOPE="/providers/Microsoft.Management/managementGroups/${TENANT_ID}"
ASSIGNMENT_NAME="deny-bau-funded"
LIST_FILE="${LIST_FILE:-$(dirname "$0")/allowed-resource-ids.json}"
MAX_BYTES=900000   # warn well before the documented 1,048,576-byte assignment body limit

validate_list() { # lower-case, sorted, unique, every entry a resource ID
  jq -e 'type=="array" and all(.[]; type=="string" and startswith("/subscriptions/") and . == ascii_downcase)' "$LIST_FILE" >/dev/null \
    || { echo "allow-list invalid: must be an array of lower-case /subscriptions/... IDs" >&2; exit 1; }
  local n b; n=$(jq length "$LIST_FILE"); b=$(jq -c . "$LIST_FILE" | wc -c)
  echo "allow-list: $n IDs, $b bytes"
  (( b < MAX_BYTES )) || { echo "allow-list too large ($b bytes): split per subscription (see Page)" >&2; exit 1; }
}

params_file() { # $1 = effect; writes the full parameters object to a temp file, prints its path
  local f; f=$(mktemp --suffix=.json)
  jq -c --arg e "$1" '{tagName:{value:"project-funding"},tagValue:{value:"bau-funded"},allowedResourceIds:{value:.},effect:{value:$e}}' "$LIST_FILE" > "$f"
  echo "$f"
}

import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { buildInventory, samples } from "./build-inventory";

async function main(): Promise<void> {
  const root = path.join(process.cwd(), "fixtures");
  await mkdir(path.join(root, "samples"), { recursive: true });
  await writeFile(path.join(root, "inventory.json"), `${JSON.stringify(buildInventory(), null, 2)}\n`);
  await writeFile(path.join(root, "samples", "nsg-flat.json"), `${JSON.stringify(samples.flatNsg, null, 2)}\n`);
  await writeFile(path.join(root, "samples", "nsg-plural-and-singular.json"), `${JSON.stringify(samples.bothShapesNsg, null, 2)}\n`);
  await writeFile(path.join(root, "samples", "classic-flat.json"), `${JSON.stringify(samples.flatClassicFirewall, null, 2)}\n`);
  await writeFile(path.join(root, "samples", "rcg-summary.json"), `${JSON.stringify(samples.summaryGroup, null, 2)}\n`);
  console.log("Wrote fixtures/inventory.json and fixtures/samples");
}

void main();

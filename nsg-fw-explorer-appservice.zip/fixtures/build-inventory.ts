import type { ArmResource, Inventory } from "../src/lib/types";

const SUB = {
  hub: "11111111-1111-1111-1111-111111111111",
  apps: "22222222-2222-2222-2222-222222222222",
  nonprod: "33333333-3333-3333-3333-333333333333",
} as const;

function armId(subscription: string, group: string, type: string, name: string): string {
  return `/subscriptions/${subscription}/resourceGroups/${group}/providers/Microsoft.Network/${type}/${name}`;
}

function subnetId(vnet: string, name: string): string {
  return `${vnet}/subnets/${name}`;
}

interface RuleProps {
  protocol?: string;
  sourcePortRange?: string;
  sourcePortRanges?: string[];
  destinationPortRange?: string;
  destinationPortRanges?: string[];
  sourceAddressPrefix?: string;
  sourceAddressPrefixes?: string[];
  destinationAddressPrefix?: string;
  destinationAddressPrefixes?: string[];
  sourceApplicationSecurityGroups?: { id: string }[];
  destinationApplicationSecurityGroups?: { id: string }[];
  access: "Allow" | "Deny";
  priority: number;
  direction: "Inbound" | "Outbound";
  description?: string;
}

function nsgRule(name: string, properties: RuleProps) {
  return { name, properties };
}

function defaultRules() {
  return [
    nsgRule("AllowVNetInBound", {
      protocol: "*",
      sourcePortRange: "*",
      destinationPortRange: "*",
      sourceAddressPrefix: "VirtualNetwork",
      destinationAddressPrefix: "VirtualNetwork",
      access: "Allow",
      priority: 65000,
      direction: "Inbound",
      description: "Allow inbound traffic from all VMs in VNET",
    }),
    nsgRule("AllowAzureLoadBalancerInBound", {
      protocol: "*",
      sourcePortRange: "*",
      destinationPortRange: "*",
      sourceAddressPrefix: "AzureLoadBalancer",
      destinationAddressPrefix: "*",
      access: "Allow",
      priority: 65001,
      direction: "Inbound",
      description: "Allow inbound traffic from azure load balancer",
    }),
    nsgRule("DenyAllInBound", {
      protocol: "*",
      sourcePortRange: "*",
      destinationPortRange: "*",
      sourceAddressPrefix: "*",
      destinationAddressPrefix: "*",
      access: "Deny",
      priority: 65500,
      direction: "Inbound",
      description: "Deny all inbound traffic",
    }),
    nsgRule("AllowVNetOutBound", {
      protocol: "*",
      sourcePortRange: "*",
      destinationPortRange: "*",
      sourceAddressPrefix: "VirtualNetwork",
      destinationAddressPrefix: "VirtualNetwork",
      access: "Allow",
      priority: 65000,
      direction: "Outbound",
      description: "Allow outbound traffic from all VMs to all VMs in VNET",
    }),
    nsgRule("AllowInternetOutBound", {
      protocol: "*",
      sourcePortRange: "*",
      destinationPortRange: "*",
      sourceAddressPrefix: "*",
      destinationAddressPrefix: "Internet",
      access: "Allow",
      priority: 65001,
      direction: "Outbound",
      description: "Allow outbound traffic from all VMs to Internet",
    }),
    nsgRule("DenyAllOutBound", {
      protocol: "*",
      sourcePortRange: "*",
      destinationPortRange: "*",
      sourceAddressPrefix: "*",
      destinationAddressPrefix: "*",
      access: "Deny",
      priority: 65500,
      direction: "Outbound",
      description: "Deny all outbound traffic",
    }),
  ];
}

function nsg(input: {
  subscription: string;
  group: string;
  name: string;
  location: string;
  subnets?: string[];
  nics?: string[];
  rules: ReturnType<typeof nsgRule>[];
}): ArmResource {
  return {
    id: armId(input.subscription, input.group, "networkSecurityGroups", input.name),
    name: input.name,
    type: "microsoft.network/networksecuritygroups",
    subscriptionId: input.subscription,
    resourceGroup: input.group,
    location: input.location,
    properties: {
      securityRules: input.rules,
      defaultSecurityRules: defaultRules(),
      subnets: (input.subnets ?? []).map((id) => ({ id })),
      networkInterfaces: (input.nics ?? []).map((id) => ({ id })),
    },
  };
}

function vnet(input: {
  subscription: string;
  group: string;
  name: string;
  location: string;
  prefix: string;
  subnets: { name: string; prefix: string; nsg?: string }[];
}): ArmResource {
  const id = armId(input.subscription, input.group, "virtualNetworks", input.name);
  return {
    id,
    name: input.name,
    type: "microsoft.network/virtualnetworks",
    subscriptionId: input.subscription,
    resourceGroup: input.group,
    location: input.location,
    properties: {
      addressSpace: { addressPrefixes: [input.prefix] },
      subnets: input.subnets.map((subnet) => ({
        name: subnet.name,
        id: subnetId(id, subnet.name),
        properties: {
          addressPrefix: subnet.prefix,
          ...(subnet.nsg ? { networkSecurityGroup: { id: subnet.nsg } } : {}),
        },
      })),
    },
  };
}

const RG = {
  hub: "rg-hub-eus",
  apps: "rg-spoke-apps",
  platform: "rg-spoke-platform",
  dev: "rg-dev-eus",
  legacy: "rg-legacy-eus",
} as const;

const VNET = {
  hub: armId(SUB.hub, RG.hub, "virtualNetworks", "vnet-hub-eus"),
  apps: armId(SUB.apps, RG.apps, "virtualNetworks", "vnet-spoke-apps"),
  platform: armId(SUB.apps, RG.platform, "virtualNetworks", "vnet-spoke-platform"),
  nonprodHub: armId(SUB.nonprod, RG.dev, "virtualNetworks", "vnet-nonprod-hub"),
  dev: armId(SUB.nonprod, RG.dev, "virtualNetworks", "vnet-dev"),
  legacy: armId(SUB.nonprod, RG.legacy, "virtualNetworks", "vnet-legacy"),
};

const NSG = {
  shared: armId(SUB.hub, RG.hub, "networkSecurityGroups", "nsg-shared"),
  web: armId(SUB.apps, RG.apps, "networkSecurityGroups", "nsg-web"),
  app: armId(SUB.apps, RG.apps, "networkSecurityGroups", "nsg-app"),
  data: armId(SUB.apps, RG.apps, "networkSecurityGroups", "nsg-data"),
  aks: armId(SUB.apps, RG.platform, "networkSecurityGroups", "nsg-aks"),
  ingress: armId(SUB.apps, RG.platform, "networkSecurityGroups", "nsg-ingress"),
  jump: armId(SUB.apps, RG.platform, "networkSecurityGroups", "nsg-jump"),
  dev: armId(SUB.nonprod, RG.dev, "networkSecurityGroups", "nsg-dev"),
  build: armId(SUB.nonprod, RG.dev, "networkSecurityGroups", "nsg-build"),
  legacy: armId(SUB.nonprod, RG.legacy, "networkSecurityGroups", "nsg-legacy"),
};

const NIC_JUMP = armId(SUB.apps, RG.platform, "networkInterfaces", "nic-jump-01");
const ASG_WEB = armId(SUB.apps, RG.apps, "applicationSecurityGroups", "asg-web-clients");
const IPG_ONPREM = armId(SUB.hub, RG.hub, "ipGroups", "ipg-onprem");
const IPG_TOR = armId(SUB.hub, RG.hub, "ipGroups", "ipg-tor-exit");
const POL_HUB = armId(SUB.hub, RG.hub, "firewallPolicies", "pol-hub-eus");
const POL_NONPROD = armId(SUB.nonprod, RG.dev, "firewallPolicies", "pol-nonprod");

function networkCollection(name: string, priority: number, action: "Allow" | "Deny", rules: unknown[]) {
  return {
    name,
    ruleCollectionType: "FirewallPolicyFilterRuleCollection",
    priority,
    action: { type: action },
    rules,
  };
}

function natCollection(name: string, priority: number, rules: unknown[]) {
  return {
    name,
    ruleCollectionType: "FirewallPolicyNatRuleCollection",
    priority,
    action: { type: "DNAT" },
    rules,
  };
}

function networkRule(input: {
  name: string;
  protocols: string[];
  source?: string[];
  destination?: string[];
  ports?: string[];
  sourceIpGroups?: string[];
  destinationIpGroups?: string[];
  destinationFqdns?: string[];
  description?: string;
}) {
  return {
    ruleType: "NetworkRule",
    name: input.name,
    ipProtocols: input.protocols,
    sourceAddresses: input.source ?? [],
    destinationAddresses: input.destination ?? [],
    destinationPorts: input.ports ?? [],
    sourceIpGroups: input.sourceIpGroups ?? [],
    destinationIpGroups: input.destinationIpGroups ?? [],
    destinationFqdns: input.destinationFqdns ?? [],
    description: input.description ?? "",
  };
}

function appRule(input: {
  name: string;
  protocol: string;
  port: number;
  source?: string[];
  fqdns?: string[];
  fqdnTags?: string[];
  sourceIpGroups?: string[];
  description?: string;
}) {
  return {
    ruleType: "ApplicationRule",
    name: input.name,
    protocols: [{ protocolType: input.protocol, port: input.port }],
    sourceAddresses: input.source ?? ["*"],
    targetFqdns: input.fqdns ?? [],
    fqdnTags: input.fqdnTags ?? [],
    sourceIpGroups: input.sourceIpGroups ?? [],
    description: input.description ?? "",
  };
}

function dnatRule(input: {
  name: string;
  source: string[];
  destination: string[];
  port: string;
  translatedAddress: string;
  translatedPort: string;
  description?: string;
}) {
  return {
    ruleType: "NatRule",
    name: input.name,
    ipProtocols: ["TCP"],
    sourceAddresses: input.source,
    destinationAddresses: input.destination,
    destinationPorts: [input.port],
    translatedAddress: input.translatedAddress,
    translatedPort: input.translatedPort,
    description: input.description ?? "",
  };
}

function group(policyId: string, name: string, priority: number, collections: unknown[]): ArmResource {
  return {
    id: `${policyId}/ruleCollectionGroups/${name}`,
    name,
    type: "microsoft.network/firewallpolicies/rulecollectiongroups",
    properties: { priority, ruleCollections: collections },
  };
}

function classicCollection(name: string, priority: number, action: string, rules: unknown[]) {
  return { name, properties: { priority, action: { type: action }, rules } };
}

export function buildInventory(): Inventory {
  const snet = {
    firewallHub: subnetId(VNET.hub, "AzureFirewallSubnet"),
    shared: subnetId(VNET.hub, "snet-shared"),
    dns: subnetId(VNET.hub, "snet-dns"),
    web: subnetId(VNET.apps, "snet-web"),
    app: subnetId(VNET.apps, "snet-app"),
    data: subnetId(VNET.apps, "snet-data"),
    aks: subnetId(VNET.platform, "snet-aks"),
    ingress: subnetId(VNET.platform, "snet-ingress"),
    firewallNonprod: subnetId(VNET.nonprodHub, "AzureFirewallSubnet"),
    dev: subnetId(VNET.dev, "snet-dev"),
    build: subnetId(VNET.dev, "snet-build"),
    firewallLegacy: subnetId(VNET.legacy, "AzureFirewallSubnet"),
    legacy: subnetId(VNET.legacy, "snet-legacy"),
  };

  const nsgs: ArmResource[] = [
    nsg({
      subscription: SUB.hub,
      group: RG.hub,
      name: "nsg-shared",
      location: "eastus",
      subnets: [snet.shared, snet.dns],
      rules: [
        nsgRule("Allow-DNS-UDP", {
          protocol: "Udp",
          sourcePortRange: "*",
          destinationPortRange: "53",
          sourceAddressPrefix: "VirtualNetwork",
          destinationAddressPrefix: "10.0.2.4",
          access: "Allow",
          priority: 100,
          direction: "Inbound",
          description: "Resolvers on the shared subnet.",
        }),
        nsgRule("Allow-DNS-TCP", {
          protocol: "Tcp",
          sourcePortRange: "*",
          destinationPortRange: "53",
          sourceAddressPrefix: "VirtualNetwork",
          destinationAddressPrefix: "10.0.2.4",
          access: "Allow",
          priority: 110,
          direction: "Inbound",
        }),
        nsgRule("Allow-OnPrem-HTTPS", {
          protocol: "Tcp",
          sourcePortRange: "*",
          destinationPortRange: "443",
          sourceAddressPrefix: "192.168.0.0/16",
          destinationAddressPrefix: "*",
          access: "Allow",
          priority: 200,
          direction: "Inbound",
          description: "Corporate WAN into shared services.",
        }),
      ],
    }),
    nsg({
      subscription: SUB.apps,
      group: RG.apps,
      name: "nsg-web",
      location: "eastus",
      subnets: [snet.web],
      rules: [
        nsgRule("Allow-HTTPS-Internet", {
          protocol: "Tcp",
          sourcePortRange: "*",
          destinationPortRange: "443",
          sourceAddressPrefix: "Internet",
          destinationAddressPrefix: "*",
          access: "Allow",
          priority: 100,
          direction: "Inbound",
          description: "Public HTTPS to the web tier.",
        }),
        nsgRule("Allow-HTTP-Gateway", {
          protocol: "Tcp",
          sourcePortRange: "*",
          destinationPortRange: "80",
          sourceAddressPrefix: "GatewayManager",
          destinationAddressPrefix: "*",
          access: "Allow",
          priority: 110,
          direction: "Inbound",
        }),
        nsgRule("Allow-Admin-Prefixes", {
          protocol: "Tcp",
          sourcePortRanges: ["1024-65535"],
          destinationPortRanges: ["22", "3389"],
          sourceAddressPrefixes: ["203.0.113.10/32", "198.51.100.0/24"],
          destinationAddressPrefixes: ["10.1.1.0/24"],
          access: "Allow",
          priority: 300,
          direction: "Inbound",
          description: "Break-glass admin prefixes. Ticket NET-2218.",
        }),
        nsgRule("Allow-From-ASG", {
          protocol: "Tcp",
          sourcePortRange: "*",
          destinationPortRange: "8443",
          sourceApplicationSecurityGroups: [{ id: ASG_WEB }],
          destinationAddressPrefix: "*",
          access: "Allow",
          priority: 320,
          direction: "Inbound",
          description: "Clients in asg-web-clients.",
        }),
        nsgRule("Allow-Web-To-App", {
          protocol: "Tcp",
          sourcePortRange: "*",
          destinationPortRange: "443",
          sourceAddressPrefix: "*",
          destinationAddressPrefix: "10.1.2.0/24",
          access: "Allow",
          priority: 200,
          direction: "Outbound",
        }),
      ],
    }),
    nsg({
      subscription: SUB.apps,
      group: RG.apps,
      name: "nsg-app",
      location: "eastus",
      subnets: [snet.app],
      rules: [
        nsgRule("Allow-From-Web", {
          protocol: "Tcp",
          sourcePortRange: "*",
          destinationPortRanges: ["443", "8443"],
          sourceAddressPrefix: "10.1.1.0/24",
          destinationAddressPrefix: "*",
          access: "Allow",
          priority: 100,
          direction: "Inbound",
        }),
        nsgRule("Allow-Health", {
          protocol: "Tcp",
          sourcePortRange: "*",
          destinationPortRange: "8080",
          sourceAddressPrefix: "AzureLoadBalancer",
          destinationAddressPrefix: "*",
          access: "Allow",
          priority: 110,
          direction: "Inbound",
        }),
        nsgRule("Allow-SQL-Out", {
          protocol: "Tcp",
          sourcePortRange: "*",
          destinationPortRange: "1433",
          sourceAddressPrefix: "*",
          destinationAddressPrefix: "10.1.3.0/24",
          access: "Allow",
          priority: 200,
          direction: "Outbound",
        }),
        nsgRule("Deny-Internet-Out", {
          protocol: "*",
          sourcePortRange: "*",
          destinationPortRange: "*",
          sourceAddressPrefix: "*",
          destinationAddressPrefix: "Internet",
          access: "Deny",
          priority: 4000,
          direction: "Outbound",
          description: "Spoke app subnet cannot egress directly.",
        }),
      ],
    }),
    nsg({
      subscription: SUB.apps,
      group: RG.apps,
      name: "nsg-data",
      location: "eastus",
      subnets: [snet.data],
      rules: [
        nsgRule("Allow-SQL-From-App", {
          protocol: "Tcp",
          sourcePortRange: "*",
          destinationPortRange: "1433",
          sourceAddressPrefix: "10.1.2.0/24",
          destinationAddressPrefix: "10.1.3.0/24",
          access: "Allow",
          priority: 100,
          direction: "Inbound",
          description: "SQL only from the app subnet.",
        }),
        nsgRule("Allow-Postgres", {
          protocol: "Tcp",
          sourcePortRange: "*",
          destinationPortRange: "5432",
          sourceAddressPrefix: "10.1.2.0/24",
          destinationAddressPrefix: "*",
          access: "Allow",
          priority: 110,
          direction: "Inbound",
          description: "PostgreSQL from the app subnet only.",
        }),
        nsgRule("Allow-Storage-Out", {
          protocol: "Tcp",
          sourcePortRange: "*",
          destinationPortRange: "443",
          sourceAddressPrefix: "*",
          destinationAddressPrefix: "Storage",
          access: "Allow",
          priority: 200,
          direction: "Outbound",
        }),
      ],
    }),
    nsg({
      subscription: SUB.apps,
      group: RG.platform,
      name: "nsg-aks",
      location: "eastus",
      subnets: [snet.aks],
      rules: [
        nsgRule("Allow-Node-To-Node", {
          protocol: "*",
          sourcePortRange: "*",
          destinationPortRange: "*",
          sourceAddressPrefix: "10.2.0.0/20",
          destinationAddressPrefix: "10.2.0.0/20",
          access: "Allow",
          priority: 100,
          direction: "Inbound",
        }),
        nsgRule("Allow-Kubelet", {
          protocol: "Tcp",
          sourcePortRange: "*",
          destinationPortRange: "10250",
          sourceAddressPrefix: "10.2.0.0/20",
          destinationAddressPrefix: "*",
          access: "Allow",
          priority: 110,
          direction: "Inbound",
        }),
        nsgRule("Allow-NodePort-TCP", {
          protocol: "Tcp",
          sourcePortRange: "*",
          destinationPortRange: "30000-32767",
          sourceAddressPrefix: "VirtualNetwork",
          destinationAddressPrefix: "*",
          access: "Allow",
          priority: 120,
          direction: "Inbound",
        }),
        nsgRule("Allow-NodePort-UDP", {
          protocol: "Udp",
          sourcePortRange: "*",
          destinationPortRange: "30000-32767",
          sourceAddressPrefix: "VirtualNetwork",
          destinationAddressPrefix: "*",
          access: "Allow",
          priority: 130,
          direction: "Inbound",
        }),
        nsgRule("Allow-AKS-API", {
          protocol: "Tcp",
          sourcePortRange: "*",
          destinationPortRange: "443",
          sourceAddressPrefix: "*",
          destinationAddressPrefix: "AzureCloud.eastus",
          access: "Allow",
          priority: 200,
          direction: "Outbound",
        }),
        nsgRule("Allow-Control-Plane", {
          protocol: "Tcp",
          sourcePortRange: "*",
          destinationPortRange: "443",
          sourceAddressPrefix: "*",
          destinationAddressPrefix: "10.2.16.4/32",
          access: "Allow",
          priority: 210,
          direction: "Outbound",
        }),
      ],
    }),
    nsg({
      subscription: SUB.apps,
      group: RG.platform,
      name: "nsg-ingress",
      location: "eastus",
      subnets: [snet.ingress],
      rules: [
        nsgRule("Allow-HTTPS-Ingress", {
          protocol: "Tcp",
          sourcePortRange: "*",
          destinationPortRange: "443",
          sourceAddressPrefix: "Internet",
          destinationAddressPrefix: "10.2.16.10",
          access: "Allow",
          priority: 100,
          direction: "Inbound",
        }),
        nsgRule("Allow-AzureLB", {
          protocol: "*",
          sourcePortRange: "*",
          destinationPortRange: "*",
          sourceAddressPrefix: "AzureLoadBalancer",
          destinationAddressPrefix: "*",
          access: "Allow",
          priority: 110,
          direction: "Inbound",
        }),
      ],
    }),
    nsg({
      subscription: SUB.apps,
      group: RG.platform,
      name: "nsg-jump",
      location: "eastus",
      nics: [NIC_JUMP],
      rules: [
        nsgRule("Allow-SSH-Corp", {
          protocol: "Tcp",
          sourcePortRange: "*",
          destinationPortRange: "22",
          sourceAddressPrefix: "203.0.113.0/24",
          destinationAddressPrefix: "*",
          access: "Allow",
          priority: 100,
          direction: "Inbound",
          description: "Break-glass SSH from the corporate NAT. Ticket NET-1042.",
        }),
        nsgRule("Allow-RDP-Corp", {
          protocol: "Tcp",
          sourcePortRange: "*",
          destinationPortRange: "3389",
          sourceAddressPrefix: "203.0.113.0/24",
          destinationAddressPrefix: "*",
          access: "Allow",
          priority: 110,
          direction: "Inbound",
          description: "Break-glass RDP from the corporate NAT.",
        }),
        nsgRule("Allow-Jump-HTTPS", {
          protocol: "Tcp",
          sourcePortRange: "*",
          destinationPortRange: "443",
          sourceAddressPrefix: "*",
          destinationAddressPrefix: "Internet",
          access: "Allow",
          priority: 200,
          direction: "Outbound",
        }),
      ],
    }),
    nsg({
      subscription: SUB.nonprod,
      group: RG.dev,
      name: "nsg-dev",
      location: "eastus2",
      subnets: [snet.dev],
      rules: [
        nsgRule("Allow-SSH-Any", {
          protocol: "Tcp",
          sourcePortRange: "*",
          destinationPortRange: "22",
          sourceAddressPrefix: "*",
          destinationAddressPrefix: "*",
          access: "Allow",
          priority: 100,
          direction: "Inbound",
          description: "Non-production only. Do not copy to production.",
        }),
        nsgRule("Allow-HTTP-Dev", {
          protocol: "Tcp",
          sourcePortRange: "*",
          destinationPortRange: "80",
          sourceAddressPrefix: "*",
          destinationAddressPrefix: "*",
          access: "Allow",
          priority: 110,
          direction: "Inbound",
        }),
        nsgRule("Allow-HTTPS-Dev", {
          protocol: "Tcp",
          sourcePortRange: "*",
          destinationPortRange: "443",
          sourceAddressPrefix: "*",
          destinationAddressPrefix: "*",
          access: "Allow",
          priority: 120,
          direction: "Inbound",
        }),
        nsgRule("Allow-Dev-To-Build", {
          protocol: "Tcp",
          sourcePortRange: "*",
          destinationPortRange: "22",
          sourceAddressPrefix: "*",
          destinationAddressPrefix: "10.8.2.0/24",
          access: "Allow",
          priority: 200,
          direction: "Outbound",
        }),
      ],
    }),
    nsg({
      subscription: SUB.nonprod,
      group: RG.dev,
      name: "nsg-build",
      location: "eastus2",
      subnets: [snet.build],
      rules: [
        nsgRule("Allow-SSH-From-Dev", {
          protocol: "Tcp",
          sourcePortRange: "*",
          destinationPortRange: "22",
          sourceAddressPrefix: "10.8.1.0/24",
          destinationAddressPrefix: "*",
          access: "Allow",
          priority: 100,
          direction: "Inbound",
        }),
        nsgRule("Allow-Agent-Out", {
          protocol: "Tcp",
          sourcePortRange: "*",
          destinationPortRange: "443",
          sourceAddressPrefix: "*",
          destinationAddressPrefix: "Internet",
          access: "Allow",
          priority: 100,
          direction: "Outbound",
        }),
      ],
    }),
    nsg({
      subscription: SUB.nonprod,
      group: RG.legacy,
      name: "nsg-legacy",
      location: "eastus2",
      subnets: [snet.legacy],
      rules: [
        nsgRule("Allow-Legacy-HTTPS", {
          protocol: "Tcp",
          sourcePortRange: "*",
          destinationPortRange: "443",
          sourceAddressPrefix: "*",
          destinationAddressPrefix: "*",
          access: "Allow",
          priority: 100,
          direction: "Inbound",
        }),
        nsgRule("Allow-Legacy-SQL", {
          protocol: "Tcp",
          sourcePortRange: "*",
          destinationPortRanges: ["1433", "1434"],
          sourceAddressPrefix: "10.9.2.0/24",
          destinationAddressPrefix: "*",
          access: "Allow",
          priority: 200,
          direction: "Inbound",
        }),
      ],
    }),
  ];

  const vnets: ArmResource[] = [
    vnet({
      subscription: SUB.hub,
      group: RG.hub,
      name: "vnet-hub-eus",
      location: "eastus",
      prefix: "10.0.0.0/16",
      subnets: [
        { name: "AzureFirewallSubnet", prefix: "10.0.1.0/26" },
        { name: "snet-shared", prefix: "10.0.2.0/24", nsg: NSG.shared },
        { name: "snet-dns", prefix: "10.0.3.0/28", nsg: NSG.shared },
      ],
    }),
    vnet({
      subscription: SUB.apps,
      group: RG.apps,
      name: "vnet-spoke-apps",
      location: "eastus",
      prefix: "10.1.0.0/16",
      subnets: [
        { name: "snet-web", prefix: "10.1.1.0/24", nsg: NSG.web },
        { name: "snet-app", prefix: "10.1.2.0/24", nsg: NSG.app },
        { name: "snet-data", prefix: "10.1.3.0/24", nsg: NSG.data },
      ],
    }),
    vnet({
      subscription: SUB.apps,
      group: RG.platform,
      name: "vnet-spoke-platform",
      location: "eastus",
      prefix: "10.2.0.0/16",
      subnets: [
        { name: "snet-aks", prefix: "10.2.0.0/20", nsg: NSG.aks },
        { name: "snet-ingress", prefix: "10.2.16.0/24", nsg: NSG.ingress },
      ],
    }),
    vnet({
      subscription: SUB.nonprod,
      group: RG.dev,
      name: "vnet-nonprod-hub",
      location: "eastus2",
      prefix: "10.10.0.0/16",
      subnets: [{ name: "AzureFirewallSubnet", prefix: "10.10.1.0/26" }],
    }),
    vnet({
      subscription: SUB.nonprod,
      group: RG.dev,
      name: "vnet-dev",
      location: "eastus2",
      prefix: "10.8.0.0/16",
      subnets: [
        { name: "snet-dev", prefix: "10.8.1.0/24", nsg: NSG.dev },
        { name: "snet-build", prefix: "10.8.2.0/24", nsg: NSG.build },
      ],
    }),
    vnet({
      subscription: SUB.nonprod,
      group: RG.legacy,
      name: "vnet-legacy",
      location: "eastus2",
      prefix: "10.9.0.0/16",
      subnets: [
        { name: "AzureFirewallSubnet", prefix: "10.9.1.0/26" },
        { name: "snet-legacy", prefix: "10.9.2.0/24", nsg: NSG.legacy },
      ],
    }),
  ];

  const policies: ArmResource[] = [
    {
      id: POL_HUB,
      name: "pol-hub-eus",
      type: "microsoft.network/firewallpolicies",
      subscriptionId: SUB.hub,
      resourceGroup: RG.hub,
      location: "eastus",
      properties: { sku: { tier: "Premium" }, threatIntelMode: "Alert" },
    },
    {
      id: POL_NONPROD,
      name: "pol-nonprod",
      type: "microsoft.network/firewallpolicies",
      subscriptionId: SUB.nonprod,
      resourceGroup: RG.dev,
      location: "eastus2",
      properties: { sku: { tier: "Standard" }, threatIntelMode: "Alert" },
    },
  ];

  const firewalls: ArmResource[] = [
    {
      id: armId(SUB.hub, RG.hub, "azureFirewalls", "afw-hub-eus"),
      name: "afw-hub-eus",
      type: "microsoft.network/azurefirewalls",
      subscriptionId: SUB.hub,
      resourceGroup: RG.hub,
      location: "eastus",
      properties: {
        sku: { name: "AZFW_VNet", tier: "Premium" },
        firewallPolicy: { id: POL_HUB },
        ipConfigurations: [{ name: "ipconfig", properties: { subnet: { id: snet.firewallHub } } }],
      },
    },
    {
      id: armId(SUB.nonprod, RG.dev, "azureFirewalls", "afw-nonprod"),
      name: "afw-nonprod",
      type: "microsoft.network/azurefirewalls",
      subscriptionId: SUB.nonprod,
      resourceGroup: RG.dev,
      location: "eastus2",
      properties: {
        sku: { name: "AZFW_VNet", tier: "Standard" },
        firewallPolicy: { id: POL_NONPROD },
        ipConfigurations: [{ name: "ipconfig", properties: { subnet: { id: snet.firewallNonprod } } }],
      },
    },
    {
      id: armId(SUB.nonprod, RG.legacy, "azureFirewalls", "afw-legacy"),
      name: "afw-legacy",
      type: "microsoft.network/azurefirewalls",
      subscriptionId: SUB.nonprod,
      resourceGroup: RG.legacy,
      location: "eastus2",
      properties: {
        sku: { name: "AZFW_VNet", tier: "Standard" },
        ipConfigurations: [{ name: "ipconfig", properties: { subnet: { id: snet.firewallLegacy } } }],
        networkRuleCollections: [
          classicCollection("LegacyNet", 100, "Allow", [
            { name: "DNS", protocols: ["UDP"], sourceAddresses: ["*"], destinationAddresses: ["8.8.8.8", "1.1.1.1"], destinationPorts: ["53"] },
            { name: "SQL", protocols: ["TCP"], sourceAddresses: ["10.9.2.0/24"], destinationAddresses: ["10.9.2.20"], destinationPorts: ["1433"] },
            { name: "HTTPS-Out", protocols: ["TCP"], sourceAddresses: ["10.9.0.0/16"], destinationAddresses: ["*"], destinationPorts: ["443"] },
          ]),
          classicCollection("LegacyDeny", 400, "Deny", [
            {
              name: "Deny-SMB",
              description: "Block SMB egress.",
              protocols: ["TCP"],
              sourceAddresses: ["*"],
              destinationAddresses: ["*"],
              destinationPorts: ["445"],
            },
          ]),
        ],
        applicationRuleCollections: [
          classicCollection("LegacyApp", 200, "Allow", [
            { name: "Microsoft", protocols: [{ protocolType: "Https", port: 443 }], sourceAddresses: ["*"], targetFqdns: ["*.microsoft.com", "*.azure.com"], fqdnTags: [] },
            { name: "WindowsUpdate", protocols: [{ protocolType: "Https", port: 443 }], sourceAddresses: ["*"], targetFqdns: [], fqdnTags: ["WindowsUpdate"] },
          ]),
        ],
        natRuleCollections: [
          classicCollection("LegacyDNAT", 100, "Dnat", [
            {
              name: "Legacy-HTTPS",
              protocols: ["TCP"],
              sourceAddresses: ["*"],
              destinationAddresses: ["20.9.1.5"],
              destinationPorts: ["443"],
              translatedAddress: "10.9.2.10",
              translatedPort: "443",
            },
            {
              name: "Legacy-RDP",
              protocols: ["TCP"],
              sourceAddresses: ["198.51.100.0/24"],
              destinationAddresses: ["20.9.1.5"],
              destinationPorts: ["3389"],
              translatedAddress: "10.9.2.4",
              translatedPort: "3389",
            },
          ]),
        ],
      },
    },
  ];

  const ruleCollectionGroups: ArmResource[] = [
    group(POL_HUB, "DefaultDnatRuleCollectionGroup", 100, [
      natCollection("dnat-inbound", 100, [
        dnatRule({
          name: "SSH-Jump",
          source: ["203.0.113.10"],
          destination: ["20.25.30.40"],
          port: "22",
          translatedAddress: "10.2.16.20",
          translatedPort: "22",
          description: "Published jump host.",
        }),
        dnatRule({
          name: "HTTPS-App",
          source: ["*"],
          destination: ["20.25.30.41"],
          port: "443",
          translatedAddress: "10.1.1.10",
          translatedPort: "443",
        }),
        dnatRule({
          name: "RDP-Vendor",
          source: ["198.51.100.25"],
          destination: ["20.25.30.40"],
          port: "3389",
          translatedAddress: "10.2.16.20",
          translatedPort: "3389",
        }),
      ]),
    ]),
    group(POL_HUB, "NetworkRuleCollectionGroup", 200, [
      networkCollection("allow-core", 100, "Allow", [
        networkRule({ name: "DNS-Internal", protocols: ["UDP"], source: ["10.0.0.0/8"], destination: ["10.0.2.4"], ports: ["53"] }),
        networkRule({ name: "DNS-Azure", protocols: ["UDP"], source: ["10.0.0.0/8"], destination: ["168.63.129.16"], ports: ["53"] }),
        networkRule({ name: "NTP", protocols: ["UDP"], source: ["10.0.0.0/8"], destination: ["*"], ports: ["123"] }),
        networkRule({ name: "Web-To-SQL", protocols: ["TCP"], source: ["10.1.1.0/24"], destination: ["10.1.3.0/24"], ports: ["1433"] }),
        networkRule({ name: "Spoke-To-Spoke", protocols: ["TCP"], source: ["10.1.0.0/16"], destination: ["10.2.0.0/16"], ports: ["443", "8080"] }),
        networkRule({ name: "AKS-API", protocols: ["TCP"], source: ["10.2.0.0/20"], destination: ["10.2.16.4"], ports: ["443"] }),
        networkRule({
          name: "OnPrem-To-DNS",
          protocols: ["UDP"],
          source: [],
          sourceIpGroups: [IPG_ONPREM],
          destination: ["10.0.2.4"],
          ports: ["53"],
        }),
      ]),
      networkCollection("deny-risky", 200, "Deny", [
        networkRule({
          name: "Deny-Metadata",
          protocols: ["TCP"],
          source: ["*"],
          destination: ["169.254.169.254"],
          ports: ["80", "443"],
          description: "Block instance metadata.",
        }),
        networkRule({
          name: "Deny-Tor",
          protocols: ["Any"],
          source: ["*"],
          destination: [],
          destinationIpGroups: [IPG_TOR],
          ports: ["*"],
        }),
      ]),
    ]),
    group(POL_HUB, "ApplicationRuleCollectionGroup", 300, [
      networkCollection("allow-platform", 100, "Allow", [
        appRule({ name: "WindowsUpdate", protocol: "Https", port: 443, fqdnTags: ["WindowsUpdate"] }),
        appRule({
          name: "AzureMonitor",
          protocol: "Https",
          port: 443,
          fqdns: ["*.ods.opinsights.azure.com", "*.monitoring.azure.com"],
        }),
        appRule({
          name: "MicrosoftIdentity",
          protocol: "Https",
          port: 443,
          fqdns: ["login.microsoftonline.com", "*.microsoftonline.com"],
        }),
        appRule({
          name: "GitHub",
          protocol: "Https",
          port: 443,
          source: ["10.2.0.0/20"],
          fqdns: ["github.com", "*.github.com", "*.githubusercontent.com"],
        }),
        appRule({ name: "ContainerRegistry", protocol: "Https", port: 443, source: ["10.2.0.0/20"], fqdns: ["*.azurecr.io"] }),
      ]),
      networkCollection("allow-ops", 200, "Allow", [
        appRule({ name: "AzureBackup", protocol: "Https", port: 443, fqdnTags: ["AzureBackup"] }),
        appRule({ name: "Diagnostics", protocol: "Https", port: 443, source: ["10.0.0.0/8"], fqdns: ["*.blob.core.windows.net"] }),
      ]),
    ]),
    group(POL_NONPROD, "NonprodNetwork", 100, [
      networkCollection("allow-dev", 100, "Allow", [
        networkRule({ name: "Dev-Internet-Web", protocols: ["TCP"], source: ["10.8.0.0/16"], destination: ["*"], ports: ["80", "443"] }),
        networkRule({ name: "Dev-DNS", protocols: ["UDP"], source: ["10.8.0.0/16"], destination: ["*"], ports: ["53"] }),
      ]),
      networkCollection("deny-east-west", 300, "Deny", [
        networkRule({ name: "Deny-To-Apps", protocols: ["Any"], source: ["10.8.0.0/16"], destination: ["10.1.0.0/16"], ports: ["*"] }),
        networkRule({ name: "Deny-To-Platform", protocols: ["Any"], source: ["10.8.0.0/16"], destination: ["10.2.0.0/16"], ports: ["*"] }),
      ]),
    ]),
    group(POL_NONPROD, "NonprodApp", 200, [
      networkCollection("allow-saas", 100, "Allow", [
        appRule({ name: "Npm", protocol: "Https", port: 443, source: ["10.8.2.0/24"], fqdns: ["registry.npmjs.org", "*.npmjs.org"] }),
        appRule({ name: "Ubuntu", protocol: "Http", port: 80, fqdns: ["archive.ubuntu.com", "security.ubuntu.com"] }),
      ]),
    ]),
    group(POL_NONPROD, "NonprodDnat", 150, [
      natCollection("dnat-dev", 100, [
        dnatRule({
          name: "Dev-SSH",
          source: ["203.0.113.10"],
          destination: ["20.50.1.10"],
          port: "22",
          translatedAddress: "10.8.1.10",
          translatedPort: "22",
        }),
      ]),
    ]),
  ];

  return {
    subscriptions: [
      { subscriptionId: SUB.hub, name: "Production Network" },
      { subscriptionId: SUB.apps, name: "Production Applications" },
      { subscriptionId: SUB.nonprod, name: "Non-Production" },
    ],
    vnets,
    nsgs,
    nics: [
      {
        id: NIC_JUMP,
        name: "nic-jump-01",
        type: "microsoft.network/networkinterfaces",
        subscriptionId: SUB.apps,
        resourceGroup: RG.platform,
        location: "eastus",
        properties: {
          virtualMachine: {
            id: `/subscriptions/${SUB.apps}/resourceGroups/${RG.platform}/providers/Microsoft.Compute/virtualMachines/vm-jump-01`,
          },
          networkSecurityGroup: { id: NSG.jump },
          ipConfigurations: [
            {
              name: "ipconfig1",
              properties: { privateIPAddress: "10.2.16.20", subnet: { id: snet.ingress } },
            },
          ],
        },
      },
    ],
    firewalls,
    policies,
    ruleCollectionGroups,
  };
}

export const samples = {
  flatNsg: {
    id: "/subscriptions/22222222-2222-2222-2222-222222222222/resourceGroups/rg-spoke-apps/providers/Microsoft.Network/networkSecurityGroups/nsg-flat",
    name: "nsg-flat",
    subscriptionId: "22222222-2222-2222-2222-222222222222",
    resourceGroup: "rg-spoke-apps",
    location: "eastus",
    properties: {
      securityRules: [
        {
          name: "FlatAllowDns",
          protocol: "Udp",
          sourcePortRange: "*",
          destinationPortRange: "53",
          sourceAddressPrefix: "VirtualNetwork",
          destinationAddressPrefix: "10.0.2.4",
          access: "Allow",
          priority: 150,
          direction: "Inbound",
          description: "Flat Resource Graph rule with no properties wrapper.",
        },
      ],
      defaultSecurityRules: [],
      subnets: [],
      networkInterfaces: [],
    },
  } satisfies ArmResource,
  bothShapesNsg: {
    id: "/subscriptions/22222222-2222-2222-2222-222222222222/resourceGroups/rg-spoke-apps/providers/Microsoft.Network/networkSecurityGroups/nsg-both",
    name: "nsg-both",
    subscriptionId: "22222222-2222-2222-2222-222222222222",
    resourceGroup: "rg-spoke-apps",
    location: "eastus",
    properties: {
      securityRules: [
        {
          name: "BothShapes",
          properties: {
            protocol: "Tcp",
            sourcePortRange: "1000",
            sourcePortRanges: ["2000-2002"],
            destinationPortRange: "80",
            destinationPortRanges: ["443"],
            sourceAddressPrefix: "10.0.0.1",
            sourceAddressPrefixes: ["10.0.0.2/32"],
            destinationAddressPrefix: "10.1.0.1",
            destinationAddressPrefixes: ["10.1.0.2/32"],
            access: "Allow",
            priority: 180,
            direction: "Inbound",
          },
        },
      ],
      defaultSecurityRules: [],
      subnets: [],
      networkInterfaces: [],
    },
  } satisfies ArmResource,
  flatClassicFirewall: {
    id: "/subscriptions/33333333-3333-3333-3333-333333333333/resourceGroups/rg-legacy-eus/providers/Microsoft.Network/azureFirewalls/afw-flat",
    name: "afw-flat",
    subscriptionId: "33333333-3333-3333-3333-333333333333",
    resourceGroup: "rg-legacy-eus",
    location: "eastus2",
    properties: {
      networkRuleCollections: [
        {
          name: "FlatNet",
          priority: 150,
          action: { type: "Allow" },
          rules: [
            {
              name: "FlatDns",
              protocols: ["UDP"],
              sourceAddresses: ["*"],
              destinationAddresses: ["1.1.1.1"],
              destinationPorts: ["53"],
            },
          ],
        },
      ],
    },
  } satisfies ArmResource,
  summaryGroup: {
    id: "/subscriptions/11111111-1111-1111-1111-111111111111/resourceGroups/rg-hub-eus/providers/Microsoft.Network/firewallPolicies/pol-hub-eus/ruleCollectionGroups/EmptyFromGraph",
    name: "EmptyFromGraph",
    properties: { priority: 500, ruleCollections: [] },
  } satisfies ArmResource,
};

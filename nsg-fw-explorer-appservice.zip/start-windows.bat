@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>&1 || (
  echo Install Node.js 22 or newer, then run this script again.
  exit /b 1
)
if not exist node_modules call npm install
if errorlevel 1 exit /b 1
set DATA_SOURCE=csv
set AUTH_ENABLED=false
set BROWSER=none
echo Starting NSG and Firewall Rules at http://127.0.0.1:43123
start "" http://127.0.0.1:43123
npm start

import { describe, expect, it } from "vitest";
import { loadAzureInventory, selectAzureScope } from "../src/lib/collector/azure";
import { loadConfig } from "../src/lib/config";

describe("all accessible subscriptions", () => {
  it("uses every listed subscription when no scope is configured", () => {
    const choice = selectAzureScope({
      subscriptionIds: [],
      managementGroupId: "",
      listed: [
        { subscriptionId: "aaa", name: "Alpha" },
        { subscriptionId: "bbb", name: "Beta" },
        { subscriptionId: "ccc", name: "Gamma" },
      ],
      discovered: null,
    });
    expect(choice.scope.subscriptions).toEqual(["aaa", "bbb", "ccc"]);
    expect(choice.warnings[0]).toMatch(/3 subscriptions/);
  });

  it("falls back to a tenant Resource Graph discovery when the subscription list is empty", () => {
    const choice = selectAzureScope({
      subscriptionIds: [],
      managementGroupId: "",
      listed: [],
      discovered: [{ subscriptionId: "ddd", name: "Delta" }],
      listError: "HTTP 403",
    });
    expect(choice.scope.subscriptions).toEqual(["ddd"]);
    expect(choice.warnings.join(" ")).toContain("HTTP 403");
  });

  it("does not throw when nothing is visible", () => {
    const choice = selectAzureScope({
      subscriptionIds: [],
      managementGroupId: "",
      listed: [],
      discovered: [],
    });
    expect(choice.scope.subscriptions).toBeUndefined();
    expect(choice.warnings.join(" ")).toMatch(/No accessible subscriptions/);
  });

  it("queries Resource Graph with every accessible subscription and reads rule groups from ARM", async () => {
    const scopes: unknown[] = [];
    const warnings: string[] = [];
    const config = { ...loadConfig(), dataSource: "azure" as const, subscriptionIds: [], managementGroupId: "" };
    const inventory = await loadAzureInventory(config, warnings, {
      listSubscriptions: async () => [
        { subscriptionId: "11111111-1111-1111-1111-111111111111", name: "Production Network" },
        { subscriptionId: "22222222-2222-2222-2222-222222222222", name: "Production Applications" },
      ],
      discoverSubscriptions: async () => [],
      query: async (_kql, scope) => {
        scopes.push(scope);
        return [];
      },
      listRuleGroups: async () => [],
    });
    expect(scopes[0]).toEqual({
      subscriptions: ["11111111-1111-1111-1111-111111111111", "22222222-2222-2222-2222-222222222222"],
    });
    expect(inventory.nsgs).toEqual([]);
    expect(warnings.some((warning) => warning.includes("2 subscriptions"))).toBe(true);
  });
});

import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { buildInventory } from "../fixtures/build-inventory";
import { buildContext } from "../src/lib/normalize/context";
import { normalizeClassicFirewall } from "../src/lib/normalize/firewall-classic";
import { normalizeInventory } from "../src/lib/normalize/inventory";
import { normalizeNsg } from "../src/lib/normalize/nsg";
import { ruleCollectionGroupNeedsDetail } from "../src/lib/collector/rule-groups";
import type { ArmResource, Inventory, RuleRow } from "../src/lib/types";

function loadJson<T>(file: string): T {
  return JSON.parse(readFileSync(file, "utf8")) as T;
}

const inventory = loadJson<Inventory>("fixtures/inventory.json");
const rules = normalizeInventory(inventory);

function one(name: string, parent: string): RuleRow {
  const matches = rules.filter((rule) => rule.ruleName === name && rule.nsgOrFirewallName === parent);
  expect(matches.map((rule) => rule.id), `${name} on ${parent}`).toHaveLength(1);
  return matches[0];
}

describe("fixture inventory", () => {
  it("matches the builder so the JSON fixtures stay the source of truth", () => {
    expect(inventory).toEqual(buildInventory());
  });

  it("covers several subscriptions, NIC association, defaults, policies, and a classic firewall", () => {
    expect(inventory.subscriptions.map((subscription) => subscription.name)).toEqual([
      "Production Network",
      "Production Applications",
      "Non-Production",
    ]);
    expect(inventory.nsgs.length).toBeGreaterThanOrEqual(8);
    expect(inventory.firewalls.map((firewall) => firewall.name).sort()).toEqual(["afw-hub-eus", "afw-legacy", "afw-nonprod"]);
    expect(rules.filter((rule) => rule.isDefault).length).toBe(inventory.nsgs.length * 6);
    expect(rules.some((rule) => rule.sourceType === "firewall-policy" && rule.nsgOrFirewallName === "afw-hub-eus")).toBe(true);
    expect(rules.some((rule) => rule.sourceType === "firewall-policy" && rule.nsgOrFirewallName === "afw-nonprod")).toBe(true);
    expect(rules.some((rule) => rule.sourceType === "firewall-classic")).toBe(true);
    expect(new Set(rules.map((rule) => rule.id)).size).toBe(rules.length);
  });
});

describe("NSG normalizer", () => {
  it("reads singular prefixes, ports, service tags, and subnet association", () => {
    const rule = one("Allow-HTTPS-Internet", "nsg-web");
    expect(rule).toMatchObject({
      sourceType: "nsg",
      subscriptionName: "Production Applications",
      resourceGroup: "rg-spoke-apps",
      vnet: "vnet-spoke-apps",
      subnets: ["snet-web"],
      nic: "",
      direction: "Inbound",
      action: "Allow",
      priority: 100,
      priorityLabel: "100",
      protocols: ["TCP"],
      sourceAddresses: ["Internet"],
      destinationAddresses: ["*"],
      sourcePorts: ["*"],
      destinationPorts: ["443"],
      isDefault: false,
      ruleType: "security",
    });
  });

  it("reads plural address and port fields", () => {
    const rule = one("Allow-Admin-Prefixes", "nsg-web");
    expect(rule.sourceAddresses).toEqual(["203.0.113.10/32", "198.51.100.0/24"]);
    expect(rule.destinationAddresses).toEqual(["10.1.1.0/24"]);
    expect(rule.sourcePorts).toEqual(["1024-65535"]);
    expect(rule.destinationPorts).toEqual(["22", "3389"]);
    expect(rule.description).toContain("NET-2218");
  });

  it("names application security groups", () => {
    expect(one("Allow-From-ASG", "nsg-web").sourceAddresses).toContain("asg:asg-web-clients");
  });

  it("marks default security rules and keeps their priority", () => {
    const rule = one("AllowVNetInBound", "nsg-web");
    expect(rule.isDefault).toBe(true);
    expect(rule.ruleType).toBe("default");
    expect(rule.priority).toBe(65000);
    expect(rule.action).toBe("Allow");
    expect(rule.direction).toBe("Inbound");
    expect(one("DenyAllOutBound", "nsg-data")).toMatchObject({ isDefault: true, action: "Deny", priority: 65500 });
  });

  it("keeps every subnet when one NSG is associated with more than one", () => {
    expect(one("Allow-DNS-UDP", "nsg-shared").subnets).toEqual(["snet-shared", "snet-dns"]);
    expect(one("Allow-DNS-UDP", "nsg-shared").vnet).toBe("vnet-hub-eus");
  });

  it("resolves a NIC association to the VM name and the NIC subnet", () => {
    const rule = one("Allow-SSH-Corp", "nsg-jump");
    expect(rule.nic).toBe("nic-jump-01");
    expect(rule.vmName).toBe("vm-jump-01");
    expect(rule.vnet).toBe("vnet-spoke-platform");
    expect(rule.subnets).toEqual(["snet-ingress"]);
    expect(rule.description).toContain("NET-1042");
    expect(rule.destinationPorts).toEqual(["22"]);
  });

  it("accepts a flat rule that has no properties wrapper", () => {
    const nsg = loadJson<ArmResource>("fixtures/samples/nsg-flat.json");
    const [rule] = normalizeNsg(nsg, buildContext({ subscriptions: [], vnets: [], nics: [] }));
    expect(rule).toMatchObject({
      ruleName: "FlatAllowDns",
      protocols: ["UDP"],
      destinationPorts: ["53"],
      sourceAddresses: ["VirtualNetwork"],
      priority: 150,
      description: "Flat Resource Graph rule with no properties wrapper.",
    });
  });

  it("merges singular and plural fields when both are present", () => {
    const nsg = loadJson<ArmResource>("fixtures/samples/nsg-plural-and-singular.json");
    const [rule] = normalizeNsg(nsg, buildContext({ subscriptions: [], vnets: [], nics: [] }));
    expect(rule.sourceAddresses).toEqual(["10.0.0.1", "10.0.0.2/32"]);
    expect(rule.destinationAddresses).toEqual(["10.1.0.1", "10.1.0.2/32"]);
    expect(rule.sourcePorts).toEqual(["1000", "2000-2002"]);
    expect(rule.destinationPorts).toEqual(["80", "443"]);
  });
});

describe("firewall policy normalizer", () => {
  it("uses collection-group priority and records the collection", () => {
    const rule = one("DNS-Internal", "afw-hub-eus");
    expect(rule).toMatchObject({
      sourceType: "firewall-policy",
      subscriptionName: "Production Network",
      vnet: "vnet-hub-eus",
      subnets: ["AzureFirewallSubnet"],
      policyName: "pol-hub-eus",
      collectionGroupName: "NetworkRuleCollectionGroup",
      collectionGroupPriority: 200,
      collectionName: "allow-core",
      collectionPriority: 100,
      priority: 200,
      priorityLabel: "200 / 100",
      ruleType: "network",
      direction: "Outbound",
      action: "Allow",
      protocols: ["UDP"],
      destinationPorts: ["53"],
      sourceAddresses: ["10.0.0.0/8"],
      destinationAddresses: ["10.0.2.4"],
    });
  });

  it("normalizes application rules, FQDNs, and FQDN tags", () => {
    const rule = one("WindowsUpdate", "afw-hub-eus");
    expect(rule.ruleType).toBe("application");
    expect(rule.protocols).toEqual(["HTTPS"]);
    expect(rule.destinationPorts).toEqual(["443"]);
    expect(rule.destinationAddresses).toContain("fqdn-tag:WindowsUpdate");
    expect(rule.priority).toBe(300);
    expect(one("AzureMonitor", "afw-hub-eus").destinationAddresses).toEqual([
      "*.ods.opinsights.azure.com",
      "*.monitoring.azure.com",
    ]);
  });

  it("normalizes DNAT translation", () => {
    const rule = one("SSH-Jump", "afw-hub-eus");
    expect(rule).toMatchObject({
      ruleType: "nat",
      action: "DNAT",
      direction: "Inbound",
      priority: 100,
      priorityLabel: "100 / 100",
      translatedAddress: "10.2.16.20",
      translatedPort: "22",
      destinationPorts: ["22"],
    });
    expect(rule.description).toContain("Published jump host");
  });

  it("keeps IP group references on source and destination", () => {
    expect(one("OnPrem-To-DNS", "afw-hub-eus").sourceAddresses).toContain("ip-group:ipg-onprem");
    expect(one("Deny-Tor", "afw-hub-eus").destinationAddresses).toContain("ip-group:ipg-tor-exit");
    expect(one("Deny-Metadata", "afw-hub-eus").action).toBe("Deny");
  });

  it("places non-production policy rules on that firewall's VNet", () => {
    const rule = one("Dev-SSH", "afw-nonprod");
    expect(rule.vnet).toBe("vnet-nonprod-hub");
    expect(rule.subscriptionName).toBe("Non-Production");
    expect(rule.action).toBe("DNAT");
  });
});

describe("classic firewall normalizer", () => {
  it("reads nested classic network, application, and DNAT collections", () => {
    const dns = one("DNS", "afw-legacy");
    expect(dns).toMatchObject({
      sourceType: "firewall-classic",
      policyName: "",
      collectionName: "LegacyNet",
      priority: 100,
      protocols: ["UDP"],
      destinationAddresses: ["8.8.8.8", "1.1.1.1"],
      destinationPorts: ["53"],
      vnet: "vnet-legacy",
      direction: "Outbound",
    });
    expect(one("Deny-SMB", "afw-legacy")).toMatchObject({ action: "Deny", priority: 400, destinationPorts: ["445"] });
    expect(one("WindowsUpdate", "afw-legacy").destinationAddresses).toContain("fqdn-tag:WindowsUpdate");
    const dnat = one("Legacy-HTTPS", "afw-legacy");
    expect(dnat.action).toBe("DNAT");
    expect(dnat.direction).toBe("Inbound");
    expect(dnat.translatedAddress).toBe("10.9.2.10");
    expect(dnat.translatedPort).toBe("443");
  });

  it("accepts a classic collection that is not wrapped in properties", () => {
    const firewall = loadJson<ArmResource>("fixtures/samples/classic-flat.json");
    const [rule] = normalizeClassicFirewall(firewall, buildContext({ subscriptions: [], vnets: [], nics: [] }));
    expect(rule).toMatchObject({
      ruleName: "FlatDns",
      sourceType: "firewall-classic",
      protocols: ["UDP"],
      destinationAddresses: ["1.1.1.1"],
      destinationPorts: ["53"],
      priority: 150,
    });
  });
});

describe("rule collection group detail", () => {
  it("asks ARM for a summary group and keeps a group that already has rules", () => {
    const summary = loadJson("fixtures/samples/rcg-summary.json");
    expect(ruleCollectionGroupNeedsDetail(summary)).toBe(true);
    const detailed = inventory.ruleCollectionGroups[0];
    expect(ruleCollectionGroupNeedsDetail(detailed)).toBe(false);
  });
});

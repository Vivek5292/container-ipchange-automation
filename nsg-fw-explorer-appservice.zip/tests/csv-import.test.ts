import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { detectDelimiter, parseCsvTable, parseRuleCsv } from "../src/lib/csv-import";

const portalNsg = `Priority,Name,Port,Protocol,Source,Destination,Action,Direction,NSG Name,Resource Group,Subscription
100,Allow-HTTPS-Internet,443,TCP,Internet,*,Allow,Inbound,nsg-web,rg-spoke-apps,Production Applications
200,Allow-SQL-Out,"1433, 1434",Tcp,10.1.2.0/24,"10.1.3.0/24, 10.1.4.0/24",Allow,Outbound,nsg-app,rg-spoke-apps,Production Applications
`;

describe("CSV parser", () => {
  it("maps Azure portal NSG headers, including quoted multi-value cells", () => {
    const parsed = parseRuleCsv("nsg.csv", portalNsg);
    expect(parsed.issues).toEqual([]);
    expect(parsed.rules).toHaveLength(2);
    expect(parsed.rules[0]).toMatchObject({
      ruleName: "Allow-HTTPS-Internet",
      sourceType: "nsg",
      nsgOrFirewallName: "nsg-web",
      resourceGroup: "rg-spoke-apps",
      subscriptionName: "Production Applications",
      protocols: ["TCP"],
      destinationPorts: ["443"],
      sourceAddresses: ["Internet"],
      action: "Allow",
      direction: "Inbound",
      priority: 100,
    });
    expect(parsed.rules[1].destinationPorts).toEqual(["1433", "1434"]);
    expect(parsed.rules[1].destinationAddresses).toEqual(["10.1.3.0/24", "10.1.4.0/24"]);
    expect(parsed.rules[1].direction).toBe("Outbound");
  });

  it("accepts header aliases that differ by case, spaces, and punctuation", () => {
    const text = "Rule Name,Destination Port Range,Source Address Prefix,Access,NSG name\nAllow-SSH,22,203.0.113.0/24,Allow,nsg-jump\n";
    const parsed = parseRuleCsv("alias.csv", text);
    expect(parsed.issues).toEqual([]);
    expect(parsed.rules[0]).toMatchObject({
      ruleName: "Allow-SSH",
      destinationPorts: ["22"],
      sourceAddresses: ["203.0.113.0/24"],
      action: "Allow",
      nsgOrFirewallName: "nsg-jump",
    });
  });

  it("reads a BOM and a semicolon delimiter", () => {
    const text = "\uFEFFName;Protocol;Source;Destination;Destination ports;Action;Rule collection;Firewall name\nDNS-Internal;UDP;10.0.0.0/8;10.0.2.4;53;Allow;allow-core;afw-hub\n";
    expect(detectDelimiter(text)).toBe(";");
    const parsed = parseRuleCsv("fw.csv", text);
    expect(parsed.issues).toEqual([]);
    expect(parsed.rules[0]).toMatchObject({
      sourceType: "firewall-policy",
      ruleName: "DNS-Internal",
      protocols: ["UDP"],
      destinationPorts: ["53"],
      nsgOrFirewallName: "afw-hub",
      collectionName: "allow-core",
      action: "Allow",
    });
  });

  it("keeps quoted commas and reports a row that has no name or action", () => {
    const text = 'Name,Protocol,Source,Destination,Destination ports,Action,Rule type,Translated address,Translated port,Notes\nSSH-Jump,TCP,"203.0.113.10, 198.51.100.4",20.25.30.40,22,DNAT,NatRule,10.2.16.20,22,Published\n,TCP,*,*,80,Allow,NetworkRule,,,\nDNS,UDP,*,*,53,Maybe,NetworkRule,,,\n';
    const table = parseCsvTable(text);
    expect(table[1][2]).toBe("203.0.113.10, 198.51.100.4");
    const parsed = parseRuleCsv("mixed.csv", text);
    expect(parsed.rules).toHaveLength(1);
    expect(parsed.rules[0].sourceAddresses).toEqual(["203.0.113.10", "198.51.100.4"]);
    expect(parsed.rules[0].action).toBe("DNAT");
    expect(parsed.rules[0].translatedAddress).toBe("10.2.16.20");
    expect(parsed.rules[0].direction).toBe("Inbound");
    expect(parsed.issues.map((issue) => issue.message)).toEqual([
      "Rule name is missing.",
      'Action "Maybe" is missing or not Allow, Deny, or DNAT.',
    ]);
    expect(parsed.issues[0].row).toBe(3);
    expect(parsed.rules[0].raw).toMatchObject({ unknown: { Notes: "Published" } });
  });

  it("parses the shipped sample files", () => {
    const nsg = parseRuleCsv("nsg-rules.csv", readFileSync("data/samples/nsg-rules.csv", "utf8"));
    const firewall = parseRuleCsv("firewall-rules.csv", readFileSync("data/samples/firewall-rules.csv", "utf8"));
    expect(nsg.issues).toEqual([]);
    expect(firewall.issues).toEqual([]);
    expect(nsg.rules.map((rule) => rule.ruleName)).toContain("Allow-SSH-Corp");
    expect(firewall.rules.find((rule) => rule.ruleName === "WindowsUpdate")?.destinationAddresses).toContain("fqdn-tag:WindowsUpdate");
    expect(firewall.rules.find((rule) => rule.ruleName === "Deny-Metadata")?.protocols).toEqual(["TCP", "UDP"]);
  });
});

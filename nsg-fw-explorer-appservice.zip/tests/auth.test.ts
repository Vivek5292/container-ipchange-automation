import { afterEach, describe, expect, it } from "vitest";
import { allowRefresh, isAdmin, parsePrincipalHeader, resolveRequestPrincipal, canRead } from "../src/lib/auth";
import { loadConfig } from "../src/lib/config";

const saved = { ...process.env };

function setEnv(name: string, value: string): void {
  process.env[name] = value;
}

afterEach(() => {
  for (const key of Object.keys(process.env)) {
    if (!(key in saved)) delete process.env[key];
  }
  for (const [key, value] of Object.entries(saved)) {
    if (value == null) delete process.env[key];
    else process.env[key] = value;
  }
});

function header(claims: { typ: string; val: string }[]): string {
  return Buffer.from(JSON.stringify({ auth_typ: "aad", claims }), "utf8").toString("base64");
}

describe("Easy Auth principal", () => {
  it("reads group and role claims", () => {
    setEnv("AUTH_ENABLED", "true");
    const principal = parsePrincipalHeader(
      header([
        { typ: "name", val: "Asha Sen" },
        { typ: "preferred_username", val: "asha@contoso.example" },
        { typ: "groups", val: "group-ops" },
        { typ: "http://schemas.microsoft.com/ws/2008/06/identity/claims/role", val: "Rules.Admin" },
        { typ: "oid", val: "user-1" },
      ]),
    );
    expect(principal).toMatchObject({
      name: "Asha Sen",
      userId: "user-1",
      groups: ["group-ops"],
      roles: ["Rules.Admin"],
      devOverrideAdmin: false,
    });
  });

  it("rejects a missing principal in production and when Easy Auth is required", () => {
    setEnv("AUTH_ENABLED", "true");
    setEnv("NODE_ENV", "production");
    setEnv("AUTH_MODE", "disabled");
    expect(resolveRequestPrincipal(null)).toMatchObject({ status: 401 });

    setEnv("NODE_ENV", "test");
    setEnv("AUTH_MODE", "easyauth");
    expect(resolveRequestPrincipal(null)).toMatchObject({ status: 401 });
    expect(resolveRequestPrincipal("not-base64-json")).toMatchObject({ status: 401 });
  });

  it("uses a local admin only outside production when no principal is present", () => {
    setEnv("AUTH_ENABLED", "true");
    setEnv("NODE_ENV", "test");
    setEnv("AUTH_MODE", "disabled");
    process.env.DEV_IS_ADMIN = "true";
    const admin = resolveRequestPrincipal(null);
    expect("principal" in admin && admin.principal.devOverrideAdmin).toBe(true);

    process.env.DEV_IS_ADMIN = "false";
    const reader = resolveRequestPrincipal(null);
    if (!("principal" in reader)) throw new Error("expected a principal");
    expect(isAdmin(reader.principal, loadConfig())).toBe(false);
  });

  it("grants admin from the configured group or app role and keeps other readers out", () => {
    setEnv("AUTH_ENABLED", "true");
    process.env.ADMIN_GROUP_ID = "group-admins";
    process.env.ADMIN_ROLE = "Rules.Admin";
    process.env.OPS_GROUP_ID = "group-ops";
    const config = loadConfig();
    const admin = parsePrincipalHeader(header([{ typ: "groups", val: "group-admins" }, { typ: "name", val: "Admin" }]));
    const roleAdmin = parsePrincipalHeader(header([{ typ: "roles", val: "Rules.Admin" }, { typ: "name", val: "Role" }]));
    const reader = parsePrincipalHeader(header([{ typ: "groups", val: "group-ops" }, { typ: "name", val: "Reader" }]));
    const stranger = parsePrincipalHeader(header([{ typ: "name", val: "Stranger" }]));
    expect(admin && isAdmin(admin, config)).toBe(true);
    expect(roleAdmin && isAdmin(roleAdmin, config)).toBe(true);
    expect(reader && isAdmin(reader, config)).toBe(false);
    expect(reader && canRead(reader, config)).toBe(true);
    expect(stranger && canRead(stranger, config)).toBe(false);
    expect(reader && allowRefresh(reader, config)).toBe(false);
    expect(admin && allowRefresh(admin, config)).toBe(true);
  });

  it("refuses refresh and a bad principal header when auth is on", () => {
    setEnv("AUTH_ENABLED", "true");
    setEnv("AUTH_MODE", "easyauth");
    setEnv("NODE_ENV", "test");
    setEnv("ADMIN_GROUP_ID", "group-admins");
    const reader = parsePrincipalHeader(header([{ typ: "name", val: "Reader" }, { typ: "groups", val: "ops-only" }]));
    expect(reader && allowRefresh(reader, loadConfig())).toBe(false);
    expect(resolveRequestPrincipal("%%%")).toMatchObject({ status: 401 });
    expect(resolveRequestPrincipal(null)).toMatchObject({ status: 401 });
  });
});

describe("authentication disabled", () => {
  it("serves a caller with no principal, including in production", () => {
    setEnv("AUTH_ENABLED", "false");
    setEnv("NODE_ENV", "production");
    setEnv("AUTH_MODE", "easyauth");
    const resolved = resolveRequestPrincipal(null);
    expect("principal" in resolved).toBe(true);
    expect(resolveRequestPrincipal("%%%")).toMatchObject({ principal: { authenticated: true } });
  });

  it("lets anyone refresh", () => {
    setEnv("AUTH_ENABLED", "false");
    setEnv("DEV_IS_ADMIN", "false");
    setEnv("ADMIN_GROUP_ID", "group-admins");
    const config = loadConfig();
    const resolved = resolveRequestPrincipal(null);
    if (!("principal" in resolved)) throw new Error("expected a principal");
    expect(isAdmin(resolved.principal, config)).toBe(false);
    expect(allowRefresh(resolved.principal, config)).toBe(true);
  });
});

import { describe, expect, it } from "vitest";
import { addressQueryMatches, buildFacets, filterRules, paginate, parseRuleQuery, portListMatches, ruleMatches } from "../src/lib/filter";
import { normalizeInventory } from "../src/lib/normalize/inventory";
import { buildInventory } from "../fixtures/build-inventory";
import type { RuleQuery } from "../src/lib/filter";
import type { RuleRow } from "../src/lib/types";

const rules = normalizeInventory(buildInventory());

function query(partial: Partial<RuleQuery>): RuleQuery {
  return {
    q: "",
    subscriptionId: "",
    vnet: "",
    subnet: "",
    target: "",
    direction: "",
    action: "",
    protocol: "",
    port: "",
    priorityMin: null,
    priorityMax: null,
    source: "",
    destination: "",
    page: 1,
    pageSize: 25,
    sort: "priority",
    sortDir: "asc",
    ...partial,
  };
}

describe("address and port matching", () => {
  it("matches an IP inside a CIDR and a universal address", () => {
    expect(addressQueryMatches("10.1.1.50", ["10.1.1.0/24"])).toBe(true);
    expect(addressQueryMatches("10.2.0.1", ["10.1.1.0/24"])).toBe(false);
    expect(addressQueryMatches("10.1.1.50", ["*"])).toBe(true);
    expect(addressQueryMatches("10.1.1.50", ["0.0.0.0/0"])).toBe(true);
    expect(addressQueryMatches("10.1.1.50", ["Internet"])).toBe(false);
    expect(addressQueryMatches("internet", ["Internet"])).toBe(true);
    expect(addressQueryMatches("asg-web", ["asg:asg-web-clients"])).toBe(true);
    expect(addressQueryMatches("10.1.1.0/24", ["10.1.1.50"])).toBe(true);
  });

  it("matches a port inside a range, a list, and a wildcard", () => {
    expect(portListMatches(["1433"], "1433")).toBe(true);
    expect(portListMatches(["1000-2000"], "1433")).toBe(true);
    expect(portListMatches(["22", "3389"], "3389")).toBe(true);
    expect(portListMatches(["80"], "1433")).toBe(false);
    expect(portListMatches(["*"], "5432")).toBe(true);
    expect(portListMatches(["30000-32767"], "31000")).toBe(true);
    expect(portListMatches(["443"], "4430")).toBe(false);
  });
});

describe("rule filters", () => {
  it("searches free text across names and descriptions", () => {
    const matched = filterRules(rules, query({ q: "NET-1042" }));
    expect(matched.map((rule) => rule.ruleName)).toEqual(["Allow-SSH-Corp"]);
  });

  it("filters by subscription, direction, action, and priority range", () => {
    const subscriptionId = "33333333-3333-3333-3333-333333333333";
    const matched = filterRules(rules, query({ subscriptionId, direction: "Outbound", action: "Deny", priorityMin: 400, priorityMax: 400 }));
    expect(matched.map((rule) => rule.ruleName)).toContain("Deny-SMB");
    expect(matched.every((rule) => rule.subscriptionId === subscriptionId && rule.action === "Deny")).toBe(true);
  });

  it("matches a destination port and a source IP inside a prefix", () => {
    const matched = filterRules(rules, query({ q: "Allow-Postgres", port: "5432", source: "10.1.2.10" }));
    expect(matched.map((rule) => rule.ruleName)).toEqual(["Allow-Postgres"]);
    expect(ruleMatches(matched[0], query({ port: "22" }))).toBe(false);
  });

  it("paginates and builds facets", () => {
    const page = paginate(rules, 2, 25);
    expect(page.items).toHaveLength(25);
    expect(page.page).toBe(2);
    expect(page.total).toBe(rules.length);
    const facets = buildFacets(rules);
    expect(facets.subscriptions.map((option) => option.label)).toContain("Production Network");
    expect(facets.protocols).toContain("TCP");
  });

  it("parses query parameters", () => {
    const parsed = parseRuleQuery(new URLSearchParams("q=ssh&port=22&priorityMin=100&page=3&pageSize=500&sort=nope"));
    expect(parsed).toMatchObject({ q: "ssh", port: "22", priorityMin: 100, page: 3, pageSize: 100, sort: "priority" });
  });

  it("filters thousands of rows quickly", () => {
    const bulk: RuleRow[] = Array.from({ length: 5000 }, (_, index) => ({
      ...rules[0],
      id: `bulk-${index}`,
      ruleName: index % 2 === 0 ? `Allow-${index}` : `Deny-${index}`,
      priority: index,
      destinationPorts: [String(index % 1000)],
      searchText: `allow-${index} deny-${index} 10.4.${index % 256}.1`,
      sourceAddresses: [`10.4.${index % 256}.0/24`],
    }));
    const started = performance.now();
    const matched = filterRules(bulk, query({ q: "allow-42", port: "42", source: "10.4.42.9" }));
    expect(performance.now() - started).toBeLessThan(200);
    expect(matched.length).toBeGreaterThan(0);
    expect(matched.every((rule) => rule.ruleName.startsWith("Allow-"))).toBe(true);
  });
});

import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { afterEach, describe, expect, it } from "vitest";
import { rulesToCsv } from "../src/lib/csv";
import { queryAllPages } from "../src/lib/collector/paging";
import { resolveRuleCollectionGroups } from "../src/lib/collector/rule-groups";
import { normalizeInventory } from "../src/lib/normalize/inventory";
import { LocalSnapshotStore } from "../src/lib/snapshot/local";
import { buildInventory } from "../fixtures/build-inventory";
import { readFileSync } from "node:fs";

describe("resource graph paging", () => {
  it("follows skipToken and stops on a repeated token", async () => {
    const rows = await queryAllPages(async (skipToken) => {
      if (!skipToken) return { data: [{ id: "a" }], skipToken: "page-2" };
      if (skipToken === "page-2") return { data: [{ id: "b" }], skipToken: "page-2" };
      return { data: [{ id: "c" }] };
    });
    expect(rows).toEqual([{ id: "a" }, { id: "b" }]);
  });
});

describe("ARM fallback for policy rule collection groups", () => {
  it("keeps complete graph groups and replaces summaries with ARM detail", async () => {
    const calls: string[] = [];
    const summary = {
      id: "/subscriptions/sub/resourceGroups/rg/providers/Microsoft.Network/firewallPolicies/pol/ruleCollectionGroups/summary",
      name: "summary",
      properties: { priority: 100, ruleCollections: [] },
    };
    const complete = {
      id: "/subscriptions/sub/resourceGroups/rg/providers/Microsoft.Network/firewallPolicies/other/ruleCollectionGroups/full",
      name: "full",
      properties: { priority: 200, ruleCollections: [{ name: "allow", rules: [{ name: "dns" }] }] },
    };
    const detailed = {
      id: summary.id,
      name: "summary",
      properties: { priority: 100, ruleCollections: [{ name: "dnat", rules: [{ name: "ssh" }] }] },
    };
    const resolved = await resolveRuleCollectionGroups([summary, complete], [summary.id.replace(/\/ruleCollectionGroups\/summary$/, ""), complete.id.replace(/\/ruleCollectionGroups\/full$/, "")], async (policyId) => {
      calls.push(policyId);
      return [detailed];
    });
    expect(calls).toEqual([expect.stringContaining("/firewallPolicies/pol")]);
    expect(resolved.groups).toEqual([detailed, complete]);
    expect(resolved.warnings).toEqual([]);
  });

  it("keeps the summary and records a warning when ARM fails", async () => {
    const summary = {
      id: "/subscriptions/sub/resourceGroups/rg/providers/Microsoft.Network/firewallPolicies/pol/ruleCollectionGroups/summary",
      name: "summary",
      properties: { priority: 100 },
    };
    const resolved = await resolveRuleCollectionGroups([summary], ["/subscriptions/sub/resourceGroups/rg/providers/Microsoft.Network/firewallPolicies/pol"], async () => {
      throw new Error("throttled");
    });
    expect(resolved.groups).toEqual([summary]);
    expect(resolved.warnings[0]).toContain("throttled");
  });
});

describe("snapshot lock", () => {
  const directories: string[] = [];

  afterEach(async () => {
    await Promise.all(directories.splice(0).map((directory) => rm(directory, { recursive: true, force: true })));
  });

  it("lets one collector hold the lock and writes latest plus history", async () => {
    const directory = await mkdtemp(path.join(tmpdir(), "nsg-snap-"));
    directories.push(directory);
    const store = new LocalSnapshotStore(directory);
    const first = await store.acquireLock("webjob", 5_000);
    const second = await store.acquireLock("manual", 5_000);
    expect(first).not.toBeNull();
    expect(second).toBeNull();
    await first?.release();
    const third = await store.acquireLock("manual", 5_000);
    expect(third).not.toBeNull();
    await third?.release();

    const snapshot = {
      version: 1 as const,
      generatedAt: "2026-11-21T22:00:00.000Z",
      finishedAt: "2026-11-21T22:00:01.000Z",
      source: "mock" as const,
      status: "ok" as const,
      warnings: [],
      stats: { subscriptions: 1, nsgs: 1, firewalls: 0, policies: 0, rules: 0, durationMs: 1 },
      rules: [],
    };
    await store.write(snapshot);
    expect(await store.readLatest()).toMatchObject({ generatedAt: snapshot.generatedAt });
  });
});

describe("csv export", () => {
  it("quotes commas and includes the filtered rule", () => {
    const [rule] = normalizeInventory(buildInventory()).filter((item) => item.ruleName === "Allow-Postgres");
    const csv = rulesToCsv([{ ...rule, description: 'Says "hello", then more' }]);
    expect(csv.charCodeAt(0)).toBe(0xfeff);
    expect(csv).toContain("ruleName,sourceType");
    expect(csv).toContain("Allow-Postgres");
    expect(csv).toContain('"Says ""hello"", then more"');
  });
});

describe("read-only collector", () => {
  it("does not call Azure write operations", () => {
    const files = ["src/lib/collector/azure.ts", "src/lib/collector/rule-groups.ts", "src/lib/snapshot/blob.ts"];
    const forbidden = [".createOrUpdate", ".beginCreate", ".beginDelete", ".delete(", "createOrUpdate("];
    for (const file of files) {
      const source = readFileSync(file, "utf8");
      for (const token of forbidden) expect(source, `${file} contains ${token}`).not.toContain(token);
    }
  });
});

targetScope = 'resourceGroup'

@description('Azure region for the App Service plan, app, and storage account.')
param location string = resourceGroup().location

@description('Globally unique App Service name.')
param appName string

@description('Globally unique storage account name for rule snapshots. Lowercase, 3-24 characters.')
param storageAccountName string

@description('Blob container that holds latest.json.gz and history/. Create is done by this template.')
param snapshotContainerName string = 'nsg-firewall-snapshots'

@description('App Service plan SKU. S1 or larger is required for Always On.')
param skuName string = 'S1'

@description('Comma-separated subscription GUIDs. Leave empty to use the management group instead.')
param subscriptionIds string = ''

@description('Management group name or GUID used when subscription IDs are empty.')
param managementGroupId string = ''

@description('Entra group object id whose members may refresh the snapshot.')
param adminGroupId string = ''

param adminRole string = 'Rules.Admin'

@description('Optional Entra group object id required to read the site, in addition to Easy Auth.')
param opsGroupId string = ''

param opsRole string = ''

@description('User sign-in. Default false: no Easy Auth and no principal check. Set true to deploy authsettingsV2.')
param authEnabled bool = false

@description('Entra app registration client id. Used only when authEnabled is true.')
param aadClientId string = ''

@description('Entra tenant id. Used only when authEnabled is true.')
param aadTenantId string = ''

var blobDataContributor = 'ba92f5b4-2d11-453d-a403-e96b0029c9fe'

resource plan 'Microsoft.Web/serverfarms@2024-04-01' = {
  name: '${appName}-plan'
  location: location
  sku: {
    name: skuName
    tier: 'Standard'
  }
  kind: 'linux'
  properties: {
    reserved: true
  }
}

resource app 'Microsoft.Web/sites@2024-04-01' = {
  name: appName
  location: location
  identity: {
    type: 'SystemAssigned'
  }
  properties: {
    serverFarmId: plan.id
    httpsOnly: true
    siteConfig: {
      linuxFxVersion: 'NODE|22-lts'
      alwaysOn: true
      ftpsState: 'Disabled'
      minTlsVersion: '1.2'
      appSettings: [
        { name: 'DATA_SOURCE', value: 'azure' }
        { name: 'AUTH_ENABLED', value: authEnabled ? 'true' : 'false' }
        { name: 'AUTH_MODE', value: authEnabled ? 'easyauth' : 'disabled' }
        { name: 'AZURE_SUBSCRIPTION_IDS', value: subscriptionIds }
        { name: 'AZURE_MANAGEMENT_GROUP_ID', value: managementGroupId }
        { name: 'SNAPSHOT_STORAGE_ACCOUNT_URL', value: 'https://${storageAccountName}.blob.core.windows.net' }
        { name: 'SNAPSHOT_CONTAINER', value: snapshotContainerName }
        { name: 'ADMIN_GROUP_ID', value: adminGroupId }
        { name: 'ADMIN_ROLE', value: adminRole }
        { name: 'OPS_GROUP_ID', value: opsGroupId }
        { name: 'OPS_ROLE', value: opsRole }
        { name: 'SCM_DO_BUILD_DURING_DEPLOYMENT', value: 'true' }
        { name: 'WEBSITE_NODE_DEFAULT_VERSION', value: '~22' }
      ]
    }
  }
}

resource storage 'Microsoft.Storage/storageAccounts@2023-05-01' = {
  name: storageAccountName
  location: location
  sku: { name: 'Standard_LRS' }
  kind: 'StorageV2'
  properties: {
    minimumTlsVersion: 'TLS1_2'
    allowBlobPublicAccess: false
    supportsHttpsTrafficOnly: true
    allowSharedKeyAccess: false
  }
}

resource blobService 'Microsoft.Storage/storageAccounts/blobServices@2023-05-01' = {
  parent: storage
  name: 'default'
}

resource container 'Microsoft.Storage/storageAccounts/blobServices/containers@2023-05-01' = {
  parent: blobService
  name: snapshotContainerName
  properties: { publicAccess: 'None' }
}

resource blobContributor 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(container.id, app.id, blobDataContributor)
  scope: container
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', blobDataContributor)
    principalId: app.identity.principalId
    principalType: 'ServicePrincipal'
  }
}

// Easy Auth is user sign-in. It is separate from the managed identity used to read Azure.
resource authSettings 'Microsoft.Web/sites/config@2024-04-01' = if (authEnabled) {
  parent: app
  name: 'authsettingsV2'
  properties: {
    platform: {
      enabled: true
    }
    globalValidation: {
      requireAuthentication: true
      unauthenticatedClientAction: 'Return401'
    }
    identityProviders: {
      azureActiveDirectory: {
        enabled: true
        registration: {
          clientId: aadClientId
          openIdIssuer: 'https://login.microsoftonline.com/${aadTenantId}/v2.0'
          clientSecretSettingName: 'MICROSOFT_PROVIDER_AUTHENTICATION_SECRET'
        }
        validation: {
          allowedAudiences: [
            aadClientId
            'api://${aadClientId}'
          ]
        }
      }
    }
    login: {
      tokenStore: {
        enabled: true
      }
    }
  }
}

output principalId string = app.identity.principalId
output defaultHostName string = app.properties.defaultHostName

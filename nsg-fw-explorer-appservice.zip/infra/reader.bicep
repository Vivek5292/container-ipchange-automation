targetScope = 'managementGroup'

@description('Principal id of the App Service system-assigned managed identity.')
param principalId string

@description('Built-in Reader. Reader includes Microsoft.Network/*/read and Microsoft.ResourceGraph/*/read.')
param roleDefinitionId string = 'acdd72a7-3385-48ef-bd42-f606fba81ae7'

resource reader 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(managementGroup().id, principalId, roleDefinitionId)
  properties: {
    roleDefinitionId: '/providers/Microsoft.Authorization/roleDefinitions/${roleDefinitionId}'
    principalId: principalId
    principalType: 'ServicePrincipal'
  }
}

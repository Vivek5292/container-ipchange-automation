import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

function readEnv(name: string): string {
  return (process.env[name] ?? "").trim().toLowerCase();
}

function authEnabled(): boolean {
  const value = readEnv("AUTH_ENABLED");
  return value === "true" || value === "1" || value === "yes";
}

export function proxy(request: NextRequest) {
  if (!authEnabled()) return NextResponse.next();
  const enforce = readEnv("AUTH_MODE") === "easyauth" || readEnv("NODE_ENV") === "production";
  if (!enforce) return NextResponse.next();
  if (request.headers.get("x-ms-client-principal")) return NextResponse.next();
  const acceptsHtml = (request.headers.get("accept") ?? "").includes("text/html");
  if (acceptsHtml) {
    return new NextResponse("Sign-in required. This site is restricted to the operations security group.", {
      status: 401,
      headers: { "content-type": "text/plain; charset=utf-8" },
    });
  }
  return NextResponse.json(
    { error: "Sign-in required. App Service Authentication did not supply a principal." },
    { status: 401 },
  );
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|.*\\.(?:png|svg|ico)$).*)"],
};

"use client";

import { ToggleButton, ToggleButtonGroup } from "@heroui/react";
import { useTheme } from "@heroui/react";
import { useSyncExternalStore } from "react";

const mounted = () => true;
const unmounted = () => false;
const subscribe = () => () => {};

export function ThemeToggle() {
  const { theme, setTheme } = useTheme("system");
  const ready = useSyncExternalStore(subscribe, mounted, unmounted);
  const selected = ready ? theme : "system";
  return (
    <ToggleButtonGroup
      aria-label="Theme"
      disallowEmptySelection
      selectedKeys={[selected]}
      selectionMode="single"
      size="sm"
      onSelectionChange={(keys) => {
        const next = [...keys][0];
        if (typeof next === "string") setTheme(next);
      }}
    >
      <ToggleButton id="light">Light</ToggleButton>
      <ToggleButton id="dark">Dark</ToggleButton>
      <ToggleButton id="system">System</ToggleButton>
    </ToggleButtonGroup>
  );
}

"use client";

import {
  Alert,
  Button,
  Card,
  Chip,
  EmptyState,
  Input,
  Label,
  ListBox,
  Modal,
  Pagination,
  SearchField,
  Select,
  Spinner,
  Table,
  TextField,
} from "@heroui/react";
import { useEffect, useMemo, useRef, useState } from "react";
import { queryToParams, type Facets, type RuleQuery } from "@/lib/filter";
import type { RuleListItem } from "@/lib/types";
import type { SnapshotMeta } from "@/lib/api";
import { ThemeToggle } from "@/components/theme-toggle";

interface RulesResponse {
  meta: SnapshotMeta;
  facets: Facets;
  page: number;
  pageSize: number;
  total: number;
  pageCount: number;
  rules: RuleListItem[];
}

interface Filters {
  q: string;
  subscriptionId: string;
  vnet: string;
  subnet: string;
  target: string;
  direction: string;
  action: string;
  protocol: string;
  port: string;
  priorityMin: string;
  priorityMax: string;
  source: string;
  destination: string;
}

const EMPTY_FILTERS: Filters = {
  q: "",
  subscriptionId: "",
  vnet: "",
  subnet: "",
  target: "",
  direction: "",
  action: "",
  protocol: "",
  port: "",
  priorityMin: "",
  priorityMax: "",
  source: "",
  destination: "",
};

const SOURCE_LABEL: Record<string, string> = {
  nsg: "NSG",
  "firewall-policy": "Policy",
  "firewall-classic": "Classic",
};

function toQuery(filters: Filters, page: number, sort: string, sortDir: "asc" | "desc"): RuleQuery {
  return {
    q: filters.q,
    subscriptionId: filters.subscriptionId,
    vnet: filters.vnet,
    subnet: filters.subnet,
    target: filters.target,
    direction: filters.direction,
    action: filters.action,
    protocol: filters.protocol,
    port: filters.port,
    priorityMin: numberOrNull(filters.priorityMin),
    priorityMax: numberOrNull(filters.priorityMax),
    source: filters.source,
    destination: filters.destination,
    page,
    pageSize: 25,
    sort,
    sortDir,
  };
}

function numberOrNull(value: string): number | null {
  if (!value.trim()) return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function formatStamp(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  const formatted = new Intl.DateTimeFormat("en-GB", {
    year: "numeric",
    month: "short",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hourCycle: "h23",
    timeZone: "UTC",
  }).format(date);
  const milliseconds = String(date.getUTCMilliseconds()).padStart(3, "0");
  return `${formatted}.${milliseconds} UTC`;
}

function showList(values: string[]): string {
  return values.length ? values.join(", ") : "—";
}

function actionColor(action: string): "success" | "danger" | "warning" | "default" {
  if (action === "Allow") return "success";
  if (action === "Deny") return "danger";
  if (action === "DNAT") return "warning";
  return "default";
}

export function RulesExplorer() {
  const [draftSearch, setDraftSearch] = useState("");
  const [filters, setFilters] = useState<Filters>(EMPTY_FILTERS);
  const [page, setPage] = useState(1);
  const [sort, setSort] = useState({ column: "priority", direction: "ascending" as "ascending" | "descending" });
  const [data, setData] = useState<RulesResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [refreshing, setRefreshing] = useState(false);
  const [selected, setSelected] = useState<RuleListItem | null>(null);
  const [raw, setRaw] = useState<unknown>(undefined);
  const [rawError, setRawError] = useState("");

  useEffect(() => {
    const timer = setTimeout(() => {
      setFilters((current) => (current.q === draftSearch ? current : { ...current, q: draftSearch }));
      setPage(1);
    }, 300);
    return () => clearTimeout(timer);
  }, [draftSearch]);

  const query = useMemo(
    () => toQuery(filters, page, sort.column, sort.direction === "descending" ? "desc" : "asc"),
    [filters, page, sort],
  );

  useEffect(() => {
    const controller = new AbortController();
    const params = queryToParams(query);
    void fetch(`/api/rules?${params.toString()}`, { signal: controller.signal })
      .then(async (response) => {
        const body = (await response.json()) as RulesResponse & { error?: string };
        if (!response.ok) throw new Error(body.error || "Could not load rules.");
        setError("");
        setData(body);
        if (body.page !== query.page) setPage(body.page);
      })
      .catch((caught: unknown) => {
        if (caught instanceof DOMException && caught.name === "AbortError") return;
        setError(caught instanceof Error ? caught.message : "Could not load rules.");
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false);
      });
    return () => controller.abort();
  }, [query]);

  const facets = data?.facets;
  const vnetOptions = (facets?.vnets ?? []).filter((option) => !filters.subscriptionId || option.subscriptionId === filters.subscriptionId);
  const subnetOptions = (facets?.subnets ?? []).filter((option) => {
    if (filters.subscriptionId && option.subscriptionId !== filters.subscriptionId) return false;
    if (filters.vnet && option.vnet !== filters.vnet) return false;
    return true;
  });
  const targetOptions = (facets?.targets ?? []).filter((option) => !filters.subscriptionId || option.subscriptionId === filters.subscriptionId);

  function update(partial: Partial<Filters>) {
    setLoading(true);
    setError("");
    setFilters((current) => ({ ...current, ...partial }));
    setPage(1);
  }

  async function refresh() {
    setRefreshing(true);
    setNotice("");
    setError("");
    try {
      const response = await fetch("/api/refresh", { method: "POST" });
      const body = (await response.json()) as { error?: string; meta?: SnapshotMeta };
      if (response.status === 409) {
        setNotice(body.error || "A collection is already running.");
        return;
      }
      if (!response.ok) throw new Error(body.error || "Refresh failed.");
      setNotice(`Snapshot refreshed at ${formatStamp(body.meta?.generatedAt ?? "")}.`);
      setPage(1);
      setFilters((current) => ({ ...current }));
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Refresh failed.");
    } finally {
      setRefreshing(false);
    }
  }

  async function openRule(rule: RuleListItem) {
    setSelected(rule);
    setRaw(undefined);
    setRawError("");
    try {
      const response = await fetch(`/api/rule?id=${encodeURIComponent(rule.id)}`);
      const body = (await response.json()) as { error?: string; rule?: { raw?: unknown } };
      if (!response.ok) throw new Error(body.error || "Could not load the rule.");
      setRaw(body.rule?.raw);
    } catch (caught) {
      setRawError(caught instanceof Error ? caught.message : "Could not load the rule.");
    }
  }

  async function exportCsv() {
    setError("");
    const params = queryToParams({ ...query, page: 1 }, { page: false });
    const response = await fetch(`/api/export?${params.toString()}`);
    if (!response.ok) {
      const body = (await response.json().catch(() => ({}))) as { error?: string };
      setError(body.error || "Export failed.");
      return;
    }
    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    const disposition = response.headers.get("content-disposition") ?? "";
    const match = /filename="([^"]+)"/.exec(disposition);
    anchor.download = match?.[1] ?? "nsg-firewall-rules.csv";
    anchor.click();
    URL.revokeObjectURL(url);
  }

  const meta = data?.meta;
  const pageCount = data?.pageCount ?? 0;
  const start = data && data.total > 0 ? (data.page - 1) * data.pageSize + 1 : 0;
  const end = data ? Math.min(data.page * data.pageSize, data.total) : 0;

  return (
    <div className="min-h-full bg-background text-foreground">
      <header className="border-b border-border px-4 py-4 md:px-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-2xl font-semibold tracking-tight">NSG & Firewall Rules</h1>
              <Chip color="accent" size="sm" variant="soft">Read-only</Chip>
              <Chip size="sm" variant="tertiary">{meta?.source === "azure" ? "Azure" : "Mock fixtures"}</Chip>
              {meta && (
                <Chip color={meta.status === "ok" ? "success" : meta.status === "partial" ? "warning" : "danger"} size="sm" variant="soft">
                  {meta.status === "ok" ? "Current" : meta.status === "partial" ? "Partial" : "Failed"}
                </Chip>
              )}
            </div>
            <p className="max-w-3xl text-sm text-muted">
              Network security group rules, including defaults, and Azure Firewall policy and classic rules across subscriptions.
              Nothing on this page changes Azure network resources.
            </p>
            {meta && !meta.authEnabled && (
              <p className="text-sm text-muted" data-testid="auth-banner">
                Authentication disabled (test mode)
              </p>
            )}
            <p className="text-sm" data-testid="last-refreshed">
              {meta ? (
                <>
                  {meta.source === "csv" ? "Last loaded" : "Last refreshed"} <time dateTime={meta.generatedAt}>{formatStamp(meta.generatedAt)}</time>
                  {" · "}
                  {meta.stats.rules.toLocaleString()} rules in the snapshot
                  {data ? ` · ${data.total.toLocaleString()} match` : ""}
                </>
              ) : (
                "Loading the latest snapshot"
              )}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <ThemeToggle />
            {meta?.authEnabled && (
              <Chip size="sm" variant="secondary">{meta.isAdmin ? `${meta.viewer.name} · admin` : meta.viewer.name}</Chip>
            )}
            {meta?.source === "csv" && (
              <CsvUpload
                onError={setError}
                onUploaded={() => {
                  setError("");
                  setFilters((current) => ({ ...current }));
                }}
              />
            )}
            {meta?.canRefresh && (
              <Button data-testid="refresh-snapshot" isDisabled={refreshing} onPress={() => void refresh()}>
                {refreshing ? "Refreshing…" : "Refresh snapshot"}
              </Button>
            )}
          </div>
        </div>
      </header>

      <main className="space-y-4 px-4 py-4 md:px-6">
        {meta && meta.loadIssues.length > 0 && (
          <Alert status="warning">
            <Alert.Indicator />
            <Alert.Content>
              <Alert.Title>{meta.loadIssues.length} CSV {meta.loadIssues.length === 1 ? "row was" : "rows were"} not imported</Alert.Title>
              <Alert.Description>
                {meta.loadIssues.slice(0, 8).map((issue) => `${issue.file} row ${issue.row}: ${issue.message}`).join(" ")}
              </Alert.Description>
            </Alert.Content>
          </Alert>
        )}
        {error && (
          <Alert status="danger">
            <Alert.Indicator />
            <Alert.Content>
              <Alert.Title>Could not complete the request</Alert.Title>
              <Alert.Description>{error}</Alert.Description>
            </Alert.Content>
          </Alert>
        )}
        {notice && (
          <Alert status={notice.startsWith("Snapshot refreshed") ? "success" : "warning"}>
            <Alert.Indicator />
            <Alert.Content>
              <Alert.Description>{notice}</Alert.Description>
            </Alert.Content>
          </Alert>
        )}
        {meta && meta.warnings.length > 0 && (
          <Alert status="warning">
            <Alert.Indicator />
            <Alert.Content>
              <Alert.Title>Collection warnings</Alert.Title>
              <Alert.Description>{meta.warnings.join(" ")}</Alert.Description>
            </Alert.Content>
          </Alert>
        )}

        <Card variant="secondary">
          <Card.Header>
            <Card.Title>Find a rule</Card.Title>
            <Card.Description>
              Search checks names, addresses, tags, ports, and descriptions. A port matches a destination port or a range.
              An IP matches an address, a CIDR, or a rule that allows every address. Other text matches service tags, ASGs, IP groups, and FQDNs.
            </Card.Description>
          </Card.Header>
          <Card.Content className="space-y-4">
            <SearchField aria-label="Search rules" fullWidth value={draftSearch} variant="secondary" onChange={setDraftSearch}>
              <SearchField.Group>
                <SearchField.SearchIcon />
                <SearchField.Input placeholder="Search rule, subscription, address, tag, ticket, description" />
                <SearchField.ClearButton />
              </SearchField.Group>
            </SearchField>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
              <FilterSelect
                label="Subscription"
                options={facets?.subscriptions ?? []}
                value={filters.subscriptionId}
                onChange={(value) => update({ subscriptionId: value, vnet: "", subnet: "", target: "" })}
              />
              <FilterSelect
                label="VNet"
                options={vnetOptions}
                value={optionKey(vnetOptions, filters.vnet)}
                onChange={(value) => update({ vnet: optionId(vnetOptions, value), subnet: "" })}
              />
              <FilterSelect
                label="Subnet"
                options={subnetOptions}
                value={optionKey(subnetOptions, filters.subnet)}
                onChange={(value) => update({ subnet: optionId(subnetOptions, value) })}
              />
              <FilterSelect
                label="NSG or firewall"
                options={targetOptions}
                value={optionKey(targetOptions, filters.target)}
                onChange={(value) => update({ target: optionId(targetOptions, value) })}
              />
              <FilterSelect
                label="Direction"
                options={(facets?.directions ?? ["Inbound", "Outbound", "n/a"]).map((id) => ({ id, key: id, label: id }))}
                value={filters.direction}
                onChange={(value) => update({ direction: value })}
              />
              <FilterSelect
                label="Action"
                options={(facets?.actions ?? ["Allow", "Deny", "DNAT"]).map((id) => ({ id, key: id, label: id }))}
                value={filters.action}
                onChange={(value) => update({ action: value })}
              />
              <FilterSelect
                label="Protocol"
                options={(facets?.protocols ?? []).map((id) => ({ id, key: id, label: id }))}
                value={filters.protocol}
                onChange={(value) => update({ protocol: value })}
              />
              <FilterText label="Destination port" placeholder="443 or 30000" value={filters.port} onChange={(port) => update({ port })} />
              <FilterText label="Priority min" placeholder="100" value={filters.priorityMin} onChange={(priorityMin) => update({ priorityMin })} />
              <FilterText label="Priority max" placeholder="4096" value={filters.priorityMax} onChange={(priorityMax) => update({ priorityMax })} />
              <FilterText label="Source" placeholder="IP, CIDR, tag, or ASG" value={filters.source} onChange={(source) => update({ source })} />
              <FilterText label="Destination" placeholder="IP, CIDR, FQDN, or tag" value={filters.destination} onChange={(destination) => update({ destination })} />
            </div>
          </Card.Content>
          <Card.Footer className="flex flex-wrap gap-2">
            <Button
              variant="tertiary"
              onPress={() => {
                setLoading(true);
                setDraftSearch("");
                setFilters(EMPTY_FILTERS);
                setPage(1);
              }}
            >
              Clear filters
            </Button>
            <Button variant="secondary" onPress={() => void exportCsv()}>
              Export CSV
            </Button>
          </Card.Footer>
        </Card>

        {loading && !data ? (
          <div className="flex items-center gap-3 py-16">
            <Spinner />
            <span>Loading rules</span>
          </div>
        ) : (
          <Table>
            <Table.ScrollContainer className="max-h-[calc(100vh-16rem)]">
              <Table.Content
                aria-label="NSG and firewall rules"
                className="min-w-[1500px]"
                sortDescriptor={sort}
                onRowAction={(key) => {
                  const rule = data?.rules.find((item) => item.id === String(key));
                  if (rule) void openRule(rule);
                }}
                onSortChange={(descriptor) => {
                  setLoading(true);
                  setSort({
                    column: String(descriptor.column),
                    direction: descriptor.direction === "descending" ? "descending" : "ascending",
                  });
                  setPage(1);
                }}
              >
                <Table.Header>
                  <SortColumn id="ruleName" isRowHeader>Rule</SortColumn>
                  <SortColumn id="subscriptionName">Subscription</SortColumn>
                  <SortColumn id="vnet">VNet</SortColumn>
                  <Table.Column id="subnet">Subnet</Table.Column>
                  <SortColumn id="nsgOrFirewallName">NSG / firewall</SortColumn>
                  <SortColumn id="direction">Direction</SortColumn>
                  <SortColumn id="action">Action</SortColumn>
                  <SortColumn id="priority">Priority</SortColumn>
                  <SortColumn id="protocol">Protocol</SortColumn>
                  <Table.Column id="ports">Dest ports</Table.Column>
                  <Table.Column id="source">Source</Table.Column>
                  <Table.Column id="destination">Destination</Table.Column>
                </Table.Header>
                <Table.Body
                  items={data?.rules ?? []}
                  renderEmptyState={() => <EmptyState className="py-10">No rules match these filters.</EmptyState>}
                >
                  {(rule) => (
                    <Table.Row id={rule.id} className="cursor-pointer">
                      <Table.Cell>
                        <div className="flex flex-col gap-1">
                          <span className="font-medium">{rule.ruleName}</span>
                          <span className="flex flex-wrap gap-1">
                            <Chip size="sm" variant="tertiary">{SOURCE_LABEL[rule.sourceType] ?? rule.sourceType}</Chip>
                            {rule.isDefault && <Chip color="warning" size="sm" variant="soft">Default</Chip>}
                          </span>
                        </div>
                      </Table.Cell>
                      <Table.Cell>{rule.subscriptionName}</Table.Cell>
                      <Table.Cell>{rule.vnet || "—"}</Table.Cell>
                      <Table.Cell>{showList(rule.subnets)}</Table.Cell>
                      <Table.Cell>
                        <div className="flex flex-col">
                          <span>{rule.nsgOrFirewallName || "—"}</span>
                          {rule.policyName && <span className="text-xs text-muted">{rule.policyName}</span>}
                        </div>
                      </Table.Cell>
                      <Table.Cell><Chip size="sm" variant="soft">{rule.direction}</Chip></Table.Cell>
                      <Table.Cell><Chip color={actionColor(rule.action)} size="sm" variant="soft">{rule.action}</Chip></Table.Cell>
                      <Table.Cell className="font-mono text-xs">{rule.priorityLabel || "—"}</Table.Cell>
                      <Table.Cell>{showList(rule.protocols)}</Table.Cell>
                      <Table.Cell className="font-mono text-xs">{showList(rule.destinationPorts)}</Table.Cell>
                      <Table.Cell><Clip value={showList(rule.sourceAddresses)} /></Table.Cell>
                      <Table.Cell>
                        <Clip value={rule.translatedAddress ? `${showList(rule.destinationAddresses)} → ${rule.translatedAddress}${rule.translatedPort ? `:${rule.translatedPort}` : ""}` : showList(rule.destinationAddresses)} />
                      </Table.Cell>
                    </Table.Row>
                  )}
                </Table.Body>
              </Table.Content>
            </Table.ScrollContainer>
            <Table.Footer>
              <Pagination size="sm">
                <Pagination.Summary>
                  {loading ? "Updating results" : data && data.total > 0 ? `${start}–${end} of ${data.total}` : "No results"}
                </Pagination.Summary>
                <Pagination.Content>
                  <Pagination.Item>
                    <Pagination.Previous isDisabled={page <= 1} onPress={() => { setLoading(true); setPage((current) => Math.max(1, current - 1)); }}>
                      <Pagination.PreviousIcon />
                      Prev
                    </Pagination.Previous>
                  </Pagination.Item>
                  {pageWindow(page, pageCount).map((entry) => (
                    <Pagination.Item key={entry}>
                      <Pagination.Link isActive={entry === page} onPress={() => { setLoading(true); setPage(entry); }}>
                        {entry}
                      </Pagination.Link>
                    </Pagination.Item>
                  ))}
                  <Pagination.Item>
                    <Pagination.Next isDisabled={pageCount === 0 || page >= pageCount} onPress={() => { setLoading(true); setPage((current) => current + 1); }}>
                      Next
                      <Pagination.NextIcon />
                    </Pagination.Next>
                  </Pagination.Item>
                </Pagination.Content>
              </Pagination>
            </Table.Footer>
          </Table>
        )}
      </main>

      <Modal
        isOpen={selected != null}
        onOpenChange={(open) => {
          if (!open) setSelected(null);
        }}
      >
        <Modal.Backdrop variant="blur">
          <Modal.Container scroll="inside" size="cover">
            <Modal.Dialog>
              <Modal.CloseTrigger />
              <Modal.Header>
                <Modal.Heading>{selected?.ruleName}</Modal.Heading>
              </Modal.Header>
              <Modal.Body>
                {selected && (
                  <div className="space-y-4">
                    <div className="flex flex-wrap gap-2">
                      <Chip size="sm" variant="tertiary">{SOURCE_LABEL[selected.sourceType] ?? selected.sourceType}</Chip>
                      <Chip color={actionColor(selected.action)} size="sm" variant="soft">{selected.action}</Chip>
                      <Chip size="sm" variant="soft">{selected.direction}</Chip>
                      {selected.isDefault && <Chip color="warning" size="sm" variant="soft">Default NSG rule</Chip>}
                    </div>
                    <dl className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                      <Field label="Subscription" value={`${selected.subscriptionName} (${selected.subscriptionId})`} />
                      <Field label="Resource group" value={selected.resourceGroup} />
                      <Field label="Location" value={selected.location} />
                      <Field label="VNet" value={selected.vnet} />
                      <Field label="Subnets" value={showList(selected.subnets)} />
                      <Field label="NIC" value={selected.nic} />
                      <Field label="Virtual machine" value={selected.vmName} />
                      <Field label="NSG or firewall" value={selected.nsgOrFirewallName} />
                      <Field label="Policy" value={selected.policyName} />
                      <Field label="Collection group" value={selected.collectionGroupName ? `${selected.collectionGroupName} (${selected.collectionGroupPriority ?? "—"})` : ""} />
                      <Field label="Collection" value={selected.collectionName ? `${selected.collectionName} (${selected.collectionPriority ?? "—"})` : ""} />
                      <Field label="Rule type" value={selected.ruleType} />
                      <Field label="Priority" value={selected.priorityLabel} />
                      <Field label="Protocols" value={showList(selected.protocols)} />
                      <Field label="Source ports" value={showList(selected.sourcePorts)} wide />
                      <Field label="Destination ports" value={showList(selected.destinationPorts)} wide />
                      <Field label="Source" value={showList(selected.sourceAddresses)} wide />
                      <Field label="Destination" value={showList(selected.destinationAddresses)} wide />
                      <Field label="Translated address" value={selected.translatedAddress} />
                      <Field label="Translated port" value={selected.translatedPort} />
                      <Field label="Description" value={selected.description} wide />
                      <Field label="Resource id" value={selected.resourceId} wide />
                    </dl>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between gap-2">
                        <h2 className="text-sm font-medium">Raw JSON</h2>
                        <Button
                          isDisabled={raw == null}
                          size="sm"
                          variant="tertiary"
                          onPress={() => void navigator.clipboard.writeText(JSON.stringify(raw, null, 2))}
                        >
                          Copy JSON
                        </Button>
                      </div>
                      {rawError && <p className="text-sm text-danger">{rawError}</p>}
                      {raw == null && !rawError ? (
                        <div className="flex items-center gap-2 text-sm text-muted"><Spinner size="sm" /> Loading resource JSON</div>
                      ) : (
                        <pre className="max-h-80 overflow-auto rounded-xl bg-surface p-3 font-mono text-xs">{JSON.stringify(raw, null, 2)}</pre>
                      )}
                    </div>
                  </div>
                )}
              </Modal.Body>
              <Modal.Footer>
                <Button variant="tertiary" onPress={() => setSelected(null)}>Done</Button>
              </Modal.Footer>
            </Modal.Dialog>
          </Modal.Container>
        </Modal.Backdrop>
      </Modal>
    </div>
  );
}

function CsvUpload({ onUploaded, onError }: { onUploaded: () => void; onError: (message: string) => void }) {
  const input = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  return (
    <>
      <Button isDisabled={busy} variant="secondary" onPress={() => input.current?.click()}>
        {busy ? "Uploading…" : "Upload CSV"}
      </Button>
      <input
        ref={input}
        accept=".csv,text/csv"
        aria-label="Upload CSV"
        className="sr-only"
        multiple
        type="file"
        onChange={(event) => {
          const files = event.target.files;
          if (!files || files.length === 0) return;
          const body = new FormData();
          for (const file of files) body.append("files", file);
          setBusy(true);
          void fetch("/api/upload", { method: "POST", body })
            .then(async (response) => {
              if (!response.ok) {
                const payload = (await response.json().catch(() => ({}))) as { error?: string };
                throw new Error(payload.error || "Upload failed.");
              }
              onUploaded();
            })
            .catch((caught: unknown) => onError(caught instanceof Error ? caught.message : "Upload failed."))
            .finally(() => {
              setBusy(false);
              event.target.value = "";
            });
        }}
      />
    </>
  );
}

function SortColumn({ id, children, isRowHeader = false }: { id: string; children: string; isRowHeader?: boolean }) {
  return (
    <Table.Column allowsSorting id={id} isRowHeader={isRowHeader}>
      {({ sortDirection }) => (
        <Table.SortableColumnHeader sortDirection={sortDirection ?? undefined}>{children}</Table.SortableColumnHeader>
      )}
    </Table.Column>
  );
}

function Clip({ value }: { value: string }) {
  return <span className="block max-w-64 truncate" title={value}>{value}</span>;
}

function Field({ label, value, wide = false }: { label: string; value: string; wide?: boolean }) {
  return (
    <div className={wide ? "sm:col-span-2" : undefined}>
      <dt className="text-xs text-muted">{label}</dt>
      <dd className="break-words font-mono text-xs">{value || "—"}</dd>
    </div>
  );
}

function FilterText({ label, value, onChange, placeholder }: { label: string; value: string; onChange: (value: string) => void; placeholder: string }) {
  return (
    <TextField fullWidth value={value} variant="secondary" onChange={onChange}>
      <Label>{label}</Label>
      <Input placeholder={placeholder} />
    </TextField>
  );
}

function FilterSelect({
  label,
  options,
  value,
  onChange,
}: {
  label: string;
  options: { id: string; key: string; label: string }[];
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <Select
      aria-label={label}
      fullWidth
      placeholder={`Any ${label.toLowerCase()}`}
      value={value || null}
      variant="secondary"
      onChange={(next) => onChange(next == null ? "" : String(next))}
    >
      <Label>{label}</Label>
      <Select.Trigger>
        <Select.Value />
        <Select.ClearButton />
        <Select.Indicator />
      </Select.Trigger>
      <Select.Popover>
        <ListBox>
          {options.map((option) => (
            <ListBox.Item key={option.key} id={option.key} textValue={option.label}>
              {option.label}
              <ListBox.ItemIndicator />
            </ListBox.Item>
          ))}
        </ListBox>
      </Select.Popover>
    </Select>
  );
}

function optionKey(options: { id: string; key: string }[], id: string): string {
  return options.find((option) => option.id === id)?.key ?? "";
}

function optionId(options: { id: string; key: string }[], key: string): string {
  return options.find((option) => option.key === key)?.id ?? "";
}

function pageWindow(page: number, pageCount: number): number[] {
  if (pageCount <= 1) return pageCount === 1 ? [1] : [];
  const pages: number[] = [];
  const start = Math.max(1, page - 2);
  const end = Math.min(pageCount, start + 4);
  for (let current = Math.max(1, end - 4); current <= end; current += 1) pages.push(current);
  return pages;
}

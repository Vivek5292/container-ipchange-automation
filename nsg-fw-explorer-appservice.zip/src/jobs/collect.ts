import { runCollectWithLock } from "../lib/collector/run";

async function main(): Promise<void> {
  const result = await runCollectWithLock(`webjob:${process.pid}`);
  if (!result.acquired) {
    console.log("[collector] another collection holds the lock; exiting");
    return;
  }
  if (result.snapshot?.status === "error") {
    console.error(`[collector] ${result.snapshot.error ?? "collection failed"}`);
    process.exitCode = 1;
  }
}

main().catch((error: unknown) => {
  console.error(error instanceof Error ? error.message : error);
  process.exitCode = 1;
});

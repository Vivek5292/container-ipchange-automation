import { gate, snapshotMeta } from "@/lib/api";
import { runCollectWithLock } from "@/lib/collector/run";
import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  const auth = gate(request, true);
  if ("response" in auth) return auth.response;
  const result = await runCollectWithLock(`manual:${auth.principal.userId || auth.principal.name}`);
  if (!result.acquired || !result.snapshot) {
    return NextResponse.json(
      { error: "A collection is already running. Wait for it to finish, then refresh the page." },
      { status: 409 },
    );
  }
  return NextResponse.json({
    meta: snapshotMeta(result.snapshot, auth.principal),
  });
}

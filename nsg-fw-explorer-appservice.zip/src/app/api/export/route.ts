import { loadRules } from "@/lib/api";
import { rulesToCsv } from "@/lib/csv";
import type { NextRequest } from "next/server";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const loaded = await loadRules(request);
  if ("response" in loaded) return loaded.response;
  const csv = rulesToCsv(loaded.matched);
  const stamp = loaded.snapshot.generatedAt.replaceAll(":", "-");
  return new Response(csv, {
    headers: {
      "content-type": "text/csv; charset=utf-8",
      "content-disposition": `attachment; filename="nsg-firewall-rules-${stamp}.csv"`,
    },
  });
}

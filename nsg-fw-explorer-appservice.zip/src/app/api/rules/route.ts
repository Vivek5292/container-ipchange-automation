import { loadRules, snapshotMeta } from "@/lib/api";
import type { NextRequest } from "next/server";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const loaded = await loadRules(request);
  if ("response" in loaded) return loaded.response;
  return Response.json({
    meta: snapshotMeta(loaded.snapshot, loaded.principal),
    facets: loaded.facets,
    page: loaded.page.page,
    pageSize: loaded.page.pageSize,
    total: loaded.page.total,
    pageCount: loaded.page.pageCount,
    rules: loaded.rules,
  });
}

import { gate, snapshotMeta } from "@/lib/api";
import { importUploadedCsvs } from "@/lib/csv-store";
import { loadConfig } from "@/lib/config";
import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  const auth = gate(request);
  if ("response" in auth) return auth.response;
  if (loadConfig().dataSource !== "csv") {
    return NextResponse.json({ error: "CSV upload is only available when DATA_SOURCE=csv." }, { status: 400 });
  }
  const form = await request.formData();
  const files = form.getAll("files").filter((entry): entry is File => entry instanceof File);
  if (files.length === 0) return NextResponse.json({ error: "Choose at least one CSV file." }, { status: 400 });
  const parsed = await Promise.all(files.map(async (file) => ({ name: file.name, text: await file.text() })));
  const { snapshot, issues } = await importUploadedCsvs(parsed);
  return NextResponse.json({
    meta: snapshotMeta(snapshot, auth.principal),
    imported: snapshot.stats.rules,
    issues,
  });
}

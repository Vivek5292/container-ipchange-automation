import { gate } from "@/lib/api";
import { ensureSnapshot } from "@/lib/collector/run";
import { toListItem } from "@/lib/filter";
import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const auth = gate(request);
  if ("response" in auth) return auth.response;
  const id = request.nextUrl.searchParams.get("id")?.trim();
  if (!id) return NextResponse.json({ error: "Rule id is required." }, { status: 400 });
  try {
    const snapshot = await ensureSnapshot();
    const rule = snapshot.rules.find((item) => item.id === id);
    if (!rule) return NextResponse.json({ error: "Rule not found in the latest snapshot." }, { status: 404 });
    return NextResponse.json({ rule: { ...toListItem(rule), raw: rule.raw } });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Could not load the rule.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

import { RulesExplorer } from "@/components/rules-explorer";

export default function HomePage() {
  return <RulesExplorer />;
}

import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "NSG & Firewall Rules",
  description: "Read-only inventory of Azure NSG and Azure Firewall rules for cloud operations.",
};

const themeScript = `(function(){try{var stored=localStorage.getItem("heroui-theme");var theme=stored&&stored!=="system"?stored:(window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light");if(theme!=="light"&&theme!=="dark")theme="light";var root=document.documentElement;root.classList.remove("light","dark");root.classList.add(theme);root.setAttribute("data-theme",theme);}catch(e){}})();`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="light h-full" data-theme="light" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
      </head>
      <body className="min-h-full bg-background text-foreground antialiased">{children}</body>
    </html>
  );
}

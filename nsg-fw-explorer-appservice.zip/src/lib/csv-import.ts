import { createHash } from "node:crypto";
import { buildSearchText, normalizeAction, normalizeDirection, normalizeProtocol, ruleId } from "./arm";
import type { CsvLoadIssue, RuleAction, RuleKind, RuleRow, SourceType } from "./types";

export interface ParsedCsvFile {
  name: string;
  rules: RuleRow[];
  issues: CsvLoadIssue[];
  hash: string;
}

const ALIASES: Record<string, string> = {
  priority: "priority",
  name: "name",
  rulename: "name",
  port: "destPorts",
  ports: "destPorts",
  destinationport: "destPorts",
  destinationports: "destPorts",
  destinationportrange: "destPorts",
  destinationportranges: "destPorts",
  sourceport: "srcPorts",
  sourceports: "srcPorts",
  sourceportrange: "srcPorts",
  sourceportranges: "srcPorts",
  protocol: "protocols",
  protocols: "protocols",
  ipprotocols: "protocols",
  source: "source",
  sourceaddress: "source",
  sourceaddresses: "source",
  sourceaddressprefix: "source",
  sourceaddressprefixes: "source",
  destination: "destination",
  destinationaddress: "destination",
  destinationaddresses: "destination",
  destinationaddressprefix: "destination",
  destinationaddressprefixes: "destination",
  action: "action",
  access: "action",
  actiontype: "action",
  direction: "direction",
  description: "description",
  nsg: "nsg",
  nsgname: "nsg",
  networksecuritygroup: "nsg",
  resourcegroup: "resourceGroup",
  resourcegroupname: "resourceGroup",
  subscription: "subscriptionName",
  subscriptionname: "subscriptionName",
  subscriptionid: "subscriptionId",
  location: "location",
  nsglocation: "location",
  subnet: "subnet",
  subnetname: "subnet",
  subnetassignmentname: "subnet",
  nic: "nic",
  nicname: "nic",
  nicassignmentname: "nic",
  default: "isDefault",
  isdefault: "isDefault",
  ruletype: "ruleKind",
  rulecollectiontype: "ruleKind",
  ruleconnectiontype: "ruleKind",
  rulecollection: "collection",
  rulecollectionname: "collection",
  collection: "collection",
  collectionname: "collection",
  collectionpriority: "collectionPriority",
  rulepriority: "collectionPriority",
  rulecollectionpriority: "collectionPriority",
  priorityrulecollection: "collectionPriority",
  collectiongroup: "collectionGroup",
  collectiongroupname: "collectionGroup",
  rulecollectiongroup: "collectionGroup",
  collectiongrouppriority: "groupPriority",
  grouppriority: "groupPriority",
  priorityrulecollectiongroup: "groupPriority",
  firewall: "firewall",
  firewallname: "firewall",
  policy: "policy",
  policyname: "policy",
  translatedaddress: "translatedAddress",
  translatedip: "translatedAddress",
  translatedfqdn: "translatedAddress",
  translatedport: "translatedPort",
  destinationfqdn: "fqdn",
  destinationfqdns: "fqdn",
  targetfqdn: "fqdn",
  targetfqdns: "fqdn",
  fqdn: "fqdn",
  fqdns: "fqdn",
  fqdntag: "fqdnTags",
  fqdntags: "fqdnTags",
  sourceipgroup: "sourceIpGroups",
  sourceipgroups: "sourceIpGroups",
  destinationipgroup: "destIpGroups",
  destinationipgroups: "destIpGroups",
};

const NSG_HINTS = new Set(["nsg", "direction", "destPorts", "srcPorts", "source", "destination", "action", "priority", "name"]);
const FIREWALL_HINTS = new Set(["ruleKind", "collection", "collectionGroup", "fqdn", "fqdnTags", "translatedAddress", "translatedPort", "sourceIpGroups", "destIpGroups", "firewall", "policy"]);

export function normalizeHeader(header: string): string {
  return header.replace(/^\uFEFF/, "").toLowerCase().replace(/[^a-z0-9]+/g, "");
}

export function detectDelimiter(text: string): "," | ";" {
  const sample = text.replace(/^\uFEFF/, "").split(/\r?\n/, 1)[0] ?? "";
  const commas = countOutsideQuotes(sample, ",");
  const semis = countOutsideQuotes(sample, ";");
  return semis > commas ? ";" : ",";
}

function countOutsideQuotes(line: string, delimiter: string): number {
  let count = 0;
  let quoted = false;
  for (let i = 0; i < line.length; i += 1) {
    const char = line[i];
    if (char === '"') {
      if (quoted && line[i + 1] === '"') i += 1;
      else quoted = !quoted;
    } else if (!quoted && char === delimiter) count += 1;
  }
  return count;
}

/** RFC-style CSV: quotes, escaped quotes, newlines inside quotes, comma or semicolon. */
export function parseCsvTable(text: string, delimiter: "," | ";" = detectDelimiter(text)): string[][] {
  const source = text.replace(/^\uFEFF/, "").replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = "";
  let quoted = false;
  for (let i = 0; i < source.length; i += 1) {
    const char = source[i];
    if (quoted) {
      if (char === '"') {
        if (source[i + 1] === '"') {
          cell += '"';
          i += 1;
        } else quoted = false;
      } else cell += char;
      continue;
    }
    if (char === '"') {
      quoted = true;
      continue;
    }
    if (char === delimiter) {
      row.push(cell);
      cell = "";
      continue;
    }
    if (char === "\n") {
      row.push(cell);
      if (row.some((value) => value.trim())) rows.push(row);
      row = [];
      cell = "";
      continue;
    }
    cell += char;
  }
  row.push(cell);
  if (row.some((value) => value.trim())) rows.push(row);
  return rows;
}

export function splitMultiValue(value: string): string[] {
  const parts = value.split(/[,;|]/).map((part) => part.trim()).filter(Boolean);
  return parts.length ? parts : [];
}

function asBool(value: string | undefined): boolean {
  const text = (value ?? "").trim().toLowerCase();
  return text === "true" || text === "yes" || text === "1" || text === "default";
}

function mapHeaders(headers: string[]): { keys: Array<string | null>; unknown: string[] } {
  const keys = headers.map((header) => ALIASES[normalizeHeader(header)] ?? null);
  const unknown = headers.filter((_, index) => keys[index] == null && headers[index].trim());
  return { keys, unknown };
}

function scoreKind(keys: Array<string | null>): "nsg" | "firewall" | "unknown" {
  const present = new Set(keys.filter((key): key is string => Boolean(key)));
  let nsg = 0;
  let firewall = 0;
  for (const key of present) {
    if (NSG_HINTS.has(key)) nsg += 1;
    if (FIREWALL_HINTS.has(key)) firewall += 1;
  }
  const firewallSpecific = ["ruleKind", "collection", "collectionGroup", "translatedAddress", "fqdn", "fqdnTags", "firewall", "policy"];
  if (!present.has("nsg") && firewallSpecific.some((key) => present.has(key))) return "firewall";
  if (firewall >= 2 && firewall >= nsg) return "firewall";
  if (nsg >= 4) return "nsg";
  return "unknown";
}

function recordFromRow(headers: string[], keys: Array<string | null>, cells: string[]): { known: Record<string, string>; unknown: Record<string, string> } {
  const known: Record<string, string> = {};
  const unknown: Record<string, string> = {};
  headers.forEach((header, index) => {
    const value = cells[index] ?? "";
    const key = keys[index];
    if (!key) {
      if (header.trim() && value.trim()) unknown[header] = value;
      return;
    }
    const previous = known[key];
    known[key] = previous && value.trim() ? `${previous}, ${value}` : value || previous || "";
  });
  return { known, unknown };
}

function ruleKindFrom(value: string, action: RuleAction): RuleKind {
  const text = value.toLowerCase();
  if (text.includes("application")) return "application";
  if (text.includes("nat") || text.includes("dnat") || action === "DNAT") return "nat";
  if (text.includes("default")) return "default";
  if (text.includes("network")) return "network";
  return "security";
}

export function parseRuleCsv(name: string, text: string): ParsedCsvFile {
  const hash = createHash("sha256").update(text).digest("hex");
  const table = parseCsvTable(text);
  if (table.length === 0) {
    return { name, rules: [], hash, issues: [{ file: name, row: 0, message: "The file is empty." }] };
  }
  const headers = table[0];
  const { keys, unknown } = mapHeaders(headers);
  const kind = scoreKind(keys);
  if (kind === "unknown") {
    return {
      name,
      rules: [],
      hash,
      issues: [{ file: name, row: 1, message: `Unrecognized columns: ${headers.filter(Boolean).join(", ") || "(none)"}. Expected an NSG or firewall rule export.` }],
    };
  }
  const rules: RuleRow[] = [];
  const issues: CsvLoadIssue[] = [];
  table.slice(1).forEach((cells, index) => {
    const rowNumber = index + 2;
    if (cells.every((cell) => !cell.trim())) return;
    const { known, unknown: extra } = recordFromRow(headers, keys, cells);
    const ruleName = known.name?.trim() ?? "";
    if (!ruleName) {
      issues.push({ file: name, row: rowNumber, message: "Rule name is missing." });
      return;
    }
    const action = normalizeAction(known.action);
    if (!action) {
      issues.push({ file: name, row: rowNumber, message: `Action "${known.action ?? ""}" is missing or not Allow, Deny, or DNAT.` });
      return;
    }
    const built = kind === "nsg"
      ? nsgRow(name, rowNumber, known, extra, unknown, action)
      : firewallRow(name, rowNumber, known, extra, unknown, action);
    rules.push(built);
  });
  return { name, rules, issues, hash };
}

function nsgRow(
  file: string,
  row: number,
  known: Record<string, string>,
  extra: Record<string, string>,
  unknownHeaders: string[],
  action: RuleAction,
): RuleRow {
  const direction = known.direction ? normalizeDirection(known.direction) : "Inbound";
  const protocols = splitMultiValue(known.protocols ?? "").map(normalizeProtocol);
  const priority = numberOrNull(known.priority);
  const isDefault = asBool(known.isDefault) || /^allowvnet|^denyall/i.test(known.name ?? "");
  const rule: RuleRow = {
    id: ruleId(["csv", file, String(row), known.name, direction]),
    sourceType: "nsg",
    subscriptionId: known.subscriptionId?.trim() || "",
    subscriptionName: known.subscriptionName?.trim() || known.subscriptionId?.trim() || "CSV import",
    resourceGroup: known.resourceGroup?.trim() || "",
    location: known.location?.trim() || "",
    vnet: "",
    subnets: splitMultiValue(known.subnet ?? ""),
    nic: known.nic?.trim() || "",
    vmName: "",
    nsgOrFirewallName: known.nsg?.trim() || "",
    resourceId: "",
    policyName: "",
    collectionGroupName: "",
    collectionGroupPriority: null,
    collectionName: "",
    collectionPriority: null,
    ruleName: known.name.trim(),
    ruleType: isDefault ? "default" : "security",
    direction,
    action,
    priority,
    priorityLabel: priority == null ? "" : String(priority),
    protocols,
    sourceAddresses: splitMultiValue(known.source ?? ""),
    destinationAddresses: splitMultiValue(known.destination ?? ""),
    sourcePorts: splitMultiValue(known.srcPorts ?? ""),
    destinationPorts: splitMultiValue(known.destPorts ?? ""),
    translatedAddress: "",
    translatedPort: "",
    isDefault,
    description: known.description?.trim() || "",
    raw: { file, row, unknownHeaders, unknown: extra, columns: known },
    searchText: "",
  };
  rule.searchText = buildSearchText([rule]);
  return rule;
}

function firewallRow(
  file: string,
  row: number,
  known: Record<string, string>,
  extra: Record<string, string>,
  unknownHeaders: string[],
  action: RuleAction,
): RuleRow {
  const ruleType = ruleKindFrom(known.ruleKind ?? "", action);
  const direction = known.direction
    ? normalizeDirection(known.direction)
    : action === "DNAT" || ruleType === "nat"
      ? "Inbound"
      : "Outbound";
  const groupPriority = numberOrNull(known.groupPriority);
  const collectionPriority = numberOrNull(known.collectionPriority) ?? (known.groupPriority ? null : numberOrNull(known.priority));
  const priority = groupPriority ?? collectionPriority;
  const sourceType: SourceType = /classic/i.test(known.ruleKind ?? "") ? "firewall-classic" : "firewall-policy";
  const destinations = [
    ...splitMultiValue(known.destination ?? ""),
    ...splitMultiValue(known.fqdn ?? ""),
    ...splitMultiValue(known.fqdnTags ?? "").map((tag) => (tag.startsWith("fqdn-tag:") ? tag : `fqdn-tag:${tag}`)),
    ...splitMultiValue(known.destIpGroups ?? "").map((group) => (group.startsWith("ip-group:") ? group : `ip-group:${group}`)),
  ];
  const sources = [
    ...splitMultiValue(known.source ?? ""),
    ...splitMultiValue(known.sourceIpGroups ?? "").map((group) => (group.startsWith("ip-group:") ? group : `ip-group:${group}`)),
  ];
  const rule: RuleRow = {
    id: ruleId(["csv", file, String(row), known.name, direction]),
    sourceType,
    subscriptionId: known.subscriptionId?.trim() || "",
    subscriptionName: known.subscriptionName?.trim() || known.subscriptionId?.trim() || "CSV import",
    resourceGroup: known.resourceGroup?.trim() || "",
    location: known.location?.trim() || "",
    vnet: "",
    subnets: splitMultiValue(known.subnet ?? ""),
    nic: "",
    vmName: "",
    nsgOrFirewallName: known.firewall?.trim() || known.policy?.trim() || "",
    resourceId: "",
    policyName: known.policy?.trim() || "",
    collectionGroupName: known.collectionGroup?.trim() || "",
    collectionGroupPriority: groupPriority,
    collectionName: known.collection?.trim() || "",
    collectionPriority,
    ruleName: known.name.trim(),
    ruleType,
    direction,
    action,
    priority,
    priorityLabel: [groupPriority, collectionPriority].filter((value) => value != null).join(" / ") || (priority == null ? "" : String(priority)),
    protocols: splitMultiValue(known.protocols ?? "").map(normalizeProtocol),
    sourceAddresses: sources,
    destinationAddresses: destinations,
    sourcePorts: splitMultiValue(known.srcPorts ?? ""),
    destinationPorts: splitMultiValue(known.destPorts ?? ""),
    translatedAddress: known.translatedAddress?.trim() || "",
    translatedPort: known.translatedPort?.trim() || "",
    isDefault: false,
    description: known.description?.trim() || "",
    raw: { file, row, unknownHeaders, unknown: extra, columns: known },
    searchText: "",
  };
  rule.searchText = buildSearchText([rule]);
  return rule;
}

function numberOrNull(value: string | undefined): number | null {
  if (!value || !value.trim()) return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

import { loadConfig } from "../config";
import { BlobSnapshotStore } from "./blob";
import { LocalSnapshotStore } from "./local";
import type { SnapshotStore } from "./types";

let store: SnapshotStore | null = null;
let storeKey = "";

export function getSnapshotStore(): SnapshotStore {
  const config = loadConfig();
  const key = config.snapshotStorageAccountUrl
    ? `blob:${config.snapshotStorageAccountUrl}/${config.snapshotContainer}`
    : `local:${config.localSnapshotDir}`;
  if (!store || storeKey !== key) {
    storeKey = key;
    store = config.snapshotStorageAccountUrl
      ? new BlobSnapshotStore(config)
      : new LocalSnapshotStore(config.localSnapshotDir);
  }
  return store;
}

export function resetSnapshotStore(): void {
  store = null;
  storeKey = "";
}

export type { SnapshotLock, SnapshotStore } from "./types";

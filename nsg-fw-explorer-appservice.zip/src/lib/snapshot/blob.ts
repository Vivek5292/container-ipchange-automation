import { DefaultAzureCredential } from "@azure/identity";
import { BlobServiceClient, RestError } from "@azure/storage-blob";
import { gunzipSync, gzipSync } from "node:zlib";
import type { AppConfig } from "../config";
import type { Snapshot } from "../types";
import type { SnapshotLock, SnapshotStore } from "./types";

/**
 * Snapshot blobs only. The lease blob stops overlapping collections.
 * Network resources are not modified from this store.
 */
export class BlobSnapshotStore implements SnapshotStore {
  private cache: { storedAt: number; snapshot: Snapshot } | null = null;
  private readonly service: BlobServiceClient;
  private readonly containerName: string;

  constructor(config: AppConfig) {
    this.service = new BlobServiceClient(config.snapshotStorageAccountUrl, new DefaultAzureCredential());
    this.containerName = config.snapshotContainer;
  }

  async readLatest(): Promise<Snapshot | null> {
    if (this.cache && Date.now() - this.cache.storedAt < 15_000) return this.cache.snapshot;
    const blob = this.container().getBlockBlobClient("snapshots/latest.json.gz");
    if (!(await blob.exists())) return null;
    const downloaded = await blob.downloadToBuffer();
    const snapshot = JSON.parse(decode(downloaded).toString("utf8")) as Snapshot;
    this.cache = { storedAt: Date.now(), snapshot };
    return snapshot;
  }

  async write(snapshot: Snapshot): Promise<void> {
    const body = gzipSync(Buffer.from(JSON.stringify(snapshot)));
    const stamp = snapshot.generatedAt.replaceAll(":", "-");
    const headers = { blobContentType: "application/json", blobContentEncoding: "gzip" };
    const container = this.container();
    await container.getBlockBlobClient(`snapshots/history/${stamp}.json.gz`).uploadData(body, { blobHTTPHeaders: headers });
    await container.getBlockBlobClient("snapshots/latest.json.gz").uploadData(body, { blobHTTPHeaders: headers });
    this.cache = { storedAt: Date.now(), snapshot };
  }

  async acquireLock(owner: string, ttlMs: number): Promise<SnapshotLock | null> {
    const blob = this.container().getBlockBlobClient("locks/collector.lock");
    const payload = Buffer.from(JSON.stringify({ owner }));
    try {
      await blob.upload(payload, payload.length, { conditions: { ifNoneMatch: "*" } });
    } catch (error) {
      if (!isStatus(error, 409) && !isStatus(error, 412)) throw error;
    }
    const leaseSeconds = Math.min(60, Math.max(15, Math.round(ttlMs / 1000)));
    const lease = blob.getBlobLeaseClient();
    try {
      await lease.acquireLease(leaseSeconds);
    } catch (error) {
      if (isStatus(error, 409)) return null;
      throw error;
    }
    return {
      renew: async () => {
        await lease.renewLease();
      },
      release: async () => {
        await lease.releaseLease();
      },
    };
  }

  private container() {
    return this.service.getContainerClient(this.containerName);
  }
}

function decode(buffer: Buffer): Buffer {
  if (buffer.length >= 2 && buffer[0] === 0x1f && buffer[1] === 0x8b) return gunzipSync(buffer);
  return buffer;
}

function isStatus(error: unknown, status: number): boolean {
  return error instanceof RestError && error.statusCode === status;
}

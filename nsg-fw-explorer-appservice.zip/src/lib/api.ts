import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { allowRefresh, isAdmin, resolveRequestPrincipal, type Principal } from "./auth";
import { loadConfig } from "./config";
import { ensureSnapshot } from "./collector/run";
import { buildFacets, filterRules, paginate, parseRuleQuery, toListItem, type Facets, type RuleQuery } from "./filter";
import type { RuleListItem, RuleRow, Snapshot } from "./types";

export function gate(request: NextRequest, admin = false): { principal: Principal } | { response: Response } {
  const resolved = resolveRequestPrincipal(request.headers.get("x-ms-client-principal"));
  if ("status" in resolved) {
    return { response: NextResponse.json({ error: resolved.error }, { status: resolved.status }) };
  }
  if (admin && !allowRefresh(resolved.principal, loadConfig())) {
    return {
      response: NextResponse.json(
        { error: "Manual refresh is limited to the admin group or the Rules.Admin app role." },
        { status: 403 },
      ),
    };
  }
  return { principal: resolved.principal };
}

export interface SnapshotMeta {
  generatedAt: string;
  finishedAt: string;
  status: Snapshot["status"];
  warnings: string[];
  error: string | null;
  source: Snapshot["source"];
  stats: Snapshot["stats"];
  authEnabled: boolean;
  isAdmin: boolean;
  canRefresh: boolean;
  viewer: { name: string; id: string };
  loadIssues: { file: string; row: number; message: string }[];
}

export function snapshotMeta(snapshot: Snapshot, principal: Principal): SnapshotMeta {
  const config = loadConfig();
  const admin = isAdmin(principal, config);
  return {
    generatedAt: snapshot.generatedAt,
    finishedAt: snapshot.finishedAt,
    status: snapshot.status,
    warnings: snapshot.warnings,
    error: snapshot.error ?? null,
    source: snapshot.source,
    stats: snapshot.stats,
    authEnabled: config.authEnabled,
    isAdmin: admin,
    canRefresh: allowRefresh(principal, config),
    viewer: { name: principal.name, id: principal.userId },
    loadIssues: snapshot.loadIssues ?? [],
  };
}

export async function loadRules(request: NextRequest): Promise<
  | { response: Response }
  | {
      principal: Principal;
      snapshot: Snapshot;
      query: RuleQuery;
      matched: RuleRow[];
      page: ReturnType<typeof paginate<RuleRow>>;
      facets: Facets;
      rules: RuleListItem[];
    }
> {
  const auth = gate(request);
  if ("response" in auth) return auth;
  try {
    const snapshot = await ensureSnapshot();
    const query = parseRuleQuery(request.nextUrl.searchParams);
    const matched = filterRules(snapshot.rules, query);
    const page = paginate(matched, query.page, query.pageSize);
    return {
      principal: auth.principal,
      snapshot,
      query,
      matched,
      page,
      facets: buildFacets(snapshot.rules),
      rules: page.items.map(toListItem),
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : "Could not load the snapshot.";
    return { response: NextResponse.json({ error: message }, { status: 500 }) };
  }
}

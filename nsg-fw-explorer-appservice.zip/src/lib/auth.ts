import { env, loadConfig, type AppConfig } from "./config";

export interface Principal {
  authenticated: boolean;
  name: string;
  userId: string;
  groups: string[];
  roles: string[];
  /** Set only for the local synthetic user, never for an Easy Auth principal. */
  devOverrideAdmin: boolean;
}

const ROLE_CLAIM = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role";
const GROUP_CLAIM = "http://schemas.microsoft.com/ws/2008/06/identity/claims/groupsid";
const NAME_CLAIM = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name";
const OID_CLAIM = "http://schemas.microsoft.com/identity/claims/objectidentifier";

interface EasyAuthClaim {
  typ?: string;
  val?: string;
}

interface EasyAuthPrincipal {
  auth_typ?: string;
  claims?: EasyAuthClaim[];
  name_typ?: string;
  role_typ?: string;
}

export function parsePrincipalHeader(header: string): Principal | null {
  try {
    const decoded = Buffer.from(header, "base64").toString("utf8");
    const parsed = JSON.parse(decoded) as EasyAuthPrincipal;
    if (!parsed || !Array.isArray(parsed.claims)) return null;
    const groups: string[] = [];
    const roles: string[] = [];
    let name = "";
    let userId = "";
    let preferred = "";
    for (const claim of parsed.claims) {
      const typ = claim.typ ?? "";
      const val = claim.val?.trim() ?? "";
      if (!val) continue;
      const type = typ.toLowerCase();
      if (type === "groups" || type === GROUP_CLAIM.toLowerCase()) groups.push(val);
      else if (type === "roles" || type === "role" || type === ROLE_CLAIM.toLowerCase() || type === (parsed.role_typ ?? "").toLowerCase()) {
        roles.push(val);
      } else if (type === "name" || type === NAME_CLAIM.toLowerCase()) name = val;
      else if (type === "preferred_username" || type === "upn") preferred = val;
      else if (type === "oid" || type === OID_CLAIM.toLowerCase()) userId = val;
    }
    return {
      authenticated: true,
      name: name || preferred || "Authenticated user",
      userId,
      groups,
      roles,
      devOverrideAdmin: false,
    };
  } catch {
    return null;
  }
}

export function syntheticPrincipal(config: AppConfig): Principal {
  return {
    authenticated: true,
    name: config.devIsAdmin ? "Local developer" : "Local reader",
    userId: "local",
    groups: config.adminGroupId && config.devIsAdmin ? [config.adminGroupId] : [],
    roles: config.devIsAdmin ? [config.adminRole, "Rules.Reader"] : ["Rules.Reader"],
    devOverrideAdmin: config.devIsAdmin,
  };
}

export function isAdmin(principal: Principal, config: AppConfig = loadConfig()): boolean {
  if (principal.devOverrideAdmin) return true;
  if (config.adminGroupId && principal.groups.includes(config.adminGroupId)) return true;
  if (config.adminRole && principal.roles.includes(config.adminRole)) return true;
  return false;
}

/** Easy Auth is the front door. When an ops group or role is configured, require it as well. */
export function canRead(principal: Principal, config: AppConfig = loadConfig()): boolean {
  if (!principal.authenticated) return false;
  if (isAdmin(principal, config)) return true;
  const restricted = Boolean(config.opsGroupId || config.opsRole);
  if (!restricted) return true;
  if (config.opsGroupId && principal.groups.includes(config.opsGroupId)) return true;
  if (config.opsRole && principal.roles.includes(config.opsRole)) return true;
  return false;
}

/** Manual refresh is open to every caller while user auth is off. The blob lease still serializes runs. */
export function allowRefresh(principal: Principal, config: AppConfig = loadConfig()): boolean {
  if (!config.authEnabled) return true;
  return isAdmin(principal, config);
}

export function resolveRequestPrincipal(header: string | null): { principal: Principal } | { status: 401 | 403; error: string } {
  const config = loadConfig();
  if (!config.authEnabled) return { principal: syntheticPrincipal(config) };
  if (header) {
    const principal = parsePrincipalHeader(header);
    if (!principal) {
      return { status: 401, error: "The Easy Auth principal header could not be read." };
    }
    if (!canRead(principal, config)) {
      return { status: 403, error: "This site is restricted to the operations security group." };
    }
    return { principal };
  }
  if (config.authMode === "easyauth" || env("NODE_ENV") === "production") {
    return {
      status: 401,
      error: "Sign-in required. App Service Authentication did not supply a principal.",
    };
  }
  return { principal: syntheticPrincipal(config) };
}

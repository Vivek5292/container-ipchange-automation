import type { Direction, RuleAction } from "./types";

export function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

/** ARM and Resource Graph sometimes nest fields under `properties`, sometimes flatten them. */
export function childProps(entry: unknown): Record<string, unknown> {
  if (!isRecord(entry)) return {};
  if (isRecord(entry.properties)) return entry.properties;
  return entry;
}

export function resourceName(id: string): string {
  const parts = id.split("/").filter(Boolean);
  return parts.at(-1) ?? id;
}

export function parseAzureId(id: string): { subscriptionId: string; resourceGroup: string; name: string } {
  const subscriptionId = /\/subscriptions\/([^/]+)/i.exec(id)?.[1] ?? "";
  const resourceGroup = /\/resourceGroups\/([^/]+)/i.exec(id)?.[1] ?? "";
  return { subscriptionId, resourceGroup, name: resourceName(id) };
}

export function parentResourceId(id: string, childType: string): string {
  const marker = `/${childType}/`;
  const index = id.toLowerCase().indexOf(marker.toLowerCase());
  if (index === -1) return id;
  return id.slice(0, index);
}

export function dedupe(values: string[]): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const value of values) {
    const trimmed = value.trim();
    if (!trimmed) continue;
    const key = trimmed.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(trimmed);
  }
  return out;
}

function pushToken(out: string[], value: string): void {
  const trimmed = value.trim();
  if (!trimmed) return;
  if (trimmed.includes(",")) {
    for (const part of trimmed.split(",")) pushToken(out, part);
    return;
  }
  out.push(trimmed);
}

/** Strings, string arrays, and `{ id }` references. Comma-separated tokens are split; ranges stay intact. */
export function looseTokens(value: unknown): string[] {
  const out: string[] = [];
  const visit = (entry: unknown) => {
    if (typeof entry === "string" || typeof entry === "number") {
      pushToken(out, String(entry));
      return;
    }
    if (Array.isArray(entry)) {
      for (const item of entry) visit(item);
      return;
    }
    if (isRecord(entry) && typeof entry.id === "string") {
      pushToken(out, resourceName(entry.id));
    }
  };
  visit(value);
  return dedupe(out);
}

export function readStrings(props: Record<string, unknown>, ...keys: string[]): string[] {
  return dedupe(keys.flatMap((key) => looseTokens(props[key])));
}

export function readResourceRefs(value: unknown, prefix: string): string[] {
  if (!Array.isArray(value)) {
    if (typeof value === "string" && value.trim()) return [`${prefix}${resourceName(value)}`];
    return [];
  }
  const names: string[] = [];
  for (const item of value) {
    if (typeof item === "string" && item.trim()) names.push(`${prefix}${resourceName(item)}`);
    else if (isRecord(item) && typeof item.id === "string") names.push(`${prefix}${resourceName(item.id)}`);
  }
  return dedupe(names);
}

const PROTOCOL_NAMES: Record<string, string> = {
  "*": "Any",
  any: "Any",
  tcp: "TCP",
  udp: "UDP",
  icmp: "ICMP",
  esp: "ESP",
  ah: "AH",
  http: "HTTP",
  https: "HTTPS",
  mssql: "MSSQL",
};

export function normalizeProtocol(value: string): string {
  const key = value.trim().toLowerCase();
  return PROTOCOL_NAMES[key] ?? value.trim().toUpperCase();
}

export function readProtocols(value: unknown): { protocols: string[]; ports: string[] } {
  const protocols: string[] = [];
  const ports: string[] = [];
  const visit = (entry: unknown) => {
    if (typeof entry === "string") {
      protocols.push(normalizeProtocol(entry));
      return;
    }
    if (Array.isArray(entry)) {
      for (const item of entry) visit(item);
      return;
    }
    if (!isRecord(entry)) return;
    const protocol = entry.protocolType ?? entry.protocol;
    if (typeof protocol === "string") protocols.push(normalizeProtocol(protocol));
    if (entry.port != null && String(entry.port).trim()) ports.push(String(entry.port).trim());
  };
  visit(value);
  return { protocols: dedupe(protocols), ports: dedupe(ports) };
}

export function normalizeAction(value: unknown): RuleAction | null {
  const raw = typeof value === "string" ? value : isRecord(value) && typeof value.type === "string" ? value.type : "";
  const normalized = raw.trim().toLowerCase();
  if (normalized === "allow") return "Allow";
  if (normalized === "deny") return "Deny";
  if (normalized === "dnat") return "DNAT";
  return null;
}

export function normalizeDirection(value: unknown): Direction {
  const normalized = String(value ?? "").trim().toLowerCase();
  if (normalized === "inbound") return "Inbound";
  if (normalized === "outbound") return "Outbound";
  return "n/a";
}

export function asNumber(value: unknown): number | null {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && value.trim() && Number.isFinite(Number(value))) return Number(value);
  return null;
}

export function asString(value: unknown): string {
  if (typeof value === "string") return value.trim();
  if (typeof value === "number" && Number.isFinite(value)) return String(value);
  return "";
}

export function linkedIds(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  const ids: string[] = [];
  for (const item of value) {
    if (typeof item === "string" && item.trim()) ids.push(item.trim());
    else if (isRecord(item) && typeof item.id === "string") ids.push(item.id);
  }
  return ids;
}

export function ruleId(parts: string[]): string {
  return parts.map((part) => part.replaceAll("|", "/")).join("|");
}

export function buildSearchText(fields: unknown[]): string {
  const chunks: string[] = [];
  const seen = new WeakSet<object>();
  const visit = (value: unknown) => {
    if (value == null) return;
    if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
      const text = String(value).trim();
      if (text) chunks.push(text);
      return;
    }
    if (typeof value !== "object") return;
    if (seen.has(value)) return;
    seen.add(value);
    if (Array.isArray(value)) {
      for (const item of value) visit(item);
      return;
    }
    for (const item of Object.values(value)) visit(item);
  };
  for (const field of fields) visit(field);
  return chunks.join("\n").toLowerCase();
}

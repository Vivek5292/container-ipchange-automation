import {
  asNumber,
  asString,
  buildSearchText,
  childProps,
  normalizeAction,
  readProtocols,
  readResourceRefs,
  readStrings,
  ruleId,
} from "../arm";
import type { ArmResource, NormalizeContext, RuleKind, RuleRow } from "../types";
import { placementForFirewall, resourceIdentity, subscriptionName } from "./context";

interface ClassicKind {
  property: "networkRuleCollections" | "applicationRuleCollections" | "natRuleCollections";
  ruleType: RuleKind;
}

const KINDS: ClassicKind[] = [
  { property: "networkRuleCollections", ruleType: "network" },
  { property: "applicationRuleCollections", ruleType: "application" },
  { property: "natRuleCollections", ruleType: "nat" },
];

function classicRuleRow(
  firewall: ArmResource,
  kind: ClassicKind,
  collection: unknown,
  rule: unknown,
  ctx: NormalizeContext,
): RuleRow | null {
  if (!rule || typeof rule !== "object" || !collection || typeof collection !== "object") return null;
  const collectionRecord = collection as Record<string, unknown>;
  const collectionProps = childProps(collection);
  const record = rule as Record<string, unknown>;
  const props = childProps(rule);
  const action =
    normalizeAction(collectionProps.action ?? collectionRecord.action) ?? (kind.ruleType === "nat" ? "DNAT" : null);
  if (!action) return null;

  const protocolInfo = readProtocols(props.protocols ?? props.ipProtocols ?? record.protocols);
  const sourceAddresses = [
    ...readStrings(props, "sourceAddresses", "sourceAddressPrefix", "sourceAddressPrefixes"),
    ...readResourceRefs(props.sourceIpGroups, "ip-group:"),
  ];
  const destinationAddresses = [
    ...readStrings(props, "destinationAddresses", "destinationAddressPrefix", "destinationAddressPrefixes", "targetFqdns", "destinationFqdns"),
    ...readResourceRefs(props.destinationIpGroups, "ip-group:"),
    ...readResourceRefs(props.fqdnTags, "fqdn-tag:"),
  ];
  const destinationPorts = [
    ...readStrings(props, "destinationPorts", "destinationPortRange", "destinationPortRanges"),
    ...protocolInfo.ports,
  ].filter((value, index, all) => value && all.indexOf(value) === index);
  const sourcePorts = readStrings(props, "sourcePorts", "sourcePortRange", "sourcePortRanges");
  const collectionName = asString(collectionRecord.name) || asString(collectionProps.name) || kind.property;
  const collectionPriority = asNumber(collectionProps.priority ?? collectionRecord.priority);
  const ruleName = asString(record.name) || asString(props.name) || "unnamed";
  const identity = resourceIdentity(firewall);
  const placement = placementForFirewall(firewall, ctx);
  const direction = action === "DNAT" || kind.ruleType === "nat" ? "Inbound" : "Outbound";
  const description = asString(props.description) || asString(collectionProps.description);

  const row: RuleRow = {
    id: ruleId(["firewall-classic", firewall.id, collectionName, ruleName, direction]),
    sourceType: "firewall-classic",
    subscriptionId: identity.subscriptionId,
    subscriptionName: subscriptionName(ctx, identity.subscriptionId),
    resourceGroup: identity.resourceGroup,
    location: identity.location,
    vnet: placement.vnet,
    subnets: placement.subnets,
    nic: "",
    vmName: "",
    nsgOrFirewallName: firewall.name,
    resourceId: firewall.id,
    policyName: "",
    collectionGroupName: "",
    collectionGroupPriority: null,
    collectionName,
    collectionPriority,
    ruleName,
    ruleType: kind.ruleType,
    direction,
    action,
    priority: collectionPriority,
    priorityLabel: collectionPriority == null ? "" : String(collectionPriority),
    protocols: protocolInfo.protocols,
    sourceAddresses,
    destinationAddresses,
    sourcePorts,
    destinationPorts,
    translatedAddress: asString(props.translatedAddress) || asString(props.translatedFqdn),
    translatedPort: asString(props.translatedPort),
    isDefault: false,
    description,
    raw: { collection: collectionName, rule },
    searchText: "",
  };
  row.searchText = buildSearchText([row]);
  return row;
}

export function normalizeClassicFirewall(firewall: ArmResource, ctx: NormalizeContext): RuleRow[] {
  const props = childProps(firewall);
  const rows: RuleRow[] = [];
  for (const kind of KINDS) {
    const collections = props[kind.property];
    if (!Array.isArray(collections)) continue;
    for (const collection of collections) {
      const rules = childProps(collection).rules;
      if (!Array.isArray(rules)) continue;
      for (const rule of rules) {
        const row = classicRuleRow(firewall, kind, collection, rule, ctx);
        if (row) rows.push(row);
      }
    }
  }
  return rows;
}

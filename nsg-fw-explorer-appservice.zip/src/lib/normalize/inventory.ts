import { parentResourceId } from "../arm";
import type { ArmResource, Inventory, RuleRow } from "../types";
import { buildContext } from "./context";
import { normalizeClassicFirewall } from "./firewall-classic";
import { normalizePolicyGroup } from "./firewall-policy";
import { normalizeNsg } from "./nsg";

function policyIdOf(firewall: ArmResource): string {
  const policy = firewall.properties?.firewallPolicy;
  if (policy && typeof policy === "object" && "id" in policy && typeof policy.id === "string") {
    return policy.id.toLowerCase();
  }
  return "";
}

export function policyIdForGroup(group: ArmResource): string {
  return parentResourceId(group.id ?? "", "ruleCollectionGroups").toLowerCase();
}

export function normalizeInventory(inventory: Inventory): RuleRow[] {
  const ctx = buildContext(inventory);
  const rows: RuleRow[] = [];
  for (const nsg of inventory.nsgs) rows.push(...normalizeNsg(nsg, ctx));

  const groupsByPolicy = new Map<string, ArmResource[]>();
  for (const group of inventory.ruleCollectionGroups) {
    const policyId = policyIdForGroup(group);
    const list = groupsByPolicy.get(policyId) ?? [];
    list.push(group);
    groupsByPolicy.set(policyId, list);
  }

  const firewallsByPolicy = new Map<string, ArmResource[]>();
  for (const firewall of inventory.firewalls) {
    rows.push(...normalizeClassicFirewall(firewall, ctx));
    const policyId = policyIdOf(firewall);
    if (!policyId) continue;
    const list = firewallsByPolicy.get(policyId) ?? [];
    list.push(firewall);
    firewallsByPolicy.set(policyId, list);
  }

  for (const policy of inventory.policies) {
    const policyId = policy.id.toLowerCase();
    const groups = groupsByPolicy.get(policyId) ?? [];
    const firewalls = firewallsByPolicy.get(policyId) ?? [];
    const targets: Array<ArmResource | null> = firewalls.length ? firewalls : [null];
    for (const firewall of targets) {
      for (const group of groups) rows.push(...normalizePolicyGroup(group, policy, firewall, ctx));
    }
  }

  return rows;
}

import type { DataSource } from "./types";

export interface AppConfig {
  dataSource: DataSource;
  subscriptionIds: string[];
  managementGroupId: string;
  snapshotStorageAccountUrl: string;
  snapshotContainer: string;
  adminGroupId: string;
  adminRole: string;
  opsGroupId: string;
  opsRole: string;
  /** User sign-in. Off unless AUTH_ENABLED is true, 1, or yes. */
  authEnabled: boolean;
  authMode: "easyauth" | "disabled";
  localSnapshotDir: string;
  devIsAdmin: boolean;
}

/**
 * App Service injects settings at process start. Read them dynamically so a
 * value set in the portal is visible without Next inlining it at build time.
 */
export function env(name: string): string {
  const value = process.env[name];
  return typeof value === "string" ? value.trim() : "";
}

export function authEnabledFromEnv(): boolean {
  const value = env("AUTH_ENABLED").toLowerCase();
  return value === "true" || value === "1" || value === "yes";
}

function csv(name: string): string[] {
  return env(name)
    .split(",")
    .map((part) => part.trim())
    .filter(Boolean);
}

export function resolveDataSource(): DataSource {
  const value = env("DATA_SOURCE").toLowerCase();
  if (value === "azure" || value === "mock" || value === "csv") return value;
  if (env("WEBSITE_SITE_NAME")) return "azure";
  return "csv";
}

export function loadConfig(): AppConfig {
  const dataSource = resolveDataSource();
  const authMode = env("AUTH_MODE").toLowerCase() === "easyauth" ? "easyauth" : "disabled";
  return {
    dataSource,
    subscriptionIds: csv("AZURE_SUBSCRIPTION_IDS"),
    managementGroupId: env("AZURE_MANAGEMENT_GROUP_ID"),
    snapshotStorageAccountUrl: env("SNAPSHOT_STORAGE_ACCOUNT_URL").replace(/\/$/, ""),
    snapshotContainer: env("SNAPSHOT_CONTAINER") || "nsg-firewall-snapshots",
    adminGroupId: env("ADMIN_GROUP_ID"),
    adminRole: env("ADMIN_ROLE") || "Rules.Admin",
    opsGroupId: env("OPS_GROUP_ID"),
    opsRole: env("OPS_ROLE"),
    authEnabled: authEnabledFromEnv(),
    authMode,
    localSnapshotDir: env("LOCAL_SNAPSHOT_DIR") || "data/snapshots",
    devIsAdmin: env("DEV_IS_ADMIN").toLowerCase() !== "false",
  };
}

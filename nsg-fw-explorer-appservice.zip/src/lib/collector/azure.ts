import { DefaultAzureCredential } from "@azure/identity";
import { ResourceGraphClient } from "@azure/arm-resourcegraph";
import { NetworkManagementClient } from "@azure/arm-network";
import type { TokenCredential } from "@azure/core-auth";
import type { AppConfig } from "../config";
import type { ArmResource, Inventory, SubscriptionRef } from "../types";
import { isRecord } from "../arm";
import { queryAllPages } from "./paging";
import { resolveRuleCollectionGroups } from "./rule-groups";

const NSG_QUERY = `Resources
| where type =~ 'microsoft.network/networksecuritygroups'
| project id, name, type, subscriptionId, resourceGroup, location, properties`;

const NIC_QUERY = `Resources
| where type =~ 'microsoft.network/networkinterfaces'
| project id, name, type, subscriptionId, resourceGroup, location, properties`;

const VNET_QUERY = `Resources
| where type =~ 'microsoft.network/virtualnetworks'
| project id, name, type, subscriptionId, resourceGroup, location, properties`;

const FIREWALL_QUERY = `Resources
| where type =~ 'microsoft.network/azurefirewalls'
| project id, name, type, subscriptionId, resourceGroup, location, properties`;

const POLICY_QUERY = `Resources
| where type =~ 'microsoft.network/firewallpolicies'
| project id, name, type, subscriptionId, resourceGroup, location, properties`;

const GROUP_QUERY = `Resources
| where type =~ 'microsoft.network/firewallpolicies/rulecollectiongroups'
| project id, name, type, subscriptionId, resourceGroup, location, properties`;

const SUBSCRIPTION_QUERY = `ResourceContainers
| where type =~ 'microsoft.resources/subscriptions'
| project subscriptionId, name = tostring(properties.displayName)`;

export interface GraphScope {
  subscriptions?: string[];
  managementGroups?: string[];
}

export interface AzureScopeChoice {
  scope: GraphScope;
  subscriptions: SubscriptionRef[];
  warnings: string[];
}

/**
 * Pick the Resource Graph scope. With no subscription list and no management
 * group, use every subscription the identity can see. An empty result is a
 * warning, not a thrown error.
 */
export function selectAzureScope(input: {
  subscriptionIds: string[];
  managementGroupId: string;
  listed: SubscriptionRef[] | null;
  discovered: SubscriptionRef[] | null;
  listError?: string;
}): AzureScopeChoice {
  const warnings: string[] = [];
  if (input.listError) warnings.push(`Listing subscriptions failed: ${input.listError}`);
  if (input.subscriptionIds.length > 0) {
    return { scope: { subscriptions: input.subscriptionIds }, subscriptions: input.listed ?? [], warnings };
  }
  if (input.managementGroupId) {
    return {
      scope: { managementGroups: [input.managementGroupId] },
      subscriptions: input.listed ?? input.discovered ?? [],
      warnings,
    };
  }
  const found = input.listed && input.listed.length > 0 ? input.listed : input.discovered;
  if (found && found.length > 0) {
    const via = input.listed && input.listed.length > 0 ? "the subscription list" : "a tenant Resource Graph query";
    warnings.push(`No subscription or management group was configured. Querying ${found.length} subscriptions from ${via}.`);
    return {
      scope: { subscriptions: found.map((subscription) => subscription.subscriptionId) },
      subscriptions: found,
      warnings,
    };
  }
  warnings.push("No accessible subscriptions were found. Set AZURE_SUBSCRIPTION_IDS or AZURE_MANAGEMENT_GROUP_ID, or grant the identity Reader.");
  return { scope: {}, subscriptions: [], warnings };
}

/**
 * Read-only Azure inventory. This module lists resources. It never creates,
 * updates, or deletes network resources.
 */
export interface AzureDependencies {
  listSubscriptions: () => Promise<SubscriptionRef[]>;
  discoverSubscriptions: () => Promise<SubscriptionRef[]>;
  query: (kql: string, scope: GraphScope) => Promise<unknown[]>;
  listRuleGroups: (policyId: string) => Promise<unknown[]>;
}

export async function loadAzureInventory(config: AppConfig, warnings: string[], dependencies?: AzureDependencies): Promise<Inventory> {
  const choice = dependencies
    ? await chooseWithDependencies(config, dependencies, warnings)
    : await resolveScope(config, warnings);
  warnings.push(...choice.warnings);
  if (!choice.scope.subscriptions?.length && !choice.scope.managementGroups?.length) {
    return emptyInventory(choice.subscriptions);
  }
  if (dependencies) return inventoryFromQueries(choice, dependencies.query, dependencies.listRuleGroups, warnings);
  const credential = new DefaultAzureCredential();
  const client = new ResourceGraphClient(credential);
  const scope = choice.scope;
  const query = (kql: string, label: string) => queryGraph(client, kql, scope, warnings, label);

  const [subscriptionRows, vnetRows, nsgRows, nicRows, firewallRows, policyRows, graphGroups] = await Promise.all([
    query(SUBSCRIPTION_QUERY, "subscriptions"),
    query(VNET_QUERY, "virtual networks"),
    query(NSG_QUERY, "network security groups"),
    query(NIC_QUERY, "network interfaces"),
    query(FIREWALL_QUERY, "azure firewalls"),
    query(POLICY_QUERY, "firewall policies"),
    query(GROUP_QUERY, "firewall policy rule collection groups"),
  ]);
  const vnets = vnetRows.filter(isArmResource);
  const nsgs = nsgRows.filter(isArmResource);
  const nics = nicRows.filter(isArmResource);
  const firewalls = firewallRows.filter(isArmResource);
  const policies = policyRows.filter(isArmResource);

  const subscriptions = mergeSubscriptions(choice.scope.subscriptions ?? choice.subscriptions.map((item) => item.subscriptionId), subscriptionRows);
  const resolved = await resolveRuleCollectionGroups(
    graphGroups,
    policies.map((policy) => policy.id),
    async (policyId) => listPolicyRuleCollectionGroups(credential, policyId, warnings),
  );
  warnings.push(...resolved.warnings);

  return {
    subscriptions,
    vnets,
    nsgs,
    nics,
    firewalls,
    policies,
    ruleCollectionGroups: resolved.groups.filter(isArmResource),
  };
}

async function chooseWithDependencies(config: AppConfig, dependencies: AzureDependencies, warnings: string[]): Promise<AzureScopeChoice> {
  if (config.subscriptionIds.length > 0 || config.managementGroupId) {
    return selectAzureScope({ subscriptionIds: config.subscriptionIds, managementGroupId: config.managementGroupId, listed: null, discovered: null });
  }
  let listed: SubscriptionRef[] | null = null;
  let listError = "";
  try {
    listed = await dependencies.listSubscriptions();
  } catch (error) {
    listError = error instanceof Error ? error.message : String(error);
  }
  let discovered: SubscriptionRef[] | null = null;
  if (!listed || listed.length === 0) {
    try {
      discovered = await dependencies.discoverSubscriptions();
    } catch (error) {
      warnings.push(`Tenant Resource Graph discovery failed: ${error instanceof Error ? error.message : String(error)}`);
    }
  }
  return selectAzureScope({
    subscriptionIds: [],
    managementGroupId: "",
    listed,
    discovered,
    listError,
  });
}

async function resolveScope(config: AppConfig, warnings: string[]): Promise<AzureScopeChoice> {
  const credential = new DefaultAzureCredential();
  const client = new ResourceGraphClient(credential);
  return chooseWithDependencies(config, {
    listSubscriptions: () => listAccessibleSubscriptions(credential),
    discoverSubscriptions: () => discoverSubscriptions(client),
    query: (kql, scope) => queryGraph(client, kql, scope, warnings, "discovery"),
    listRuleGroups: (policyId) => listPolicyRuleCollectionGroups(credential, policyId, warnings),
  }, warnings);
}

async function discoverSubscriptions(client: ResourceGraphClient): Promise<SubscriptionRef[]> {
  const rows = await queryAllPages(async (skipToken) => {
    const response = await client.resources({
      query: SUBSCRIPTION_QUERY,
      options: { skipToken, top: 1000, resultFormat: "objectArray", allowPartialScopes: true },
    });
    return { data: response.data, skipToken: response.skipToken };
  });
  return rows.flatMap((row) => {
    if (!isRecord(row) || typeof row.subscriptionId !== "string") return [];
    const name = typeof row.name === "string" && row.name ? row.name : row.subscriptionId;
    return [{ subscriptionId: row.subscriptionId, name }];
  });
}

async function inventoryFromQueries(
  choice: AzureScopeChoice,
  query: AzureDependencies["query"],
  listRuleGroups: AzureDependencies["listRuleGroups"],
  warnings: string[],
): Promise<Inventory> {
  const scope = choice.scope;
  const run = async (kql: string, label: string) => {
    try {
      return await query(kql, scope);
    } catch (error) {
      warnings.push(`Resource Graph query for ${label} failed: ${error instanceof Error ? error.message : String(error)}`);
      return [];
    }
  };
  const [subscriptionRows, vnets, nsgs, nics, firewalls, policies, graphGroups] = await Promise.all([
    run(SUBSCRIPTION_QUERY, "subscriptions"),
    run(VNET_QUERY, "virtual networks"),
    run(NSG_QUERY, "network security groups"),
    run(NIC_QUERY, "network interfaces"),
    run(FIREWALL_QUERY, "azure firewalls"),
    run(POLICY_QUERY, "firewall policies"),
    run(GROUP_QUERY, "firewall policy rule collection groups"),
  ]);
  const resolved = await resolveRuleCollectionGroups(
    graphGroups,
    policies.filter(isArmResource).map((policy) => policy.id),
    async (policyId) => {
      try {
        return await listRuleGroups(policyId);
      } catch (error) {
        warnings.push(`ARM rule collection groups for ${policyId} failed: ${error instanceof Error ? error.message : String(error)}`);
        return [];
      }
    },
  );
  warnings.push(...resolved.warnings);
  return {
    subscriptions: mergeSubscriptions(scope.subscriptions ?? choice.subscriptions.map((item) => item.subscriptionId), subscriptionRows),
    vnets: vnets.filter(isArmResource),
    nsgs: nsgs.filter(isArmResource),
    nics: nics.filter(isArmResource),
    firewalls: firewalls.filter(isArmResource),
    policies: policies.filter(isArmResource),
    ruleCollectionGroups: resolved.groups.filter(isArmResource),
  };
}

function emptyInventory(subscriptions: SubscriptionRef[]): Inventory {
  return { subscriptions, vnets: [], nsgs: [], nics: [], firewalls: [], policies: [], ruleCollectionGroups: [] };
}

async function queryGraph(
  client: ResourceGraphClient,
  kql: string,
  scope: GraphScope,
  warnings: string[],
  label: string,
): Promise<unknown[]> {
  try {
    const rows = await queryAllPages(async (skipToken) => {
      const response = await client.resources({
        query: kql,
        subscriptions: scope.subscriptions,
        managementGroups: scope.managementGroups,
        options: { skipToken, top: 1000, resultFormat: "objectArray" },
      });
      return { data: response.data, skipToken: response.skipToken };
    });
    return rows;
  } catch (error) {
    warnings.push(`Resource Graph query for ${label} failed: ${error instanceof Error ? error.message : String(error)}`);
    return [];
  }
}

function isArmResource(value: unknown): value is ArmResource {
  return isRecord(value) && typeof value.id === "string" && typeof value.name === "string";
}

function mergeSubscriptions(configuredIds: string[], rows: unknown[]): SubscriptionRef[] {
  const names = new Map<string, SubscriptionRef>();
  for (const row of rows) {
    if (!isRecord(row)) continue;
    const subscriptionId = typeof row.subscriptionId === "string" ? row.subscriptionId : "";
    const name = typeof row.name === "string" && row.name ? row.name : subscriptionId;
    if (!subscriptionId) continue;
    names.set(subscriptionId.toLowerCase(), { subscriptionId, name });
  }
  if (configuredIds.length === 0) return [...names.values()];
  return configuredIds.map((subscriptionId) => {
    const known = names.get(subscriptionId.toLowerCase());
    return { subscriptionId, name: known?.name ?? subscriptionId };
  });
}

async function listPolicyRuleCollectionGroups(
  credential: TokenCredential,
  policyId: string,
  warnings: string[],
): Promise<unknown[]> {
  const match = /\/subscriptions\/([^/]+)\/resourceGroups\/([^/]+)\/providers\/Microsoft\.Network\/firewallPolicies\/([^/]+)/i.exec(policyId);
  if (!match) {
    warnings.push(`Could not parse firewall policy id ${policyId}.`);
    return [];
  }
  const [, subscriptionId, resourceGroup, policyName] = match;
  const client = new NetworkManagementClient(credential, subscriptionId);
  const groups: unknown[] = [];
  for await (const group of client.firewallPolicyRuleCollectionGroups.list(resourceGroup, policyName)) {
    groups.push(group);
  }
  return groups;
}

async function listAccessibleSubscriptions(credential: TokenCredential): Promise<SubscriptionRef[]> {
  const token = await credential.getToken("https://management.azure.com/.default");
  if (!token) throw new Error("DefaultAzureCredential did not return a management token.");
  const subscriptions: SubscriptionRef[] = [];
  let url: string | null = "https://management.azure.com/subscriptions?api-version=2022-12-01";
  while (url) {
    const response = await fetch(url, { headers: { Authorization: `Bearer ${token.token}` } });
    if (!response.ok) {
      throw new Error(`Listing subscriptions failed with HTTP ${response.status}.`);
    }
    const body = (await response.json()) as { value?: { subscriptionId?: string; displayName?: string }[]; nextLink?: string };
    for (const subscription of body.value ?? []) {
      if (!subscription.subscriptionId) continue;
      subscriptions.push({
        subscriptionId: subscription.subscriptionId,
        name: subscription.displayName || subscription.subscriptionId,
      });
    }
    url = body.nextLink ?? null;
  }
  return subscriptions;
}

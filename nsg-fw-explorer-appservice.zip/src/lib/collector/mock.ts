import { readFile } from "node:fs/promises";
import path from "node:path";
import type { Inventory } from "../types";

export function inventoryFilePath(): string {
  return path.join(process.cwd(), "fixtures", "inventory.json");
}

export async function loadMockInventory(): Promise<Inventory> {
  const text = await readFile(inventoryFilePath(), "utf8");
  return JSON.parse(text) as Inventory;
}

import type { AppConfig } from "../config";
import { loadConfig } from "../config";
import { normalizeInventory } from "../normalize/inventory";
import type { DataSource, Snapshot } from "../types";
import { getSnapshotStore, type SnapshotStore } from "../snapshot";

export interface CollectResult {
  acquired: boolean;
  snapshot?: Snapshot;
}

export async function collectSnapshot(config: AppConfig = loadConfig()): Promise<Snapshot> {
  const started = Date.now();
  const generatedAt = new Date(started).toISOString();
  const warnings: string[] = [];
  const source: DataSource = config.dataSource;
  try {
    if (source === "csv") return buildCsvSnapshot(generatedAt);
    const inventory = source === "azure" ? await loadAzure(config, warnings) : await loadMock();
    if (source === "azure" && !config.snapshotStorageAccountUrl) {
      warnings.push("SNAPSHOT_STORAGE_ACCOUNT_URL is empty. The snapshot was written to the local file store and is not shared across instances.");
    }
    const rules = normalizeInventory(inventory);
    const finished = Date.now();
    return {
      version: 1,
      generatedAt,
      finishedAt: new Date(finished).toISOString(),
      source,
      status: warnings.length > 0 ? "partial" : "ok",
      warnings,
      stats: {
        subscriptions: inventory.subscriptions.length,
        nsgs: inventory.nsgs.length,
        firewalls: inventory.firewalls.length,
        policies: inventory.policies.length,
        rules: rules.length,
        durationMs: finished - started,
      },
      rules,
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    const finished = Date.now();
    return {
      version: 1,
      generatedAt,
      finishedAt: new Date(finished).toISOString(),
      source,
      status: "error",
      warnings,
      error: message,
      stats: {
        subscriptions: 0,
        nsgs: 0,
        firewalls: 0,
        policies: 0,
        rules: 0,
        durationMs: finished - started,
      },
      rules: [],
    };
  }
}

async function buildCsvSnapshot(generatedAt: string): Promise<Snapshot> {
  const { ensureCsvSnapshot } = await import("../csv-store");
  const snapshot = await ensureCsvSnapshot();
  if (!snapshot.generatedAt) snapshot.generatedAt = generatedAt;
  return snapshot;
}

async function loadMock() {
  const { loadMockInventory } = await import("./mock");
  return loadMockInventory();
}

async function loadAzure(config: AppConfig, warnings: string[]) {
  const { loadAzureInventory } = await import("./azure");
  return loadAzureInventory(config, warnings);
}

export async function runCollectWithLock(owner: string, store: SnapshotStore = getSnapshotStore()): Promise<CollectResult> {
  const lock = await store.acquireLock(owner, 15 * 60 * 1000);
  if (!lock) return { acquired: false };
  const renew = setInterval(() => {
    void lock.renew().catch((error: unknown) => {
      const message = error instanceof Error ? error.message : String(error);
      console.error(`[collector] lock renew failed: ${message}`);
    });
  }, 20_000);
  try {
    const snapshot = await collectSnapshot();
    if (snapshot.status === "error" && snapshot.rules.length === 0) {
      const current = await store.readLatest();
      if (current && current.rules.length > 0) {
        console.error(`[collector] collection failed and the previous snapshot was kept: ${snapshot.error}`);
        return { acquired: true, snapshot: current };
      }
    }
    await store.write(snapshot);
    console.log(
      `[collector] ${snapshot.status} ${snapshot.stats.rules} rules from ${snapshot.stats.nsgs} NSGs and ${snapshot.stats.firewalls} firewalls in ${snapshot.stats.durationMs}ms`,
    );
    return { acquired: true, snapshot };
  } finally {
    clearInterval(renew);
    await lock.release();
  }
}

export async function ensureSnapshot(store: SnapshotStore = getSnapshotStore()): Promise<Snapshot> {
  if (loadConfig().dataSource === "csv") {
    const { ensureCsvSnapshot } = await import("../csv-store");
    return ensureCsvSnapshot();
  }
  const existing = await store.readLatest();
  if (existing && existing.status !== "error") return existing;
  const result = await runCollectWithLock("web");
  if (result.snapshot && result.snapshot.status !== "error") return result.snapshot;
  if (existing) return existing;
  if (result.snapshot?.error) throw new Error(result.snapshot.error);
  throw new Error("No snapshot is available.");
}

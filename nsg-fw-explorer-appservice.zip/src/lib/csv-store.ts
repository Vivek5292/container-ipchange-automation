import { createHash } from "node:crypto";
import { readdir, readFile } from "node:fs/promises";
import path from "node:path";
import { parseRuleCsv, type ParsedCsvFile } from "./csv-import";
import { getSnapshotStore } from "./snapshot";
import type { CsvLoadIssue, RuleRow, Snapshot } from "./types";

function fileOf(rule: RuleRow): string {
  const raw = rule.raw;
  if (raw && typeof raw === "object" && "file" in raw && typeof raw.file === "string") return raw.file;
  return "";
}

export function mergeCsvFiles(existing: Snapshot | null, parsed: ParsedCsvFile[]): Snapshot {
  const replaced = new Set(parsed.map((file) => file.name));
  const kept = (existing?.rules ?? []).filter((rule) => !replaced.has(fileOf(rule)));
  const rules = [...kept, ...parsed.flatMap((file) => file.rules)];
  const keptIssues = (existing?.loadIssues ?? []).filter((issue) => !replaced.has(issue.file));
  const loadIssues = [...keptIssues, ...parsed.flatMap((file) => file.issues)];
  const generatedAt = new Date().toISOString();
  const warnings = loadIssues.map((issue) => `${issue.file} row ${issue.row}: ${issue.message}`);
  return {
    version: 1,
    generatedAt,
    finishedAt: generatedAt,
    source: "csv",
    status: loadIssues.length > 0 ? "partial" : "ok",
    warnings,
    stats: {
      subscriptions: new Set(rules.map((rule) => rule.subscriptionName).filter(Boolean)).size,
      nsgs: new Set(rules.filter((rule) => rule.sourceType === "nsg").map((rule) => rule.nsgOrFirewallName)).size,
      firewalls: new Set(rules.filter((rule) => rule.sourceType !== "nsg").map((rule) => rule.nsgOrFirewallName)).size,
      policies: new Set(rules.map((rule) => rule.policyName).filter(Boolean)).size,
      rules: rules.length,
      durationMs: 0,
    },
    rules,
    loadIssues,
  };
}

export async function readCsvDirectory(directory: string): Promise<{ name: string; text: string }[]> {
  let names: string[] = [];
  try {
    names = await readdir(directory);
  } catch {
    return [];
  }
  const csvNames = names.filter((name) => name.toLowerCase().endsWith(".csv")).sort();
  const files = await Promise.all(csvNames.map(async (name) => ({
    name,
    text: await readFile(path.join(directory, name), "utf8"),
  })));
  return files;
}

export async function ensureCsvSnapshot(root = process.cwd()): Promise<Snapshot> {
  const store = getSnapshotStore();
  const existing = await store.readLatest();
  const dropped = await readCsvDirectory(path.join(root, "data"));
  const changed = dropped.filter((file) => {
    const hash = createHash("sha256").update(file.text).digest("hex");
    return !existing?.rules.some((rule) => fileOf(rule) === file.name && ruleHash(rule) === hash);
  });
  if (changed.length > 0) {
    const parsed = changed.map((file) => stamp(parseRuleCsv(file.name, file.text)));
    const snapshot = mergeCsvFiles(existing?.source === "csv" ? existing : null, parsed);
    await store.write(snapshot);
    return snapshot;
  }
  if (existing && existing.source === "csv") return existing;
  const samples = await readCsvDirectory(path.join(root, "data", "samples"));
  if (samples.length === 0) {
    const empty = mergeCsvFiles(null, []);
    empty.warnings = ["No CSV files in ./data or ./data/samples."];
    empty.status = "error";
    empty.error = empty.warnings[0];
    return empty;
  }
  const snapshot = mergeCsvFiles(null, samples.map((file) => stamp(parseRuleCsv(file.name, file.text))));
  await store.write(snapshot);
  return snapshot;
}

export async function importUploadedCsvs(files: { name: string; text: string }[]): Promise<{ snapshot: Snapshot; issues: CsvLoadIssue[] }> {
  const store = getSnapshotStore();
  const existing = await store.readLatest();
  const parsed = files.map((file) => stamp(parseRuleCsv(file.name, file.text)));
  const snapshot = mergeCsvFiles(existing?.source === "csv" ? existing : null, parsed);
  await store.write(snapshot);
  return { snapshot, issues: parsed.flatMap((file) => file.issues) };
}

function ruleHash(rule: RuleRow): string {
  const raw = rule.raw;
  if (raw && typeof raw === "object" && "hash" in raw && typeof raw.hash === "string") return raw.hash;
  return "";
}

function stamp(parsed: ParsedCsvFile): ParsedCsvFile {
  return {
    ...parsed,
    rules: parsed.rules.map((rule) => ({
      ...rule,
      raw: { ...(rule.raw as object), hash: parsed.hash },
    })),
  };
}

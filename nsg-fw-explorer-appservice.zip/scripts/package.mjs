import { execFileSync } from "node:child_process";
import { mkdirSync, readFileSync, rmSync, statSync, writeFileSync } from "node:fs";
import path from "node:path";

const root = process.cwd();
const out = "/opt/cursor/artifacts";
mkdirSync(out, { recursive: true });
const readme = readFileSync(path.join(root, "README.md"), "utf8");

const builds = [
  {
    zip: "nsg-fw-explorer-local.zip",
    quickstart: `# Local build

Run this on your own computer. No Azure sign-in and no tenant credentials.

\`\`\`bash
npm install && npm start
\`\`\`

Windows: double-click \`start-windows.bat\`. Mac or Linux: \`chmod +x start-mac.sh && ./start-mac.sh\`. Both install dependencies if needed, start the app, and open a browser at http://127.0.0.1:43123.

The app reads NSG and Azure Firewall rule CSVs. Drop exports into \`./data\`, or use **Upload CSV**. Samples are in \`./data/samples\`. The last import is kept in \`./data/snapshots\` and survives a restart. The page says "Last loaded".

User authentication is off (\`AUTH_ENABLED=false\`). This copy is only for your machine.

---

`,
  },
  {
    zip: "nsg-fw-explorer-appservice.zip",
    quickstart: `# App Service build

Deploy this zip to Azure App Service (Linux, Node 22). A WebJob collects every NSG and Azure Firewall the managed identity can read. No CSV files are required.

\`\`\`bash
az webapp deploy --resource-group <rg> --name <app-name> --src-path nsg-fw-explorer-appservice.zip --type zip
\`\`\`

Oryx runs \`npm install\` and \`npm run build\`, then \`npm start\`. The zip includes \`App_Data/jobs/triggered/collector\` (schedule \`0 0 */4 * * *\`). Set Always On. \`AUTH_ENABLED\` stays false unless you change that app setting. Infrastructure is in \`infra/\`. The rest of this file is the full deploy guide.

---

`,
  },
];

const tarExcludes = [
  "node_modules",
  ".next",
  ".git",
  "test-results",
  "playwright-report",
  "blob-report",
  "coverage",
  "data/snapshots",
  "data/uploads",
  ".env",
  ".env.local",
];

for (const build of builds) {
  const staging = path.join("/tmp", build.zip.replace(".zip", ""));
  rmSync(staging, { recursive: true, force: true });
  mkdirSync(staging, { recursive: true });
  const args = tarExcludes.flatMap((name) => ["--exclude", name]);
  const archive = path.join("/tmp", `${build.zip}.tar`);
  rmSync(archive, { force: true });
  execFileSync("tar", [...args, "-cf", archive, "."], { cwd: root, stdio: "inherit" });
  execFileSync("tar", ["-xf", archive], { cwd: staging, stdio: "inherit" });
  rmSync(archive, { force: true });
  writeFileSync(path.join(staging, "README.md"), `${build.quickstart}${readme}`);
  const zipPath = path.join(out, build.zip);
  rmSync(zipPath, { force: true });
  execFileSync("zip", ["-r", "-q", zipPath, "."], { cwd: staging });
  const size = statSync(zipPath).size;
  console.log(`${zipPath} ${(size / 1024 / 1024).toFixed(2)} MB`);
}

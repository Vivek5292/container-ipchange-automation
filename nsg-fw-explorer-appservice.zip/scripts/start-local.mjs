import { spawn } from "node:child_process";
import { setTimeout as delay } from "node:timers/promises";

const onAppService = Boolean(process.env.WEBSITE_SITE_NAME || process.env.WEBSITE_INSTANCE_ID);
const mock = process.argv.includes("--mock");

if (!process.env.DATA_SOURCE) {
  process.env.DATA_SOURCE = onAppService ? "azure" : mock ? "mock" : "csv";
}
if (!process.env.AUTH_ENABLED) process.env.AUTH_ENABLED = "false";

const port = process.env.PORT || (onAppService ? "8080" : "43123");
const host = onAppService ? "0.0.0.0" : "127.0.0.1";
const args = onAppService
  ? ["next", "start", "-H", host, "-p", port]
  : ["next", "dev", "-H", host, "-p", port];

const child = spawn("npx", args, { stdio: "inherit", shell: true });
child.on("exit", (code) => process.exit(code ?? 0));

const openBrowser = !onAppService && !mock && process.env.BROWSER !== "none" && !process.argv.includes("--no-open");
if (openBrowser) {
  const url = `http://127.0.0.1:${port}`;
  void waitAndOpen(url);
}

async function waitAndOpen(url) {
  for (let attempt = 0; attempt < 60; attempt += 1) {
    try {
      const response = await fetch(url);
      if (response.ok) break;
    } catch {
      await delay(500);
      continue;
    }
    await delay(500);
  }
  const command = process.platform === "win32" ? "start" : process.platform === "darwin" ? "open" : "xdg-open";
  const opener = process.platform === "win32"
    ? spawn("cmd", ["/c", "start", "", url], { detached: true, stdio: "ignore", shell: true })
    : spawn(command, [url], { detached: true, stdio: "ignore" });
  opener.unref();
}

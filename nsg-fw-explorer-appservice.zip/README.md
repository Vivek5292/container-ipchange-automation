# App Service build

Deploy this zip to Azure App Service (Linux, Node 22). A WebJob collects every NSG and Azure Firewall the managed identity can read. No CSV files are required.

```bash
az webapp deploy --resource-group <rg> --name <app-name> --src-path nsg-fw-explorer-appservice.zip --type zip
```

Oryx runs `npm install` and `npm run build`, then `npm start`. The zip includes `App_Data/jobs/triggered/collector` (schedule `0 0 */4 * * *`). Set Always On. `AUTH_ENABLED` stays false unless you change that app setting. Infrastructure is in `infra/`. The rest of this file is the full deploy guide.

---

# NSG & Firewall Rules

Read-only inventory of Azure network security group rules and Azure Firewall rules for a cloud operations team. Rules from many subscriptions are normalized into one table, snapshotted, and searched from a browser. The site never creates or changes Azure network resources.

Local development uses fixture data. No tenant credentials are required.

## Architecture

```text
Browser (HeroUI table)
  → Next.js route handlers
      → snapshot store (local files, or Azure Blob)
          ↑
scheduled WebJob  ── collector ── mock fixtures
manual refresh    ── collector ── Azure Resource Graph + ARM (read-only)
```

The collector is one module. The WebJob and the manual refresh button both call it.

1. **Read.** In Azure mode, [Azure Resource Graph](https://learn.microsoft.com/azure/governance/resource-graph/overview) lists NSGs (custom `securityRules` and `defaultSecurityRules`), NIC and subnet associations, VNets, Azure Firewalls, firewall policies, and policy rule collection groups across the configured subscriptions or management group. Queries follow `skipToken` until the result set is exhausted. NIC records are used to resolve a VM name and the NIC's subnet when that lookup is already in the graph response.
2. **Fill in policy rules.** Resource Graph often returns a rule collection group without rule bodies. When a group has no `rules` array, the collector calls `firewallPolicyRuleCollectionGroups.list` from `@azure/arm-network` for that policy. That is a read. Classic firewall rules (`networkRuleCollections`, `applicationRuleCollections`, `natRuleCollections` on the firewall resource) are taken from the firewall resource when they are present.
3. **Normalize.** NSG rules, firewall policy rules (network, application, DNAT), and classic firewall rules become one row shape: subscription, resource group, VNet, subnet or subnets, NIC, VM, NSG or firewall, policy, collection group, collection, name, type, direction, action, priority, protocols, source and destination (addresses, prefixes, FQDNs, FQDN tags, service tags, ASGs, IP groups), ports, DNAT translation, default-rule flag, description, and the raw JSON. Singular and plural ARM fields are both read (`sourceAddressPrefix` and `sourceAddressPrefixes`, and the same for ports and destinations).
4. **Store.** The snapshot is JSON. Blob storage writes gzip (`snapshots/latest.json.gz` and `snapshots/history/<timestamp>.json.gz`). Local development writes pretty JSON under `data/snapshots/`.
5. **Serve.** The table is filtered and paginated on the server, so a snapshot with thousands of rows does not have to be shipped to the browser on every keystroke. CSV export uses the same filter and includes every matching row, not only the current page.

Direction is taken from the NSG rule. Firewall network and application rules are treated as outbound. DNAT and classic NAT rules are treated as inbound. Anything else is `n/a`.

Priority in the range filter is the NSG rule priority, the firewall policy **collection group** priority, or the classic collection priority. The label also shows the collection priority (`200 / 100` means group 200, collection 100).

An address filter treats `*`, `any`, and `0.0.0.0/0` as every IPv4 address, matches an IP inside a CIDR, and otherwise does a case-insensitive substring match so service tags, ASG names, IP groups, and FQDNs work. A numeric port matches a destination port or a range such as `30000-32767`.

User authentication is **off** unless `AUTH_ENABLED` is `true`, `1`, or `yes`. That is one app setting. While it is off, the site does not require an Easy Auth principal (including in production), the page shows "Authentication disabled (test mode)", and anyone who can reach the site can refresh the snapshot. The blob lease still stops two collections from running at once.

When `AUTH_ENABLED` is on, behavior is Easy Auth again: `X-MS-CLIENT-PRINCIPAL` is required in production and when `AUTH_MODE=easyauth`, an ops group or role is required when `OPS_GROUP_ID` or `OPS_ROLE` is set, and refresh is limited to `ADMIN_GROUP_ID` or the `ADMIN_ROLE` app role (default `Rules.Admin`).

## Local development

Requires Node.js 22 or newer.

```bash
npm install
npm run dev
```

`npm start` is the local CSV build (no Azure). `npm run dev` is the fixture build used by the tests. Open http://127.0.0.1:43123. User authentication stays off. The theme control follows the system theme until you choose Light, Dark, or System; that choice is stored in the browser.

For a laptop with portal exports:

```bash
npm install && npm start
```

Windows: `start-windows.bat`. Mac or Linux: `chmod +x start-mac.sh && ./start-mac.sh`. Drop NSG and firewall CSVs into `./data`, or use **Upload CSV**. Samples live in `./data/samples` and load automatically when nothing has been imported yet. The page says "Last loaded". The import is stored in `./data/snapshots/latest.json` and is still there after a restart.

`npm run package` writes `nsg-fw-explorer-local.zip` and `nsg-fw-explorer-appservice.zip`.

### CSV columns

Header matching ignores case, spaces, and punctuation. These names are accepted. Unknown columns are kept on the rule as raw JSON. A row with no rule name, or with an action other than Allow, Deny, or DNAT, is listed in the page and is not added to the table.

NSG exports, including the portal rule grid (Priority, Name, Port, Protocol, Source, Destination, Action) and fuller exports:

| Meaning | Accepted headers |
| --- | --- |
| Name | Name, Rule Name |
| Priority | Priority |
| Destination ports | Port, Ports, Destination Port, Destination Port Range, Destination Ports |
| Source ports | Source Port, Source Port Range, Source Ports |
| Protocol | Protocol, Protocols |
| Source | Source, Source Address Prefix, Source Addresses |
| Destination | Destination, Destination Address Prefix, Destination Addresses |
| Action | Action, Access |
| Direction | Direction |
| NSG | NSG, NSG Name, Network Security Group |
| Resource group | Resource Group, Resource Group Name |
| Subscription | Subscription, Subscription Name, Subscription Id |
| Subnet / NIC | Subnet, Subnet Assignment Name, NIC, NIC Assignment Name |
| Description | Description |

Firewall and firewall policy exports (portal-style grids and the usual PowerShell exports):

| Meaning | Accepted headers |
| --- | --- |
| Name | Name, Rule Name |
| Rule kind | Rule type, Rule collection type |
| Collection | Rule collection, Rule collection name, Collection |
| Collection priority | Collection priority, Rule priority, Rule collection priority |
| Collection group | Collection group, Rule collection group |
| Group priority | Group priority, Collection group priority |
| Protocol | Protocol, Protocols, IP protocols |
| Source / destination | Source, Source addresses, Destination, Destination addresses |
| Ports | Destination ports, Port |
| FQDN | FQDN, Destination FQDNs, Target FQDNs |
| FQDN tag | FQDN tag, FQDN tags |
| IP groups | Source IP groups, Destination IP groups |
| DNAT | Translated address, Translated port |
| Firewall / policy | Firewall, Firewall name, Policy, Policy name |
| Action | Action, Action type (Allow, Deny, DNAT) |

Cells may repeat values separated by commas, semicolons, or pipes, including inside quotes. The file may use commas or semicolons, and may start with a UTF-8 BOM.

The fixture has three subscriptions (Production Network, Production Applications, Non-Production), several VNets and subnets, NSGs with custom and default rules, one NIC-associated NSG (`nsg-jump` on `vm-jump-01`), two firewall policies (`afw-hub-eus`, `afw-nonprod`), and one classic firewall (`afw-legacy`).

Useful commands:

```bash
npm test              # Vitest: normalizers, filters, auth, paging, lock, CSV
npm run test:e2e      # Playwright against the dev server
npm run job           # Run the collector once (mock, unless DATA_SOURCE=azure)
npm run fixtures      # Regenerate fixtures/inventory.json from fixtures/build-inventory.ts
```

Copy `.env.example` to `.env.local` only when you need to override a default. Do not commit `.env.local`.

## Scheduler

Collection runs every 4 hours. Three ways to do that were considered.

| Option | What it is | Why it was not the default |
| --- | --- | --- |
| Triggered WebJob | `App_Data/jobs/triggered/collector` with `settings.job` cron `0 0 */4 * * *` | Chosen. One App Service, one managed identity, cron is built in, logs show up with the app. |
| In-process timer | `setInterval` or `node-cron` inside the Next.js process | The timer dies on recycle, runs once per worker, and mixes a multi-minute graph query with request handling. Harder to tell a failed collection from a failed page. |
| Function App timer | Separate function with a timer trigger | A timer trigger can take a singleton lock, but it is a second deployable, a second identity, and a second plan if the collection must outlive the Consumption timeout. Cold start sits on the collection path. |

**Decision: triggered WebJob**, plus a lock so a scale-out instance and a manual refresh cannot collect at the same time.

- **Always On.** Triggered WebJobs on Linux do not run reliably while the app is unloaded. The plan must be Basic or higher and Always On must be on. The Bicep template sets both.
- **Scale-out.** Each instance would otherwise start the WebJob. `is_singleton` in `settings.job` depends on `AzureWebJobsStorage` (a storage connection string). This repo does not use that secret. The collector acquires a 60-second blob lease on `locks/collector.lock` and renews it. The same lease covers a manual refresh. With authentication off, that button is not limited to an admin. The lease is what stops overlapping runs. If Blob storage is not configured, a local lock file is used; that lock is per machine, so production must set `SNAPSHOT_STORAGE_ACCOUNT_URL`.
- **Cold start.** The WebJob starts a new Node process each run. That is a few seconds and does not affect people already using the site. The site itself stays warm because of Always On.
- **Deployment.** The job ships inside the app (`run.sh` + `settings.job`). There is no second pipeline. App settings are already in the process environment.
- **Observability.** stdout from `src/jobs/collect.ts` is the WebJob log (Kudu / Log stream). A failed collection does not replace a good snapshot. The page shows the last successful time, `Current` / `Partial` / `Failed`, and any warnings.
- **Overlap.** A run that is still going at the next 4-hour mark exits immediately when it cannot take the lease. A second admin click returns HTTP 409.

NCRONTAB is six fields: second, minute, hour, day, month, day of week. `0 0 */4 * * *` is every four hours at minute 0.

## Deploy to App Service

Placeholders only. Replace the angle brackets.

### 1. Infrastructure

```bash
az group create --name <rg> --location eastus

az deployment group create \
  --resource-group <rg> \
  --template-file infra/main.bicep \
  --parameters \
    appName=<app-name> \
    storageAccountName=<storage-account> \
    subscriptionIds=<sub-guid>,<sub-guid> \
    adminGroupId=<admin-group-object-id> \
    opsGroupId=<ops-group-object-id>

# Reader at the management group. principalId is an output of the deployment above.
az deployment mg create \
  --management-group-id <mg-id> \
  --location eastus \
  --template-file infra/reader.bicep \
  --parameters principalId=<principal-id>
```

`infra/main.bicep` creates the Linux plan (S1, Always On), the Node 22 app, a system-assigned identity, the storage account, the snapshot container, and **Storage Blob Data Contributor** on that container. Shared key access on the account is disabled; the app uses the managed identity.

If you assign access per subscription instead of at a management group:

```bash
az role assignment create \
  --assignee-object-id <principal-id> \
  --assignee-principal-type ServicePrincipal \
  --role "Reader" \
  --scope /subscriptions/<sub-guid>
```

Reader is enough. It includes network reads and Resource Graph reads. Do not assign Contributor or Network Contributor. A custom role also works if it includes `Microsoft.Network/*/read`, `Microsoft.Resources/subscriptions/read`, and `Microsoft.ResourceGraph/*/read`.

### 2. App settings

Set by the Bicep template, repeated here so a portal-only setup matches:

> **Warning.** With `AUTH_ENABLED` left at its default (`false`), the site shows every network rule to anyone who can open the URL. Use that only for a test. Prefer one of these while you are testing: an App Service IP allowlist, a private endpoint, or running the app on your own machine (`npm run dev`). Do not leave a public App Service in this mode.

IP allowlist (placeholders). After the first Allow rule, App Service denies every other address:

```bash
az webapp config access-restriction add \
  --resource-group <rg> \
  --name <app-name> \
  --rule-name allow-ops-network \
  --action Allow \
  --ip-address <office-cidr> \
  --priority 100
```

Private endpoint is the portal or `az network private-endpoint create` path for the app. Local mock mode never leaves the machine.

| Setting | Example | Purpose |
| --- | --- | --- |
| `DATA_SOURCE` | `azure` | `mock` or `azure` |
| `AUTH_ENABLED` | `false` | User sign-in. Default off. Set to `true` to require Easy Auth |
| `AUTH_MODE` | `easyauth` | Used only when `AUTH_ENABLED=true`. Rejects a missing principal |
| `AZURE_SUBSCRIPTION_IDS` | `<guid>,<guid>` | Explicit scope. Used when set. |
| `AZURE_MANAGEMENT_GROUP_ID` | `<mg-id>` | Used when the subscription list is empty |
| `SNAPSHOT_STORAGE_ACCOUNT_URL` | `https://<account>.blob.core.windows.net` | Managed-identity blob endpoint |
| `SNAPSHOT_CONTAINER` | `nsg-firewall-snapshots` | Container created by Bicep |
| `ADMIN_GROUP_ID` | `<group-object-id>` | Group allowed to refresh |
| `ADMIN_ROLE` | `Rules.Admin` | App role allowed to refresh |
| `OPS_GROUP_ID` | `<group-object-id>` | Optional extra read restriction |
| `OPS_ROLE` | `Rules.Reader` | Optional extra read restriction |

No client secret or storage key belongs in the repo. `DefaultAzureCredential` uses the system-assigned identity on App Service.

If neither subscription IDs nor a management group is set, the collector lists subscriptions the identity can see and queries those. Prefer an explicit scope.

History blobs are not deleted by the app. Add a lifecycle policy on `snapshots/history/` if you want a retention window. Local dev keeps the latest 48 files.

### 3. Easy Auth (optional)

The default Bicep deploy sets `AUTH_ENABLED=false` and does not create `authsettingsV2`. The managed identity, Reader assignment, and Storage Blob Data Contributor stay. Those are how the app reads Azure, not how users sign in.

To turn user sign-in on, change one app setting and redeploy with the auth parameters (or set Easy Auth in the portal):

```bash
az webapp config appsettings set \
  --resource-group <rg> \
  --name <app-name> \
  --settings AUTH_ENABLED=true AUTH_MODE=easyauth
```

Then supply an app registration. Add app roles `Rules.Reader` and `Rules.Admin` (allowed member types: Users/Groups). Under **Token configuration**, the group claim is optional if you use app roles; if you use `ADMIN_GROUP_ID` / `OPS_GROUP_ID`, set group membership to `SecurityGroup` or `Groups assigned to the application`.

Assign the operations group to `Rules.Reader` (or require user assignment and assign that group to the enterprise app). Assign a smaller admin group to `Rules.Admin`. With auth on, only that admin group or role can refresh. Everyone else who can read the site cannot.

```bash
az deployment group create \
  --resource-group <rg> \
  --template-file infra/main.bicep \
  --parameters \
    appName=<app-name> \
    storageAccountName=<storage-account> \
    authEnabled=true \
    aadClientId=<client-id> \
    aadTenantId=<tenant-id>

az webapp config appsettings set \
  --resource-group <rg> \
  --name <app-name> \
  --settings MICROSOFT_PROVIDER_AUTHENTICATION_SECRET=<client-secret>
```

`authEnabled=true` writes `authsettingsV2`: Easy Auth on, unauthenticated requests get HTTP 401, and the Microsoft provider uses the client id, tenant issuer, and the secret setting name above. Store the secret in that app setting or in Key Vault. Do not commit it.

The app reads `X-MS-CLIENT-PRINCIPAL` (base64 JSON). Group claims (`groups` or the group SID claim) and role claims (`roles` or the standard role URI) are both accepted. In production, or when `AUTH_MODE=easyauth`, a request with no principal is rejected. Restrict the enterprise app with **User assignment required**, and assign the ops group.

Turning the setting back to `AUTH_ENABLED=false` stops the app from checking the principal. Bicep incremental mode does not delete an `authsettingsV2` that is already on the site. Disable the platform feature as well:

```bash
az webapp auth update --resource-group <rg> --name <app-name> --enabled false
```

### 4. Deploy the app and the WebJob

From a machine with the repo:

```bash
npm ci
npm run build
zip -r release.zip . \
  -x '*.git*' 'node_modules/*' '.next/cache/*' 'data/*' 'test-results/*' 'playwright-report/*'

az webapp deploy \
  --resource-group <rg> \
  --name <app-name> \
  --src-path release.zip \
  --type zip
```

Oryx builds on the app (`SCM_DO_BUILD_DURING_DEPLOYMENT=true`) and `npm start` runs `next start`, which listens on `PORT`.

The zip includes `App_Data/jobs/triggered/collector/run.sh` and `settings.job`. Confirm the job in the portal under WebJobs, or:

```bash
az webapp webjob triggered list --resource-group <rg> --name <app-name>
```

`run.sh` executes `node --import tsx src/jobs/collect.ts` from the site root. App settings are in the environment, so the job uses the same identity and scope as the site.

Always On is required. It is set in Bicep. If you created the app by hand:

```bash
az webapp config set --resource-group <rg> --name <app-name> --always-on true
```

### 5. First snapshot

The first page view collects if `latest` is missing. For a large tenant, trigger the WebJob once instead of waiting on a browser request:

```bash
az webapp webjob triggered run \
  --resource-group <rg> \
  --name <app-name> \
  --webjob-name collector
```

## Tests

```bash
npm test
npx playwright install chromium
npm run test:e2e
```

Vitest covers every normalizer against the committed Resource Graph / ARM JSON (singular and plural fields, flat documents, default rules, NIC to VM, policy network / application / DNAT, classic collections, the ARM fallback decision, Resource Graph paging, the file lock, CSV quoting, and the read-only source check). Auth tests run with `AUTH_ENABLED=true` for the Easy Auth path and with it false for the open test path. Playwright drives search, action and subscription filters, port matching, the detail dialog, CSV export, the test-mode banner, and refresh without a principal.

## What you still have to fill in

- Tenant and either `AZURE_SUBSCRIPTION_IDS` or `AZURE_MANAGEMENT_GROUP_ID`.
- A network boundary while auth is off (IP allowlist, private endpoint, or local only).
- When you set `AUTH_ENABLED=true`: the ops group (Easy Auth user assignment and, if you want the app to check it too, `OPS_GROUP_ID` or `OPS_ROLE`), the admin group object id (`ADMIN_GROUP_ID`) and/or the `Rules.Admin` app role (`ADMIN_ROLE`), and the Easy Auth client id, tenant id, and client secret (app setting, not git).
- Storage account name.
- Reader (or equivalent) for the managed identity, and Storage Blob Data Contributor on the snapshot container. The Bicep files do the storage role and can do Reader at a management group. Those roles are Azure read access for the collector, not user sign-in.

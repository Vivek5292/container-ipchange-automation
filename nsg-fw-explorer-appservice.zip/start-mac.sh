#!/usr/bin/env bash
# Also works on Linux. Installs dependencies if needed, starts the local CSV app, and opens a browser.
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "Install Node.js 22 or newer, then run this script again."
  exit 1
fi
if [[ ! -d node_modules ]]; then
  npm install
fi
export DATA_SOURCE=csv
export AUTH_ENABLED=false
export BROWSER=none
echo "Starting NSG and Firewall Rules at http://127.0.0.1:43123"
if command -v open >/dev/null 2>&1; then
  (sleep 2 && open "http://127.0.0.1:43123") >/dev/null 2>&1 &
elif command -v xdg-open >/dev/null 2>&1; then
  (sleep 2 && xdg-open "http://127.0.0.1:43123") >/dev/null 2>&1 &
fi
exec npm start

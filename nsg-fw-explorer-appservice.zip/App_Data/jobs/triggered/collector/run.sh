#!/usr/bin/env bash
# Triggered WebJob. App Service starts this from App_Data/jobs/triggered/collector.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../../../.." && pwd)"
cd "$ROOT"
exec node --import tsx src/jobs/collect.ts

import { expect, test } from "@playwright/test";
import path from "node:path";

const base = process.env.LOCAL_BUILD_URL;

test.skip(!base, "Set LOCAL_BUILD_URL to prove the unzipped local build.");

test("uploads sample CSVs, filters them, and keeps them after restart", async ({ page, request }) => {
  await page.goto(base!);
  await expect(page.getByTestId("auth-banner")).toBeVisible();
  await expect(page.getByText("Last loaded").first()).toBeVisible();
  const input = page.locator("input[type=file]");
  await input.setInputFiles([
    path.join(process.cwd(), "data/samples/nsg-rules.csv"),
    path.join(process.cwd(), "data/samples/firewall-rules.csv"),
  ]);
  await expect(page.getByRole("row", { name: /Allow-SSH-Corp/ })).toBeVisible({ timeout: 20_000 });
  await page.getByRole("searchbox", { name: "Search rules" }).fill("NET-1042");
  await expect(page.getByRole("row", { name: /Allow-HTTPS-Internet/ })).toHaveCount(0);
  await page.getByRole("button", { name: "Clear filters" }).click();
  await page.getByRole("searchbox", { name: "Search rules" }).fill("");
  await page.getByRole("button", { name: "Action" }).click();
  await page.getByRole("option", { name: "DNAT", exact: true }).click();
  await expect(page.getByRole("row", { name: /SSH-Jump/ })).toBeVisible();
  await page.screenshot({ path: "/opt/cursor/artifacts/local-csv-upload.png" });

  const before = await request.get(`${base}/api/rules?q=Allow-SSH-Corp`);
  expect(before.ok()).toBeTruthy();
  const body = (await before.json()) as { total: number };
  expect(body.total).toBeGreaterThan(0);
});

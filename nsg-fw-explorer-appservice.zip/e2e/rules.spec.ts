import { expect, test } from "@playwright/test";

test.beforeEach(async ({ page }) => {
  await page.goto("/");
  await expect(page.getByRole("heading", { name: "NSG & Firewall Rules" })).toBeVisible();
  await expect(page.getByTestId("auth-banner")).toHaveText("Authentication disabled (test mode)");
  await expect(page.getByTestId("last-refreshed")).toContainText("Last refreshed");
  await expect(page.getByRole("row").nth(1)).toBeVisible();
});

test("searches and filters the fixture rules", async ({ page }) => {
  await page.getByRole("searchbox", { name: "Search rules" }).fill("Allow-Postgres");
  await expect(page.getByRole("row", { name: /Allow-Postgres/ })).toBeVisible();
  await expect(page.getByRole("row", { name: /Allow-HTTPS-Internet/ })).toHaveCount(0);

  await page.getByRole("button", { name: "Clear filters" }).click();
  await page.getByRole("searchbox", { name: "Search rules" }).fill("");
  await page.getByRole("button", { name: "Action" }).click();
  await page.getByRole("option", { name: "Deny", exact: true }).click();
  await expect(page.getByRole("row", { name: /DenyAllInBound/ }).first()).toBeVisible();
  await expect(page.getByRole("row", { name: /Allow-HTTPS-Internet/ })).toHaveCount(0);

  await page.getByRole("button", { name: "Clear filters" }).click();
  const port = page.getByRole("textbox", { name: "Destination port" });
  await port.fill("5432");
  await page.getByRole("searchbox", { name: "Search rules" }).fill("Allow-Postgres");
  await expect(page.getByRole("row", { name: /Allow-Postgres/ })).toBeVisible();
  await expect(page.getByRole("row", { name: /Allow-SSH-Corp/ })).toHaveCount(0);

  await page.getByRole("button", { name: "Clear filters" }).click();
  await page.getByRole("button", { name: "Subscription" }).click();
  await page.getByRole("option", { name: "Non-Production" }).click();
  await expect(page.getByRole("gridcell", { name: "Non-Production" }).first()).toBeVisible();
  await expect(page.getByRole("gridcell", { name: "Production Network" })).toHaveCount(0);
  await expect(page.getByRole("gridcell", { name: "Production Applications" })).toHaveCount(0);
});

test("opens the rule detail view", async ({ page }) => {
  await page.getByRole("searchbox", { name: "Search rules" }).fill("NET-1042");
  await page.getByRole("row", { name: /Allow-SSH-Corp/ }).click();
  const dialog = page.getByRole("dialog");
  await expect(dialog).toBeVisible();
  await expect(dialog).toContainText("NET-1042");
  await expect(dialog).toContainText("vm-jump-01");
  await expect(dialog).toContainText("nic-jump-01");
  await expect(dialog).toContainText("Raw JSON");
  await expect(dialog.locator("pre")).toContainText("Allow-SSH-Corp");
  await dialog.getByRole("button", { name: "Done" }).click();
  await expect(dialog).toBeHidden();
});

test("exports the filtered rows as CSV", async ({ page }) => {
  await page.getByRole("searchbox", { name: "Search rules" }).fill("Allow-Postgres");
  await expect(page.getByRole("row", { name: /Allow-Postgres/ })).toBeVisible();
  const [response] = await Promise.all([
    page.waitForResponse((item) => item.url().includes("/api/export") && item.ok()),
    page.getByRole("button", { name: "Export CSV" }).click(),
  ]);
  const body = await response.text();
  expect(body).toContain("ruleName");
  expect(body).toContain("Allow-Postgres");
  expect(body).not.toContain("Allow-HTTPS-Internet");
  expect(response.headers()["content-type"]).toContain("text/csv");
});

test("shows the admin refresh control and refreshes the snapshot", async ({ page }) => {
  await expect(page.getByTestId("refresh-snapshot")).toBeVisible();
  const before = await page.getByTestId("last-refreshed").innerText();
  await page.getByTestId("refresh-snapshot").click();
  await expect(page.getByText(/Snapshot refreshed/)).toBeVisible();
  await expect(page.getByTestId("last-refreshed")).not.toHaveText(before);
});

test("serves rules and refresh without a principal while auth is off", async ({ page, request }) => {
  await expect(page.getByTestId("auth-banner")).toBeVisible();
  await expect(page.getByTestId("refresh-snapshot")).toBeVisible();

  const rules = await request.get("/api/rules");
  expect(rules.status()).toBe(200);
  const body = (await rules.json()) as { meta: { authEnabled: boolean; canRefresh: boolean }; rules: unknown[] };
  expect(body.meta.authEnabled).toBe(false);
  expect(body.meta.canRefresh).toBe(true);
  expect(body.rules.length).toBeGreaterThan(0);

  const refreshed = await request.post("/api/refresh");
  expect(refreshed.status()).toBe(200);

  const ignoredHeader = await request.post("/api/refresh", {
    headers: { "x-ms-client-principal": "%%%" },
  });
  expect(ignoredHeader.status()).toBe(200);
});

import { expect, test } from "@playwright/test";

async function showRule(page: import("@playwright/test").Page) {
  await page.getByRole("searchbox", { name: "Search rules" }).fill("Allow-SSH-Corp");
  await expect(page.getByRole("row", { name: /Allow-SSH-Corp/ })).toBeVisible();
}

for (const theme of ["light", "dark"] as const) {
  test(`renders the table, filters, and detail in ${theme} mode`, async ({ page }) => {
    await page.goto("/");
    await page.evaluate(() => localStorage.removeItem("heroui-theme"));
    await page.reload();
    await page.getByRole("radio", { name: theme === "light" ? "Light" : "Dark" }).click();
    await expect(page.locator("html")).toHaveAttribute("data-theme", theme);
    await expect(page.locator("html")).toHaveClass(new RegExp(`\\b${theme}\\b`));
    await expect(page.getByRole("row").nth(1)).toBeVisible();
    await page.screenshot({ path: `/opt/cursor/artifacts/table-${theme}.png` });

    await page.getByRole("button", { name: "Action" }).click();
    await page.getByRole("option", { name: "Deny", exact: true }).click();
    await page.getByRole("searchbox", { name: "Search rules" }).fill("metadata");
    await expect(page.getByRole("row", { name: /Deny-Metadata/ })).toBeVisible();
    await expect(page.locator("html")).toHaveAttribute("data-theme", theme);
    await page.screenshot({ path: `/opt/cursor/artifacts/filters-${theme}.png` });

    await page.getByRole("button", { name: "Clear filters" }).click();
    await showRule(page);
    await page.getByRole("row", { name: /Allow-SSH-Corp/ }).click();
    const dialog = page.getByRole("dialog");
    await expect(dialog).toContainText("Raw JSON");
    await dialog.getByText("Raw JSON").scrollIntoViewIfNeeded();
    await expect(page.locator("html")).toHaveAttribute("data-theme", theme);
    await page.screenshot({ path: `/opt/cursor/artifacts/detail-${theme}.png` });
    await dialog.getByRole("button", { name: "Done" }).click();

    await page.reload();
    await expect(page.locator("html")).toHaveAttribute("data-theme", theme);
    await expect(page.locator("html")).toHaveClass(new RegExp(`\\b${theme}\\b`));
    await expect(page.getByRole("radio", { name: theme === "light" ? "Light" : "Dark" })).toHaveAttribute("aria-checked", "true");
  });
}

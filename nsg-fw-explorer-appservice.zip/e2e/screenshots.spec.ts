import { mkdir } from "node:fs/promises";
import { expect, test } from "@playwright/test";

const artifacts = "/opt/cursor/artifacts";

test("capture the table, filters, detail, and refresh", async ({ page }) => {
  await mkdir(artifacts, { recursive: true });
  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.goto("/");
  await expect(page.getByTestId("auth-banner")).toHaveText("Authentication disabled (test mode)");
  await expect(page.getByTestId("last-refreshed")).toContainText("Last refreshed");
  await expect(page.getByTestId("refresh-snapshot")).toBeVisible();
  await expect(page.getByRole("row").nth(1)).toBeVisible();
  await page.screenshot({ path: `${artifacts}/table-view.png` });

  await page.getByRole("button", { name: "Action" }).click();
  await page.getByRole("option", { name: "Deny", exact: true }).click();
  await page.getByRole("searchbox", { name: "Search rules" }).fill("metadata");
  await expect(page.getByRole("row", { name: /Deny-Metadata/ })).toBeVisible();
  await page.screenshot({ path: `${artifacts}/filters-applied.png` });

  await page.getByRole("button", { name: "Clear filters" }).click();
  await page.getByRole("searchbox", { name: "Search rules" }).fill("NET-1042");
  await page.getByRole("row", { name: /Allow-SSH-Corp/ }).click();
  const dialog = page.getByRole("dialog");
  await expect(dialog).toContainText("Raw JSON");
  await expect(dialog).toContainText("vm-jump-01");
  await dialog.getByText("Raw JSON").scrollIntoViewIfNeeded();
  await expect(dialog.locator("pre")).toBeVisible();
  await page.screenshot({ path: `${artifacts}/detail-view.png` });
  await dialog.getByRole("button", { name: "Done" }).click();

  await page.getByTestId("refresh-snapshot").click();
  await expect(page.getByText(/Snapshot refreshed/)).toBeVisible();
  await expect(page.getByTestId("last-refreshed")).toBeVisible();
  await page.screenshot({ path: `${artifacts}/admin-refresh.png` });
});

// Production server for Terrascape: serves the static Vite build (dist/) with zero dependencies.
//
// - Listens on process.env.PORT (set by Azure App Service), falling back to WEBSITES_PORT. If neither is set it asks
//   the OS for a free port (PORT=0 semantics) and logs it. No port number is hard-coded anywhere.
// - On App Service, TLS ends at the front end on 443 and requests reach this process as plain HTTP on that port.
// - The app uses hash routing (#/p/<id>), so every page is "/"; unknown non-asset paths still fall back to index.html.
// - Adds security headers (CSP, HSTS, nosniff, frame-ancestors, ...), long-lived caching for hashed assets,
//   no-cache + ETag for index.html, and pre-compressed gzip/brotli for text files.
import { createServer } from 'node:http';
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { brotliCompressSync, gzipSync, constants as zc } from 'node:zlib';
import { extname, join, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = fileURLToPath(new URL('.', import.meta.url));
const ROOT = resolve(process.env.STATIC_DIR ?? join(here, 'dist'));

const TYPES = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.ico': 'image/x-icon',
  '.woff2': 'font/woff2', '.woff': 'font/woff', '.txt': 'text/plain; charset=utf-8', '.map': 'application/json; charset=utf-8',
};
const COMPRESSIBLE = new Set(['.html', '.js', '.mjs', '.css', '.json', '.svg', '.txt', '.map']);

export const SECURITY_HEADERS = {
  'Content-Security-Policy': [
    "default-src 'self'",
    "script-src 'self'",
    "style-src 'self' 'unsafe-inline'", // React / React Flow set inline style attributes
    "img-src 'self' data: blob:", // inlined SVG icons, image export
    "font-src 'self' data:",
    "connect-src 'self' data: blob:", // diagram export fetches its own data: URL
    "worker-src 'self' blob:",
    "object-src 'none'",
    "base-uri 'self'",
    "form-action 'self'",
    "frame-ancestors 'none'",
  ].join('; '),
  'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'no-referrer',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=(), usb=()',
  'Cross-Origin-Opener-Policy': 'same-origin',
};

/** Read the whole build into memory once (about 2 MB): fast, and nothing on disk is touched per request. */
function loadFiles(root) {
  const files = new Map();
  const walk = (dir) => {
    for (const name of readdirSync(dir)) {
      const full = join(dir, name);
      if (statSync(full).isDirectory()) { walk(full); continue; }
      const ext = extname(name).toLowerCase();
      const body = readFileSync(full);
      const url = '/' + full.slice(root.length + 1).split(sep).join('/');
      const zip = COMPRESSIBLE.has(ext) && body.length > 1024;
      files.set(url, {
        body, type: TYPES[ext] ?? 'application/octet-stream',
        etag: `"${createHash('sha1').update(body).digest('base64url')}"`,
        gzip: zip ? gzipSync(body, { level: 9 }) : null,
        br: zip ? brotliCompressSync(body, { params: { [zc.BROTLI_PARAM_QUALITY]: 11 } }) : null,
        immutable: url.startsWith('/assets/'), // Vite content-hashes everything under assets/
      });
    }
  };
  walk(root);
  if (!files.has('/index.html')) throw new Error(`index.html not found in ${root}: run "npm run build" first`);
  return files;
}

export function createApp(root = ROOT) {
  const files = loadFiles(root);
  return createServer((req, res) => {
    for (const [k, v] of Object.entries(SECURITY_HEADERS)) res.setHeader(k, v);
    const path = (() => { try { return decodeURIComponent(new URL(req.url ?? '/', 'http://x').pathname); } catch { return null; } })();
    if (path === null || path.includes('\0')) { res.writeHead(400).end('Bad request'); return; }
    if (path === '/healthz') { res.writeHead(200, { 'Content-Type': 'text/plain', 'Cache-Control': 'no-store' }).end('ok'); return; }
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405, { Allow: 'GET, HEAD' }).end(); return; }
    // Files come only from the in-memory map, so "../" cannot escape the build folder.
    let f = files.get(path === '/' ? '/index.html' : path);
    if (!f) {
      // SPA fallback for page-like paths; a missing asset is a real 404 (so a stale chunk fails loudly).
      if (path.startsWith('/assets/') || extname(path)) { res.writeHead(404, { 'Content-Type': 'text/plain' }).end('Not found'); return; }
      f = files.get('/index.html');
    }
    const headers = {
      'Content-Type': f.type,
      'Cache-Control': f.immutable ? 'public, max-age=31536000, immutable' : 'no-cache',
      ETag: f.etag,
      Vary: 'Accept-Encoding',
    };
    if (req.headers['if-none-match'] === f.etag) { res.writeHead(304, headers).end(); return; }
    const accept = String(req.headers['accept-encoding'] ?? '');
    let body = f.body;
    if (f.br && /\bbr\b/.test(accept)) { body = f.br; headers['Content-Encoding'] = 'br'; }
    else if (f.gzip && /\bgzip\b/.test(accept)) { body = f.gzip; headers['Content-Encoding'] = 'gzip'; }
    headers['Content-Length'] = body.length;
    res.writeHead(200, headers);
    res.end(req.method === 'HEAD' ? undefined : body);
  });
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const port = Number(process.env.PORT || process.env.WEBSITES_PORT || 0);
  const server = createApp();
  server.listen(port, () => {
    const addr = server.address();
    console.log(`Terrascape serving ${ROOT} on port ${typeof addr === 'object' && addr ? addr.port : port}`);
  });
  const stop = () => server.close(() => process.exit(0));
  process.on('SIGTERM', stop);
  process.on('SIGINT', stop);
}

// Creates a sign-in user record (PBKDF2-SHA256, 210k iterations, random 16-byte salt). Zero dependencies: it ships in
// the Azure and local packages too. The password is read from stdin (typed hidden, or piped), never from argv, so it
// stays out of shell history; only the salt and hash are written.
//
//   node scripts/hash-password.mjs alice "Alice Example"                print the record (paste it into users.json)
//   node scripts/hash-password.mjs --add alice "Alice Example"          add / replace it in the users file
//   node scripts/hash-password.mjs --add --file path/users.json alice   ... in a specific file
//   printf '%s' "$PW" | node scripts/hash-password.mjs --add alice      non-interactive
//
// Default file for --add: config/users.json next to server.mjs (packages), else src/config/users.json (repo).
// The server re-reads the file on every sign-in, so no restart is needed. In the repo, src/config/users.json is also
// built into the app as the fallback list (rebuild to change that).
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { pbkdf2Sync, randomBytes } from 'node:crypto';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

const ITERATIONS = 210_000;
const args = process.argv.slice(2);
const add = args.includes('--add');
const fi = args.indexOf('--file');
const file = fi >= 0 ? args[fi + 1] : (() => {
  const root = fileURLToPath(new URL('..', import.meta.url));
  const packaged = join(root, 'config', 'users.json');
  return existsSync(packaged) ? packaged : join(root, 'src', 'config', 'users.json');
})();
const [username, displayName] = args.filter((a, i) => !a.startsWith('--') && !(fi >= 0 && i === fi + 1));
if (!username) {
  console.error('usage: node scripts/hash-password.mjs [--add [--file users.json]] <username> [display name]   (password on stdin)');
  process.exit(2);
}

async function readPassword() {
  const stdin = process.stdin;
  if (!stdin.isTTY) {
    let input = '';
    for await (const chunk of stdin) input += chunk;
    return input.replace(/\r?\n$/, '');
  }
  // interactive: hidden typing
  process.stderr.write(`Password for ${username}: `);
  stdin.setRawMode(true);
  stdin.resume();
  stdin.setEncoding('utf8');
  return new Promise((ok) => {
    let pw = '';
    stdin.on('data', (ch) => {
      for (const c of ch) {
        if (c === '\r' || c === '\n') { stdin.setRawMode(false); stdin.pause(); process.stderr.write('\n'); ok(pw); return; }
        if (c === '\u0003') { process.stderr.write('\n'); process.exit(130); }
        if (c === '\u007f' || c === '\b') pw = pw.slice(0, -1); else pw += c;
      }
    });
  });
}

const password = await readPassword();
if (password.length < 8) {
  console.error('Password must be at least 8 characters');
  process.exit(1);
}
const salt = randomBytes(16);
const rec = {
  username, displayName: displayName || username, salt: salt.toString('base64'),
  hash: pbkdf2Sync(password, salt, ITERATIONS, 32, 'sha256').toString('base64'), iterations: ITERATIONS,
};
if (!add) {
  console.log(JSON.stringify(rec, null, 2));
} else {
  const list = existsSync(file) ? JSON.parse(readFileSync(file, 'utf8')) : [];
  if (!Array.isArray(list)) { console.error(`${file} is not a JSON array of users`); process.exit(1); }
  const i = list.findIndex((u) => String(u.username).toLowerCase() === username.toLowerCase());
  if (i >= 0) list[i] = rec; else list.push(rec);
  writeFileSync(file, JSON.stringify(list, null, 2) + '\n');
  console.log(`${i >= 0 ? 'Updated' : 'Added'} user "${username}" in ${file}`);
}

// Production server for Terraverse 2.0: serves the static Vite build (dist/) with zero dependencies.
//
// - Listens on process.env.PORT (set by Azure App Service), falling back to WEBSITES_PORT. If neither is set it asks
//   the OS for a free port (PORT=0 semantics) and logs it. No port number is hard-coded anywhere.
// - On App Service, TLS ends at the front end on 443 and requests reach this process as plain HTTP on that port.
// - The app uses hash routing (#/p/<id>), so every page is "/"; unknown non-asset paths still fall back to index.html.
// - Adds security headers (CSP, HSTS, nosniff, frame-ancestors, ...), long-lived caching for hashed assets,
//   no-cache + ETag for index.html, and pre-compressed gzip/brotli for text files.
// - API: GET /api/ado/config and POST /api/ado/pr (Azure DevOps pull request from the generated .tf files). The logic lives
//   in server/ado.ts (Node 22.18+/24 runs it directly). Credentials come per request or from app settings
//   ADO_TENANT_ID / ADO_CLIENT_ID / ADO_CLIENT_SECRET (Key Vault references work: App Service resolves them into env).
//   The client secret is used for one token request and is never stored, logged or sent back.
// - API: POST /api/auth/login checks a user against the users file (USERS_FILE, else config/users.json next to this
//   file, else src/config/users.json in the repo): PBKDF2 hashes only, re-read on every login, failures throttled.
// - Local mode (`node server.mjs --local`, what the local package's npm start / start.sh / start.bat run): listens on
//   both loopbacks, 127.0.0.1 and ::1 (macOS browsers try ::1 first for "localhost"; ::1 is skipped when IPv6 is off),
//   port PORT or 8787. A port counts as taken when anything answers on either loopback or holds it as a wildcard
//   (e.g. an older server on ::), then it moves on to the next free port; an explicit PORT that is taken is a clear
//   error. Prints http://localhost:PORT and http://127.0.0.1:PORT, and reads settings from a .env file next to this file (ENV_FILE overrides the
//   path). Only the names of the settings it loaded are printed, never their values.
import { createServer } from 'node:http';
import { parseEnv } from 'node:util';
import { spawn } from 'node:child_process';
import { connect, createServer as netServer } from 'node:net';
import { existsSync, readdirSync, readFileSync, statSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { brotliCompressSync, gzipSync, constants as zc } from 'node:zlib';
import { extname, join, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createPullRequest, credentialsFromEnv, endpointsFromEnv, validatePrRequest } from './server/ado.ts';
import { createThrottle, readUsers, verifyLogin } from './server/auth.ts';
import { createOnboardingApi } from './server/onboarding/routes.ts';
import { createSessions } from './server/session.ts';

const here = fileURLToPath(new URL('.', import.meta.url));
const ROOT = resolve(process.env.STATIC_DIR ?? join(here, 'dist'));

const TYPES = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.ico': 'image/x-icon',
  '.woff2': 'font/woff2', '.woff': 'font/woff', '.txt': 'text/plain; charset=utf-8', '.map': 'application/json; charset=utf-8',
};
const COMPRESSIBLE = new Set(['.html', '.js', '.mjs', '.css', '.json', '.svg', '.txt', '.map']);

export const SECURITY_HEADERS = {
  'Content-Security-Policy': [
    "default-src 'self'",
    "script-src 'self'",
    "style-src 'self' 'unsafe-inline'", // React / React Flow set inline style attributes
    "img-src 'self' data: blob:", // inlined SVG icons, image export
    "font-src 'self' data:",
    "connect-src 'self' data: blob:", // diagram export fetches its own data: URL
    "worker-src 'self' blob:",
    "object-src 'none'",
    "base-uri 'self'",
    "form-action 'self'",
    "frame-ancestors 'none'",
  ].join('; '),
  'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'no-referrer',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=(), usb=()',
  'Cross-Origin-Opener-Policy': 'same-origin',
};

/** Read the whole build into memory once (about 2 MB): fast, and nothing on disk is touched per request. */
function loadFiles(root) {
  const files = new Map();
  const walk = (dir) => {
    for (const name of readdirSync(dir)) {
      const full = join(dir, name);
      if (statSync(full).isDirectory()) { walk(full); continue; }
      const ext = extname(name).toLowerCase();
      const body = readFileSync(full);
      const url = '/' + full.slice(root.length + 1).split(sep).join('/');
      const zip = COMPRESSIBLE.has(ext) && body.length > 1024;
      files.set(url, {
        body, type: TYPES[ext] ?? 'application/octet-stream',
        etag: `"${createHash('sha1').update(body).digest('base64url')}"`,
        gzip: zip ? gzipSync(body, { level: 9 }) : null,
        br: zip ? brotliCompressSync(body, { params: { [zc.BROTLI_PARAM_QUALITY]: 11 } }) : null,
        immutable: url.startsWith('/assets/'), // Vite content-hashes everything under assets/
      });
    }
  };
  try { walk(root); } catch { /* no build yet */ }
  return files;
}

const MAX_BODY = 3_000_000;
/** USERS_FILE, else config/users.json next to this file (packages), else the repo's src/config/users.json. */
export function defaultUsersFile(env = process.env) {
  if (env.USERS_FILE) return resolve(env.USERS_FILE);
  const packaged = join(here, 'config', 'users.json');
  return existsSync(packaged) ? packaged : join(here, 'src', 'config', 'users.json');
}
const json = (res, status, obj) => {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }).end(JSON.stringify(obj));
};

/** Read a JSON body (same-origin, application/json, HTTPS when forwarded); null after it has answered an error. */
async function readJson(req, res) {
  // HTTPS only: behind App Service the front end sets X-Forwarded-Proto; plain-HTTP requests never carry a secret here
  if (String(req.headers['x-forwarded-proto'] ?? '').split(',')[0].trim() === 'http') { json(res, 403, { error: 'HTTPS is required' }); return null; }
  if (req.method !== 'POST') { res.setHeader('Allow', 'POST'); json(res, 405, { error: 'Use POST' }); return null; }
  // same-origin JSON only (a cross-site form post can't send application/json without a CORS preflight, which we never grant)
  if (!String(req.headers['content-type'] ?? '').startsWith('application/json')) { json(res, 415, { error: 'Send application/json' }); return null; }
  const origin = req.headers.origin;
  if (origin && new URL(origin).host !== req.headers.host) { json(res, 403, { error: 'Cross-origin requests are not allowed' }); return null; }
  let size = 0;
  const chunks = [];
  for await (const c of req) {
    size += c.length;
    if (size > MAX_BODY) { json(res, 413, { error: 'Request too large' }); return null; }
    chunks.push(c);
  }
  let body;
  try { body = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { json(res, 400, { error: 'Invalid JSON' }); return null; }
  if (!body || typeof body !== 'object') { json(res, 400, { error: 'Invalid request' }); return null; }
  return body;
}

/** POST /api/auth/login. The password lives only in this function's scope; nothing about it is logged. */
async function handleLogin(req, res, { usersFile, throttle, log, sessions }) {
  const body = await readJson(req, res);
  if (!body) return;
  const { username, password } = body;
  if (typeof username !== 'string' || typeof password !== 'string' || !username.trim() || !password) return json(res, 400, { error: 'Enter a username and password' });
  let users;
  try { users = readUsers(usersFile); } catch (e) { log(`auth: cannot read ${usersFile} (${e.message})`); return json(res, 500, { error: 'Server misconfigured' }); }
  if (!users) return json(res, 404, { error: 'No users file on this server' });
  const who = req.socket.remoteAddress ?? '?';
  if (throttle.blocked(who)) return json(res, 429, { error: 'Too many failed sign-ins. Try again in a few minutes.' });
  const user = await verifyLogin(users, username, password);
  if (!user) { throttle.fail(who); return json(res, 401, { error: 'Wrong username or password' }); }
  throttle.ok(who);
  log(`auth: ${user.username} signed in`);
  // signed HttpOnly session cookie for the onboarding API (username + expiry only; roles are re-read per request)
  res.setHeader('Set-Cookie', sessions.setCookie(req, user.username));
  return json(res, 200, user);
}

/** POST /api/ado/pr and GET /api/ado/config. Never logs request bodies; the secret only lives in this function's scope. */
async function handleApi(req, res, path, ctx) {
  const { env, fetchImpl, log } = ctx;
  if (path === '/api/auth/login') return handleLogin(req, res, ctx);
  if (path === '/api/auth/logout') {
    if (req.method !== 'POST') { res.setHeader('Allow', 'POST'); return json(res, 405, { error: 'Use POST' }); }
    res.setHeader('Set-Cookie', ctx.sessions.clearCookie(req));
    return json(res, 200, { ok: true });
  }
  // onboarding (mock providers only; the ADO PAT never leaves the server)
  if (await ctx.onboarding.handle(req, res, path)) return;
  const serverCreds = credentialsFromEnv(env);
  if (path === '/api/ado/config' && req.method === 'GET') return json(res, 200, { serverCredentials: !!serverCreds });
  if (path !== '/api/ado/pr') return json(res, 404, { error: 'Not found' });
  const body = await readJson(req, res);
  if (!body) return;
  const { tenantId, clientId, clientSecret, ...prReq } = body;
  const creds = serverCreds ?? { tenantId: String(tenantId ?? ''), clientId: String(clientId ?? ''), clientSecret: String(clientSecret ?? '') };
  const fields = validatePrRequest(prReq, creds);
  if (Object.keys(fields).length) return json(res, 400, { ok: false, stage: 'validate', error: 'Some fields need attention', fields });
  let endpoints;
  try { endpoints = endpointsFromEnv(env); } catch (e) { log(`ado pr: bad endpoint config (${e.message})`); return json(res, 500, { ok: false, error: 'Server misconfigured' }); }
  try {
    const r = await createPullRequest(prReq, creds, { fetch: fetchImpl, endpoints });
    if (r.ok) { log(`ado pr: opened #${r.pullRequestId}`); return json(res, 201, r); }
    log(`ado pr: failed at ${r.stage} (HTTP ${r.status})`);
    return json(res, r.stage === 'validate' ? 400 : 502, { ...r, adoStatus: r.status });
  } catch (e) {
    log(`ado pr: network error (${e?.name ?? 'Error'})`);
    return json(res, 502, { ok: false, stage: 'network', error: 'Could not reach Azure DevOps or Microsoft Entra ID from the server' });
  }
}

/**
 * @param {string} [root] build folder (dist/)
 * @param {{ env?: Record<string, string | undefined>, fetch?: typeof fetch, log?: (line: string) => void, apiOnly?: boolean, usersFile?: string }} [opts]
 * @returns {import('node:http').Server & { onboarding: ReturnType<typeof createOnboardingApi> }}
 */
export function createApp(root = ROOT, opts = {}) {
  const files = opts.apiOnly ? new Map() : loadFiles(root);
  const env = opts.env ?? process.env;
  const api = {
    env, fetchImpl: opts.fetch ?? globalThis.fetch, log: opts.log ?? ((l) => console.log(l)),
    usersFile: opts.usersFile ?? defaultUsersFile(env), throttle: createThrottle(),
    sessions: createSessions(env.SESSION_SECRET),
  };
  api.onboarding = createOnboardingApi({ env, root: here, usersFile: api.usersFile, sessions: api.sessions, log: api.log, json, readJson });
  if (!files.has('/index.html') && !opts.apiOnly) api.log(`No build found in ${root}: serving the API only (run "npm run build" for the app)`);
  const server = createServer((req, res) => {
    for (const [k, v] of Object.entries(SECURITY_HEADERS)) res.setHeader(k, v);
    const path = (() => { try { return decodeURIComponent(new URL(req.url ?? '/', 'http://x').pathname); } catch { return null; } })();
    if (path === null || path.includes('\0')) { res.writeHead(400).end('Bad request'); return; }
    if (path === '/healthz') { res.writeHead(200, { 'Content-Type': 'text/plain', 'Cache-Control': 'no-store' }).end('ok'); return; }
    if (path.startsWith('/api/')) { handleApi(req, res, path, api).catch(() => { if (!res.headersSent) json(res, 500, { ok: false, error: 'Internal error' }); }); return; }
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405, { Allow: 'GET, HEAD' }).end(); return; }
    // Files come only from the in-memory map, so "../" cannot escape the build folder.
    let f = files.get(path === '/' ? '/index.html' : path);
    if (!f && !files.has('/index.html')) { res.writeHead(503, { 'Content-Type': 'text/plain' }).end('No build: run "npm run build"'); return; }
    if (!f) {
      // SPA fallback for page-like paths; a missing asset is a real 404 (so a stale chunk fails loudly).
      if (path.startsWith('/assets/') || extname(path)) { res.writeHead(404, { 'Content-Type': 'text/plain' }).end('Not found'); return; }
      f = files.get('/index.html');
    }
    const headers = {
      'Content-Type': f.type,
      'Cache-Control': f.immutable ? 'public, max-age=31536000, immutable' : 'no-cache',
      ETag: f.etag,
      Vary: 'Accept-Encoding',
    };
    if (req.headers['if-none-match'] === f.etag) { res.writeHead(304, headers).end(); return; }
    const accept = String(req.headers['accept-encoding'] ?? '');
    let body = f.body;
    if (f.br && /\bbr\b/.test(accept)) { body = f.br; headers['Content-Encoding'] = 'br'; }
    else if (f.gzip && /\bgzip\b/.test(accept)) { body = f.gzip; headers['Content-Encoding'] = 'gzip'; }
    headers['Content-Length'] = body.length;
    res.writeHead(200, headers);
    res.end(req.method === 'HEAD' ? undefined : body);
  });
  server.onboarding = api.onboarding;
  return server;
}

export const LOCAL_DEFAULT_PORT = 8787;

/** Load KEY=value lines from a .env file into `env` (variables already set win). Returns the names it set, never values. */
export function loadDotEnv(file, env = process.env) {
  if (!existsSync(file)) return [];
  const set = [];
  for (const [k, v] of Object.entries(parseEnv(readFileSync(file, 'utf8')))) {
    if (env[k] !== undefined) continue;
    env[k] = v;
    set.push(k);
  }
  return set;
}

/**
 * Listen on `port`; when it is taken and the port was not chosen explicitly (`strict: false`), try the next ones.
 * Resolves with the port in use. A taken explicit port rejects with a friendly Error (code EADDRINUSE).
 */
export function listenWithFallback(server, port, { strict, host, tries = 20 }) {
  return new Promise((ok, fail) => {
    const attempt = (p, left) => {
      const onError = (e) => {
        server.off('listening', onListening);
        if (e.code === 'EADDRINUSE' && !strict && left > 0) return attempt(p + 1, left - 1);
        const err = new Error(e.code === 'EADDRINUSE'
          ? `Port ${p} is already in use (another Terraverse or another app is running there). Stop it, or start on another port, e.g. PORT=${p + 1} npm start`
          : e.code === 'EACCES' ? `Not allowed to listen on port ${p}. Pick a port above 1024, e.g. PORT=8787 npm start` : `Could not listen on port ${p}: ${e.message}`);
        err.code = e.code;
        fail(err);
      };
      const onListening = () => { server.off('error', onError); ok(server.address().port); };
      server.once('error', onError);
      server.once('listening', onListening);
      server.listen(p, host);
    };
    attempt(port, tries);
  });
}

const portError = (p, code, message) => {
  const err = new Error(code === 'EADDRINUSE'
    ? `Port ${p} is already in use (another Terraverse or another app is running there). Stop it, or start on another port, e.g. PORT=${p + 1} npm start`
    : code === 'EACCES' ? `Not allowed to listen on port ${p}. Pick a port above 1024, e.g. PORT=8787 npm start` : `Could not listen on port ${p}: ${message}`);
  err.code = code;
  return err;
};
/** true when something accepts connections on host:port */
const answers = (host, port) => new Promise((ok) => {
  const sock = connect({ host, port });
  const done = (v) => { sock.destroy(); ok(v); };
  sock.setTimeout(400, () => done(false));
  sock.once('connect', () => done(true));
  sock.once('error', () => done(false));
});
/** 'busy' when the bind fails because the port is held; 'n/a' when the address family is unavailable */
const tryBind = (host, port) => new Promise((ok) => {
  const t = netServer();
  t.once('error', (e) => ok(e.code === 'EADDRINUSE' || e.code === 'EACCES' ? (e.code === 'EACCES' ? 'eacces' : 'busy') : 'n/a'));
  t.listen({ port, host, exclusive: true }, () => t.close(() => ok('free')));
});
const listenOn = (srv, port, host) => new Promise((ok, fail) => {
  const onErr = (e) => { srv.off('listening', onOk); fail(e); };
  const onOk = () => { srv.off('error', onErr); ok(); };
  srv.once('error', onErr);
  srv.once('listening', onOk);
  srv.listen({ port, host, exclusive: true });
});
const NO_FAMILY = new Set(['EADDRNOTAVAIL', 'EAFNOSUPPORT', 'EINVAL']);

/**
 * Local mode: serve `server`'s requests on 127.0.0.1 AND ::1 (tolerating a machine without IPv6). A port is taken when
 * anything answers on either loopback, or a wildcard (:: / 0.0.0.0) or loopback bind fails; then the next port is
 * tried unless `strict`. Resolves with the port and a close() for both listeners.
 */
export async function listenLocal(server, port, { strict, tries = 20 }) {
  for (let p = port; p <= port + tries; p++) {
    let busy = (await answers('127.0.0.1', p)) || (await answers('::1', p));
    if (!busy) for (const h of ['::', '0.0.0.0']) { const r = await tryBind(h, p); if (r === 'eacces') throw portError(p, 'EACCES'); if (r === 'busy') busy = true; }
    if (!busy) {
      try {
        await listenOn(server, p, '127.0.0.1');
      } catch (e) {
        if (e.code !== 'EADDRINUSE') throw portError(p, e.code, e.message);
        busy = true;
      }
    }
    if (!busy) {
      const v6 = createServer((q, r) => server.emit('request', q, r));
      try {
        await listenOn(v6, p, '::1');
        return { port: p, servers: [server, v6], close: () => Promise.all([server, v6].map((x) => new Promise((ok) => x.close(() => ok())))) };
      } catch (e) {
        if (NO_FAMILY.has(e.code)) return { port: p, servers: [server], close: () => new Promise((ok) => server.close(() => ok())) };
        await new Promise((ok) => server.close(() => ok()));
        if (e.code !== 'EADDRINUSE') throw portError(p, e.code, e.message);
        busy = true;
      }
    }
    if (strict) throw portError(p, 'EADDRINUSE');
  }
  throw new Error(`No free port between ${port} and ${port + tries}. Stop other servers (see README-LOCAL.md) or set PORT.`);
}

function openBrowser(url) {
  const [cmd, args] = process.platform === 'darwin' ? ['open', [url]] : process.platform === 'win32' ? ['cmd', ['/c', 'start', '', url]] : ['xdg-open', [url]];
  try { spawn(cmd, args, { stdio: 'ignore', detached: true }).on('error', () => {}).unref(); } catch { /* no browser: the URL is printed */ }
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const apiOnly = process.argv.includes('--api-only');
  const local = process.argv.includes('--local');
  if (local) {
    const envFile = resolve(process.env.ENV_FILE ?? join(here, '.env'));
    const names = loadDotEnv(envFile);
    if (names.length) console.log(`Loaded ${names.length} setting(s) from ${envFile}: ${names.join(', ')}`);
  }
  const explicit = process.env.PORT || process.env.WEBSITES_PORT;
  const port = Number(explicit || (local ? LOCAL_DEFAULT_PORT : 0));
  const server = createApp(ROOT, { apiOnly });
  // local: both loopbacks unless HOST pins one address; App Service: whatever PORT on all interfaces
  const pinned = local && process.env.HOST;
  const started = local && !pinned
    ? listenLocal(server, port, { strict: !!explicit })
    : listenWithFallback(server, port, { strict: !local || !!explicit, host: pinned || undefined }).then((p) => ({ port: p, servers: [server] }));
  let servers = [server];
  started.then(({ port: p, servers: list }) => {
    servers = list;
    console.log(`Terraverse 2.0 ${apiOnly ? 'API (/api only)' : `serving ${ROOT}`} on port ${p}`);
    if (local) {
      const url = `http://localhost:${p}`, ip = `http://${pinned && pinned !== 'localhost' ? (pinned.includes(':') ? `[${pinned}]` : pinned) : '127.0.0.1'}:${p}`;
      if (p !== port) console.log(`(port ${port} was busy, so Terraverse moved to ${p})`);
      console.log(`\n  Open ${url}\n    or ${ip}   (use this one if the first does not load)\n\n  Press Ctrl+C to stop.\n`);
      if (process.argv.includes('--open')) openBrowser(ip);
    }
  }, (e) => {
    console.error(`\nTerraverse 2.0 could not start: ${e.message}\n`);
    process.exit(1);
  });
  const stop = () => Promise.all(servers.map((x) => new Promise((ok) => x.close(() => ok())))).then(() => process.exit(0));
  process.on('SIGTERM', stop);
  process.on('SIGINT', stop);
}

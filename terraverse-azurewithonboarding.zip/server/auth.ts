/**
 * Server-side sign-in against a users file (config/users.json): PBKDF2-SHA256 hashes only, the same records
 * scripts/hash-password.mjs writes and src/lib/auth.ts understands. The file is re-read on every login, so a user
 * added to it can sign in without a restart. Passwords are never stored or logged.
 *
 * Plain erasable TypeScript, so Node 22.18+/24 runs it directly (type stripping) from server.mjs.
 */
import { existsSync, readFileSync } from 'node:fs';
import { pbkdf2 as pbkdf2cb, timingSafeEqual } from 'node:crypto';

export interface UserRecord { username: string; displayName: string; salt: string; hash: string; iterations: number; roles?: string[] }
export interface User { username: string; displayName: string; roles?: string[] }

const DUMMY_SALT = Buffer.alloc(16);
const DUMMY_ITER = 210_000;

const pbkdf2 = (password: string, salt: Buffer, iterations: number) =>
  new Promise<Buffer>((ok, fail) => pbkdf2cb(password, salt, iterations, 32, 'sha256', (e, k) => (e ? fail(e) : ok(k))));

/** Records from the file; null when the file does not exist (no server-side users configured). */
export function readUsers(file: string): UserRecord[] | null {
  if (!existsSync(file)) return null;
  const data = JSON.parse(readFileSync(file, 'utf8')) as unknown;
  const list = Array.isArray(data) ? data : (data as { users?: unknown })?.users;
  if (!Array.isArray(list)) throw new Error('users file must be a JSON array of user records');
  return list.filter((u): u is UserRecord => !!u && typeof u.username === 'string' && typeof u.salt === 'string'
    && typeof u.hash === 'string' && Number.isInteger(u.iterations) && u.iterations > 0);
}

/** The user when the password matches; null otherwise. Unknown users cost the same KDF time as wrong passwords. */
export async function verifyLogin(users: UserRecord[], username: string, password: string): Promise<User | null> {
  const name = username.trim().toLowerCase();
  const rec = users.find((u) => u.username.toLowerCase() === name);
  if (!rec) { await pbkdf2(password, DUMMY_SALT, DUMMY_ITER); return null; }
  const want = Buffer.from(rec.hash, 'base64');
  const got = await pbkdf2(password, Buffer.from(rec.salt, 'base64'), rec.iterations);
  return want.length === got.length && timingSafeEqual(want, got)
    ? { username: rec.username, displayName: rec.displayName || rec.username, ...(Array.isArray(rec.roles) ? { roles: rec.roles.filter((r) => typeof r === 'string') } : {}) }
    : null;
}

/** Failed-login counter per client: after `max` failures in `windowMs`, further attempts get 429 until the window passes. */
export function createThrottle(max = 10, windowMs = 5 * 60_000) {
  const fails = new Map<string, { n: number; until: number }>();
  return {
    blocked(key: string, now = Date.now()) { const f = fails.get(key); if (f && f.until < now) fails.delete(key); return (fails.get(key)?.n ?? 0) >= max; },
    fail(key: string, now = Date.now()) { const f = fails.get(key); fails.set(key, f && f.until >= now ? { n: f.n + 1, until: f.until } : { n: 1, until: now + windowMs }); },
    ok(key: string) { fails.delete(key); },
  };
}

/**
 * Server session for the onboarding API: after POST /api/auth/login succeeds the server sets a signed, HttpOnly,
 * SameSite=Strict cookie holding only {username, expiry}. Roles are NOT in the cookie; they are re-read from the users
 * file on every request, so removing a role takes effect at once. The signing key is SESSION_SECRET, else random per
 * process (a restart signs everyone out of the onboarding API, which is fine for a demo).
 */
import { createHmac, randomBytes, timingSafeEqual } from 'node:crypto';
import type { IncomingMessage } from 'node:http';

export const SESSION_COOKIE = 'tv_session';
export const SESSION_MS = 8 * 60 * 60 * 1000;

const b64 = (b: Buffer | string) => Buffer.from(b).toString('base64url');
const isHttps = (req: IncomingMessage) => String(req.headers['x-forwarded-proto'] ?? '').split(',')[0].trim() === 'https';

export function createSessions(secret?: string, ttlMs = SESSION_MS, now: () => number = Date.now) {
  const key = secret && secret.length >= 16 ? Buffer.from(secret, 'utf8') : randomBytes(32);
  const sign = (payload: string) => createHmac('sha256', key).update(payload).digest();
  const attrs = (req: IncomingMessage) => `Path=/api; HttpOnly; SameSite=Strict${isHttps(req) ? '; Secure' : ''}`;
  return {
    issue(username: string): string {
      const payload = b64(JSON.stringify({ u: username, exp: now() + ttlMs }));
      return `${payload}.${b64(sign(payload))}`;
    },
    verify(token: string | undefined): string | null {
      if (!token) return null;
      const [payload, mac] = token.split('.');
      if (!payload || !mac) return null;
      const want = sign(payload);
      const got = Buffer.from(mac, 'base64url');
      if (got.length !== want.length || !timingSafeEqual(got, want)) return null;
      try {
        const p = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8')) as { u?: unknown; exp?: unknown };
        return typeof p.u === 'string' && typeof p.exp === 'number' && p.exp > now() ? p.u : null;
      } catch { return null; }
    },
    fromRequest(req: IncomingMessage): string | null {
      const raw = String(req.headers.cookie ?? '');
      const hit = raw.split(';').map((c) => c.trim()).find((c) => c.startsWith(`${SESSION_COOKIE}=`));
      return this.verify(hit?.slice(SESSION_COOKIE.length + 1));
    },
    setCookie(req: IncomingMessage, username: string) { return `${SESSION_COOKIE}=${this.issue(username)}; Max-Age=${Math.floor(ttlMs / 1000)}; ${attrs(req)}`; },
    clearCookie(req: IncomingMessage) { return `${SESSION_COOKIE}=; Max-Age=0; ${attrs(req)}`; },
  };
}
export type Sessions = ReturnType<typeof createSessions>;

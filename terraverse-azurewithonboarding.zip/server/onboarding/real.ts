/**
 * Real providers (Graph, ARM, Azure DevOps): DISABLED. Every method throws before any network call, so nothing can
 * reach Microsoft from this build. Enabling them is a later slice that needs Vivek's OK (see PLAN.md §11): Graph and
 * ARM via the App Service managed identity, Azure DevOps via ONBOARDING_ADO_PAT (server-side only).
 */
import { ProviderError, type AdoProvider, type ArmProvider, type GraphProvider, type Providers } from './providers.ts';

const off = (api: string) => () => Promise.reject(new ProviderError('ProvidersDisabled', `Real ${api} calls are disabled in this build (mock mode only).`, { status: 501 }));

export function createRealProviders(): Providers {
  const graph: GraphProvider = {
    findUser: off('Graph'), searchUsers: off('Graph'), findGroup: off('Graph'), createGroup: off('Graph'), listMemberIds: off('Graph'), addMember: off('Graph'),
    findApplication: off('Graph'), createApplication: off('Graph'), findServicePrincipal: off('Graph'), createServicePrincipal: off('Graph'),
    listFederatedCredentials: off('Graph'), addFederatedCredential: off('Graph'),
  };
  const arm: ArmProvider = {
    listSubscriptions: off('ARM'), resourceGroupExists: off('ARM'), createResourceGroup: off('ARM'), resolveRole: off('ARM'),
    roleAssignmentExists: off('ARM'), createRoleAssignment: off('ARM'),
  };
  const ado: AdoProvider = {
    getProject: off('Azure DevOps'), createProject: off('Azure DevOps'), getOperation: off('Azure DevOps'), findEntitlement: off('Azure DevOps'),
    isProjectReader: off('Azure DevOps'), addEntitlement: off('Azure DevOps'), addProjectReader: off('Azure DevOps'), findEndpoint: off('Azure DevOps'),
    createEndpoint: off('Azure DevOps'),
  };
  return { kind: 'real', graph, arm, ado };
}

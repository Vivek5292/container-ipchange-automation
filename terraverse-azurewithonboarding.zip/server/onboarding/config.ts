/**
 * Onboarding settings. One file; the setting that matters most:
 *
 *   config/onboarding.json  →  "serviceConnectionRole": "<role name or role definition ID>"   (default "Reader")
 *   env ONBOARDING_SC_ROLE  →  overrides the file (App Service app setting / .env)
 *
 * It is the Azure role the service connection's app registration gets on each onboarded resource group.
 * ONBOARDING_ADO_PAT (the Azure DevOps PAT) is read from the environment only; it is never returned, logged or stored.
 * Plain erasable TypeScript so server.mjs can import it directly (Node type stripping).
 */
import { existsSync, readFileSync } from 'node:fs';

export const DEFAULT_SC_ROLE = 'Reader';
const GUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const NAME = /^[\w .()&-]{2,128}$/;

export interface OnboardingConfig {
  serviceConnectionRole: string; roleIsId: boolean; source: 'env' | 'file' | 'default';
  /** an approver may approve their own request (demo default true; set false for four-eyes) */
  allowSelfApproval: boolean;
  /** demo: the wizard may ask a step to fail once, to show Retry (mock mode only) */
  allowFailureInjection: boolean;
}

function check(v: unknown, where: string): string {
  const s = typeof v === 'string' ? v.trim() : '';
  if (!s || !(GUID.test(s) || NAME.test(s))) throw new Error(`${where}: serviceConnectionRole must be a role name or a role definition ID (GUID)`);
  return s;
}

export function readOnboardingConfig(file: string, env: Record<string, string | undefined>): OnboardingConfig {
  let role = DEFAULT_SC_ROLE;
  let source: OnboardingConfig['source'] = 'default';
  const flags = { allowSelfApproval: true, allowFailureInjection: true };
  if (existsSync(file)) {
    const j = JSON.parse(readFileSync(file, 'utf8')) as { serviceConnectionRole?: unknown; allowSelfApproval?: unknown; allowFailureInjection?: unknown };
    if (j.serviceConnectionRole !== undefined) { role = check(j.serviceConnectionRole, file); source = 'file'; }
    if (typeof j.allowSelfApproval === 'boolean') flags.allowSelfApproval = j.allowSelfApproval;
    if (typeof j.allowFailureInjection === 'boolean') flags.allowFailureInjection = j.allowFailureInjection;
  }
  if (env.ONBOARDING_SC_ROLE !== undefined && env.ONBOARDING_SC_ROLE !== '') { role = check(env.ONBOARDING_SC_ROLE, 'ONBOARDING_SC_ROLE'); source = 'env'; }
  return { serviceConnectionRole: role, roleIsId: GUID.test(role), source, ...flags };
}

/** What the browser may see: the role and where it came from, whether a PAT is configured (never the PAT). */
export function publicOnboardingConfig(c: OnboardingConfig, env: Record<string, string | undefined>) {
  return {
    serviceConnectionRole: c.serviceConnectionRole, roleIsId: c.roleIsId, source: c.source, adoAuth: 'pat' as const, patConfigured: !!env.ONBOARDING_ADO_PAT,
    mode: env.ONBOARDING_PROVIDERS === 'real' ? 'real-disabled' as const : 'mock' as const,
    allowSelfApproval: c.allowSelfApproval, allowFailureInjection: c.allowFailureInjection && env.ONBOARDING_PROVIDERS !== 'real',
  };
}

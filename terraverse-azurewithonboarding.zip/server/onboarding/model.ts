/** Onboarding request model: input validation, derived names and the record shape persisted by ./store.ts. */
import { createHash } from 'node:crypto';
import type { Subscription } from './providers.ts';

export const ENVS = ['dev', 'test', 'prod'] as const;
export const REGIONS: Record<string, { label: string; short: string }> = {
  australiaeast: { label: 'Australia East', short: 'aue' },
  australiasoutheast: { label: 'Australia Southeast', short: 'ause' },
};
export const STEP_KINDS = ['group', 'members', 'rg', 'rbac', 'project', 'connection'] as const;
export type StepKind = (typeof STEP_KINDS)[number];
export type Env = (typeof ENVS)[number];

export interface OnbInput {
  app: string; code: string; env: Env; owner: string; costCentre: string; description: string;
  members: string[]; subscriptionIds: string[]; region: string; project: string;
  /** demo only: fail this step once (needs allowFailureInjection) */
  inject: StepKind | null;
}
export interface Names { group: string; rg: string; project: string; connections: Record<string, string> }

export type ReqStatus = 'pending' | 'approved' | 'rejected' | 'running' | 'completed' | 'failed';
export type StepStateName = 'pending' | 'running' | 'done' | 'failed';
export type StepResult = 'created' | 'added' | 'exists';
export interface StepState {
  key: string; kind: StepKind; title: string; target: string; subId?: string;
  state: StepStateName; result?: StepResult; attempts: number; log: string[]; error?: string;
  startedAt?: string; finishedAt?: string; outputs: Record<string, string>;
}
export interface PlanItem { key: string; kind: StepKind; title: string; target: string; action: 'create' | 'add' | 'exists'; detail: string }
export interface Person { username: string; displayName: string }
export interface OnbRecord {
  id: string; status: ReqStatus; input: OnbInput; names: Names; subscriptions: Subscription[];
  serviceConnectionRole: string; requestedBy: Person; createdAt: string; updatedAt: string;
  approval?: { decision: 'approved' | 'rejected'; by: Person; at: string; reason?: string };
  plan: PlanItem[]; steps: StepState[]; injectConsumed: boolean; runs: number;
  history: { at: string; event: string; by?: string }[];
}

const s = (v: unknown, max = 200) => (typeof v === 'string' ? v.trim().slice(0, max) : '');
const UPN = /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/i;
const GUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/** Normalise and validate a request body. Returns field errors (keyed by field) or the clean input. */
export function validateInput(body: unknown, opts: { allowInject: boolean }): { input?: OnbInput; fields: Record<string, string> } {
  const b = (body && typeof body === 'object' ? body : {}) as Record<string, unknown>;
  const fields: Record<string, string> = {};
  const input: OnbInput = {
    app: s(b.app, 80), code: s(b.code, 12).toLowerCase(), env: s(b.env) as Env, owner: s(b.owner, 120), costCentre: s(b.costCentre, 40),
    description: s(b.description, 500),
    members: [...new Set((Array.isArray(b.members) ? b.members : []).map((m) => s(m, 254).toLowerCase()).filter(Boolean))],
    subscriptionIds: [...new Set((Array.isArray(b.subscriptionIds) ? b.subscriptionIds : []).map((x) => s(x, 36).toLowerCase()).filter(Boolean))],
    region: s(b.region, 40), project: s(b.project, 64),
    inject: STEP_KINDS.includes(b.inject as StepKind) ? (b.inject as StepKind) : null,
  };
  if (input.app.length < 2) fields.app = 'Enter the application name';
  if (!/^[a-z][a-z0-9]{2,11}$/.test(input.code)) fields.code = 'Short code: 3–12 lowercase letters or digits, starting with a letter';
  if (!ENVS.includes(input.env)) fields.env = 'Pick dev, test or prod';
  if (input.owner.length < 2) fields.owner = 'Enter the business owner';
  if (!input.members.length) fields.members = 'Add at least one person';
  else if (input.members.length > 50) fields.members = 'At most 50 people per request';
  else if (input.members.some((m) => !UPN.test(m))) fields.members = 'Members must be user principal names (name@domain)';
  if (!input.subscriptionIds.length) fields.subscriptionIds = 'Pick at least one subscription';
  else if (input.subscriptionIds.some((x) => !GUID.test(x))) fields.subscriptionIds = 'Unknown subscription';
  if (!REGIONS[input.region]) fields.region = 'Pick a region';
  if (!/^[\w][\w .-]{1,63}$/.test(input.project)) fields.project = 'Project name: 2–64 letters, digits, spaces, dots, dashes or underscores';
  if (input.inject && !opts.allowInject) fields.inject = 'Failure injection is turned off on this server';
  return Object.keys(fields).length ? { fields } : { input, fields };
}

const slug = (n: string) => n.toLowerCase().replace(/^contoso\s+/, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 20);
export function deriveNames(input: OnbInput, subs: Subscription[]): Names {
  const r = REGIONS[input.region]?.short ?? 'x';
  const base = `${input.code}-${input.env}`;
  const many = subs.length > 1;
  return {
    group: `sg-${base}-readers`, rg: `rg-${base}-${r}`, project: input.project,
    connections: Object.fromEntries(subs.map((sub) => [sub.id, many ? `sc-${base}-${r}-${slug(sub.name)}` : `sc-${base}-${r}`])),
  };
}

/** RFC 4122 v5 UUID (SHA-1, URL namespace): the deterministic role-assignment name, so a retry can never duplicate it. */
export function uuidv5(name: string): string {
  const ns = Buffer.from('6ba7b8119dad11d180b400c04fd430c8', 'hex');
  const h = createHash('sha1').update(Buffer.concat([ns, Buffer.from(name, 'utf8')])).digest();
  h[6] = (h[6] & 0x0f) | 0x50;
  h[8] = (h[8] & 0x3f) | 0x80;
  const x = h.subarray(0, 16).toString('hex');
  return `${x.slice(0, 8)}-${x.slice(8, 12)}-${x.slice(12, 16)}-${x.slice(16, 20)}-${x.slice(20)}`;
}

/** The ordered steps of a request (rg, rbac and connection once per subscription). */
export function stepList(names: Names, subs: Subscription[], memberCount: number): StepState[] {
  const st = (key: string, kind: StepKind, title: string, target: string, subId?: string): StepState =>
    ({ key, kind, title, target, ...(subId ? { subId } : {}), state: 'pending', attempts: 0, log: [], outputs: {} });
  return [
    st('group', 'group', 'Entra ID security group', names.group),
    st('members', 'members', 'Group members', `${memberCount} ${memberCount === 1 ? 'person' : 'people'}`),
    ...subs.map((sub) => st(`rg:${sub.id}`, 'rg', 'Resource group', `${names.rg} · ${sub.name}`, sub.id)),
    ...subs.map((sub) => st(`rbac:${sub.id}`, 'rbac', 'Reader for the group', `${names.rg} · ${sub.name}`, sub.id)),
    st('project', 'project', 'Azure DevOps project', names.project),
    ...subs.map((sub) => st(`connection:${sub.id}`, 'connection', 'ARM service connection', names.connections[sub.id], sub.id)),
  ];
}

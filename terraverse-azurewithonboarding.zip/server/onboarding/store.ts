/**
 * Request records on disk: one JSON file per request in ONBOARDING_DATA_DIR (default data/onboarding, gitignored).
 * Writes are atomic (write a temp file, then rename over the old one), so a crash never leaves half a record.
 */
import { existsSync, mkdirSync, readdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { randomBytes } from 'node:crypto';
import type { OnbRecord } from './model.ts';

const ID = /^onb-\d{4,}$/;

export function writeJsonAtomic(file: string, data: unknown) {
  const tmp = `${file}.${process.pid}.${randomBytes(4).toString('hex')}.tmp`;
  writeFileSync(tmp, `${JSON.stringify(data, null, 2)}\n`, { mode: 0o600 });
  renameSync(tmp, file);
}

export function createStore(dir: string) {
  mkdirSync(dir, { recursive: true });
  const file = (id: string) => join(dir, `${id}.json`);
  const ids = () => readdirSync(dir).filter((f) => f.endsWith('.json')).map((f) => f.slice(0, -5)).filter((id) => ID.test(id));
  return {
    dir,
    get(id: string): OnbRecord | null {
      if (!ID.test(id) || !existsSync(file(id))) return null;
      return JSON.parse(readFileSync(file(id), 'utf8')) as OnbRecord;
    },
    save(rec: OnbRecord) { if (!ID.test(rec.id)) throw new Error('bad id'); writeJsonAtomic(file(rec.id), rec); },
    list(): OnbRecord[] {
      return ids().map((id) => { try { return JSON.parse(readFileSync(file(id), 'utf8')) as OnbRecord; } catch { return null; } })
        .filter((r): r is OnbRecord => !!r).sort((a, b) => b.id.localeCompare(a.id, 'en', { numeric: true }));
    },
    nextId(): string {
      const n = ids().reduce((m, id) => Math.max(m, Number(id.slice(4))), 100);
      return `onb-${String(n + 1).padStart(4, '0')}`;
    },
  };
}
export type Store = ReturnType<typeof createStore>;

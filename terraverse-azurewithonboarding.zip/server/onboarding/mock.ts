/**
 * Mock providers: an in-memory "tenant" (Entra ID directory, Azure subscriptions, an Azure DevOps organisation)
 * seeded from a fixture. No network, no credentials. Behaves like the real services where it matters for the step
 * engine: lookups before creates, IDs, a role assignment that fails with PrincipalNotFound until a new principal
 * has "replicated" (consistencyMs), and asynchronous ADO project creation (operationPolls).
 */
import { randomUUID } from 'node:crypto';
import { ProviderError, type AdoProvider, type ArmProvider, type DirectoryUser, type GraphProvider, type Providers, type Subscription } from './providers.ts';

export interface MockWorld {
  users: DirectoryUser[];
  subscriptions: Subscription[];
  groups: { id: string; displayName: string; mailNickname: string; members: string[]; createdAt: number }[];
  apps: { id: string; appId: string; displayName: string; fics: { name: string; issuer: string; subject: string }[] }[];
  sps: { id: string; appId: string; createdAt: number }[];
  rgs: { subId: string; name: string; location: string; tags: Record<string, string> }[];
  assignments: { scope: string; name: string; roleDefinitionId: string; principalId: string }[];
  projects: { id: string; name: string; readers: string[]; endpoints: { id: string; name: string; issuer: string; subject: string }[] }[];
  operations: { id: string; name: string; polls: number; projectId?: string }[];
  entitlements: { upn: string; id: string; license: string }[];
}

export const MOCK_TENANT_ID = '72f988bf-0000-4000-8000-00000000c0de';
export const ROLES: Record<string, string> = {
  reader: 'acdd72a7-3385-48ef-bd42-f606fba81ae7',
  contributor: 'b24988ac-6180-42a0-ab88-20f7382dd24c',
  /** a fictional custom role, so the custom-role setting can be demoed */
  'terraverse app deployer': '7e5d2c1a-0000-4000-8000-00000000d301',
};

const person = (n: number, name: string): DirectoryUser => {
  const upn = `${name.toLowerCase().replace(/[’']/g, '').replace(/\s+/g, '.')}@contoso.com`;
  return { id: `00000000-0000-4000-a000-${String(n).padStart(12, '0')}`, upn, displayName: name };
};

/** The fixture tenant (fictional Contoso). */
export function seedWorld(): MockWorld {
  const users = ['Priya Natarajan', 'Liam O’Connor', 'Mei Chen', 'Arjun Mehta', 'Sofia Rossi', 'Noah Williams', 'Aisha Khan', 'Lucas Martin', 'Emma Brown', 'Kenji Sato']
    .map((n, i) => person(i + 1, n));
  const subscriptions = [
    { id: '0b7c2f4e-1d3a-4c5b-9e21-7a6f3c1d91e2', name: 'Contoso Dev' },
    { id: '5e21a9b0-6c4d-4f7e-8a12-3b9d0e4fa07f', name: 'Contoso Shared Services' },
    { id: '9a0d7c13-2b8e-4d61-b5f3-0c7e8a2d4b16', name: 'Contoso Prod' },
  ];
  return {
    users, subscriptions, groups: [], apps: [], sps: [],
    rgs: [{ subId: subscriptions[0].id, name: 'rg-payapi-dev-aue', location: 'australiaeast', tags: { app: 'payapi', env: 'dev' } }],
    assignments: [],
    projects: [{ id: 'a1b2c3d4-0000-4000-8000-0000000000a1', name: 'Payments API', readers: users.slice(0, 4).map((u) => u.upn), endpoints: [] }],
    operations: [],
    entitlements: users.slice(0, 6).map((u, i) => ({ upn: u.upn, id: `ent-${i + 1}`, license: 'express' })),
  };
}

export interface MockOptions {
  world?: MockWorld;
  /** simulated latency per call (ms) */
  latencyMs?: number;
  /** how long a new group / service principal is invisible to Azure RBAC (PrincipalNotFound) */
  consistencyMs?: number;
  /** how many polls an ADO project-creation operation stays inProgress */
  operationPolls?: number;
  now?: () => number;
  /** called after every write, e.g. to persist the world */
  onChange?: (w: MockWorld) => void;
  /** every call, for tests and the run log ("GET /groups … (mock)") */
  onCall?: (api: string, op: string) => void;
}

export function createMockProviders(opts: MockOptions = {}): Providers & { world: MockWorld } {
  const w = opts.world ?? seedWorld();
  const now = opts.now ?? Date.now;
  const latency = opts.latencyMs ?? 0;
  const consistency = opts.consistencyMs ?? 0;
  const polls = opts.operationPolls ?? 1;
  const call = async (api: string, op: string) => {
    opts.onCall?.(api, op);
    if (latency > 0) await new Promise((r) => setTimeout(r, latency));
  };
  const changed = () => opts.onChange?.(w);
  const lc = (s: string) => s.toLowerCase();

  const graph: GraphProvider = {
    async findUser(upn) { await call('graph', `GET /users/${upn}`); return w.users.find((u) => lc(u.upn) === lc(upn)) ?? null; },
    async searchUsers(q) {
      await call('graph', 'GET /users?$search');
      const s = lc(q.trim());
      return s ? w.users.filter((u) => lc(u.upn).includes(s) || lc(u.displayName).includes(s)).slice(0, 10) : w.users.slice(0, 10);
    },
    async findGroup(nick) { await call('graph', `GET /groups?$filter=mailNickname eq '${nick}'`); const g = w.groups.find((x) => lc(x.mailNickname) === lc(nick)); return g ? { id: g.id } : null; },
    async createGroup(g) {
      await call('graph', 'POST /groups');
      if (w.groups.some((x) => lc(x.mailNickname) === lc(g.mailNickname))) throw new ProviderError('Conflict', `A group with mailNickname ${g.mailNickname} already exists`, { status: 400 });
      const id = randomUUID();
      w.groups.push({ id, displayName: g.displayName, mailNickname: g.mailNickname, members: [], createdAt: now() });
      changed();
      return { id };
    },
    async listMemberIds(groupId) { await call('graph', `GET /groups/${groupId}/members`); return [...(w.groups.find((g) => g.id === groupId)?.members ?? [])]; },
    async addMember(groupId, userId) {
      await call('graph', `POST /groups/${groupId}/members/$ref`);
      const g = w.groups.find((x) => x.id === groupId);
      if (!g) throw new ProviderError('NotFound', 'Group not found', { status: 404 });
      if (g.members.includes(userId)) throw new ProviderError('Conflict', 'One or more added object references already exist', { status: 400 });
      g.members.push(userId);
      changed();
    },
    async findApplication(name) { await call('graph', `GET /applications?$filter=displayName eq '${name}'`); const a = w.apps.find((x) => x.displayName === name); return a ? { id: a.id, appId: a.appId } : null; },
    async createApplication(name) {
      await call('graph', 'POST /applications');
      const a = { id: randomUUID(), appId: randomUUID(), displayName: name, fics: [] };
      w.apps.push(a);
      changed();
      return { id: a.id, appId: a.appId };
    },
    async findServicePrincipal(appId) { await call('graph', `GET /servicePrincipals?$filter=appId eq '${appId}'`); const s = w.sps.find((x) => x.appId === appId); return s ? { id: s.id } : null; },
    async createServicePrincipal(appId) {
      await call('graph', 'POST /servicePrincipals');
      const s = { id: randomUUID(), appId, createdAt: now() };
      w.sps.push(s);
      changed();
      return { id: s.id };
    },
    async listFederatedCredentials(appObjectId) { await call('graph', `GET /applications/${appObjectId}/federatedIdentityCredentials`); return [...(w.apps.find((a) => a.id === appObjectId)?.fics ?? [])]; },
    async addFederatedCredential(appObjectId, fic) {
      await call('graph', `POST /applications/${appObjectId}/federatedIdentityCredentials`);
      const a = w.apps.find((x) => x.id === appObjectId);
      if (!a) throw new ProviderError('NotFound', 'Application not found', { status: 404 });
      a.fics.push(fic);
      changed();
    },
  };

  const principalCreatedAt = (id: string) => w.groups.find((g) => g.id === id)?.createdAt ?? w.sps.find((s) => s.id === id)?.createdAt;
  const arm: ArmProvider = {
    async listSubscriptions() { await call('arm', 'GET /subscriptions'); return w.subscriptions.map((s) => ({ ...s })); },
    async resourceGroupExists(subId, name) { await call('arm', `HEAD /subscriptions/${subId}/resourcegroups/${name}`); return w.rgs.some((r) => r.subId === subId && lc(r.name) === lc(name)); },
    async createResourceGroup(subId, name, location, tags) {
      await call('arm', `PUT /subscriptions/${subId}/resourcegroups/${name}`);
      if (!w.subscriptions.some((s) => s.id === subId)) throw new ProviderError('SubscriptionNotFound', 'Subscription not found', { status: 404 });
      const r = w.rgs.find((x) => x.subId === subId && lc(x.name) === lc(name));
      if (r) r.tags = { ...r.tags, ...tags }; else w.rgs.push({ subId, name, location, tags });
      changed();
    },
    async resolveRole(subId, nameOrId) {
      await call('arm', `GET /subscriptions/${subId}/providers/Microsoft.Authorization/roleDefinitions`);
      const id = /^[0-9a-f-]{36}$/i.test(nameOrId) ? lc(nameOrId) : ROLES[lc(nameOrId)];
      if (!id) throw new ProviderError('RoleNotFound', `No role definition named "${nameOrId}"`, { status: 404 });
      return `/subscriptions/${subId}/providers/Microsoft.Authorization/roleDefinitions/${id}`;
    },
    async roleAssignmentExists(scope, name) { await call('arm', `GET ${scope}/providers/Microsoft.Authorization/roleAssignments/${name}`); return w.assignments.some((a) => a.scope === scope && a.name === name); },
    async createRoleAssignment(scope, name, roleDefinitionId, principalId) {
      await call('arm', `PUT ${scope}/providers/Microsoft.Authorization/roleAssignments/${name}`);
      const born = principalCreatedAt(principalId);
      if (born === undefined || now() - born < consistency) throw new ProviderError('PrincipalNotFound', `Principal ${principalId} does not exist in the directory (replication delay)`, { transient: true, status: 400 });
      const existing = w.assignments.find((a) => a.scope === scope && a.name === name);
      if (existing) throw new ProviderError('RoleAssignmentExists', 'The role assignment already exists.', { status: 409 });
      w.assignments.push({ scope, name, roleDefinitionId, principalId });
      changed();
    },
  };

  const ado: AdoProvider = {
    async getProject(name) { await call('ado', `GET _apis/projects/${name}`); const p = w.projects.find((x) => lc(x.name) === lc(name)); return p ? { id: p.id } : null; },
    async createProject(name) {
      await call('ado', 'POST _apis/projects');
      const op = { id: randomUUID(), name, polls: polls };
      w.operations.push(op);
      changed();
      return { operationId: op.id };
    },
    async getOperation(id) {
      await call('ado', `GET _apis/operations/${id}`);
      const op = w.operations.find((o) => o.id === id);
      if (!op) throw new ProviderError('NotFound', 'Operation not found', { status: 404 });
      if (op.polls > 0) { op.polls--; changed(); return { status: 'inProgress' }; }
      if (!op.projectId) {
        const p = w.projects.find((x) => lc(x.name) === lc(op.name)) ?? { id: randomUUID(), name: op.name, readers: [], endpoints: [] };
        if (!w.projects.includes(p)) w.projects.push(p);
        op.projectId = p.id;
        changed();
      }
      return { status: 'succeeded', projectId: op.projectId };
    },
    async findEntitlement(upn) { await call('ado', 'GET _apis/userentitlements'); const e = w.entitlements.find((x) => lc(x.upn) === lc(upn)); return e ? { id: e.id, license: e.license } : null; },
    async isProjectReader(projectId, upn) { await call('ado', 'GET _apis/graph/memberships (Readers)'); return !!w.projects.find((p) => p.id === projectId)?.readers.some((r) => lc(r) === lc(upn)); },
    async addEntitlement(upn, projectId) {
      await call('ado', 'POST _apis/userentitlements (Basic, projectReader)');
      const p = w.projects.find((x) => x.id === projectId);
      if (!p) throw new ProviderError('NotFound', 'Project not found', { status: 404 });
      if (!w.entitlements.some((e) => lc(e.upn) === lc(upn))) w.entitlements.push({ upn, id: `ent-${w.entitlements.length + 1}`, license: 'express' });
      if (!p.readers.some((r) => lc(r) === lc(upn))) p.readers.push(upn);
      changed();
    },
    async addProjectReader(projectId, upn) {
      await call('ado', 'PUT _apis/graph/memberships (Readers)');
      const p = w.projects.find((x) => x.id === projectId);
      if (!p) throw new ProviderError('NotFound', 'Project not found', { status: 404 });
      if (!p.readers.some((r) => lc(r) === lc(upn))) p.readers.push(upn);
      changed();
    },
    async findEndpoint(projectId, name) {
      await call('ado', `GET _apis/serviceendpoint/endpoints?endpointNames=${name}`);
      const e = w.projects.find((p) => p.id === projectId)?.endpoints.find((x) => x.name === name);
      return e ? { id: e.id, issuer: e.issuer, subject: e.subject } : null;
    },
    async createEndpoint(projectId, e) {
      await call('ado', 'POST _apis/serviceendpoint/endpoints (AzureRM, WorkloadIdentityFederation)');
      const p = w.projects.find((x) => x.id === projectId);
      if (!p) throw new ProviderError('NotFound', 'Project not found', { status: 404 });
      const ep = { id: randomUUID(), name: e.name, issuer: `https://vstoken.dev.azure.com/${projectId.slice(0, 8)}`, subject: `sc://contoso/${p.name}/${e.name}` };
      p.endpoints.push(ep);
      changed();
      return { id: ep.id, issuer: ep.issuer, subject: ep.subject };
    },
  };
  return { kind: 'mock', graph, arm, ado, world: w };
}

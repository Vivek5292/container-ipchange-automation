/**
 * Provider interfaces for onboarding: the only way the step engine talks to Microsoft Graph, Azure Resource Manager
 * and Azure DevOps. Two implementations: ./mock.ts (in-memory, fixture-backed, the only one enabled) and ./real.ts
 * (stubs, disabled: every call throws). Each method maps to one documented REST call (see docs/onboarding-proposal).
 */

export interface DirectoryUser { id: string; upn: string; displayName: string }
export interface Subscription { id: string; name: string }

export interface GraphProvider {
  /** GET /users/{upn} */
  findUser(upn: string): Promise<DirectoryUser | null>;
  /** GET /users?$search (people picker) */
  searchUsers(q: string): Promise<DirectoryUser[]>;
  /** GET /groups?$filter=mailNickname eq '…' */
  findGroup(mailNickname: string): Promise<{ id: string } | null>;
  /** POST /groups */
  createGroup(g: { displayName: string; mailNickname: string; description: string }): Promise<{ id: string }>;
  /** GET /groups/{id}/members?$select=id */
  listMemberIds(groupId: string): Promise<string[]>;
  /** POST /groups/{id}/members/$ref */
  addMember(groupId: string, userId: string): Promise<void>;
  /** GET /applications?$filter=displayName eq '…' */
  findApplication(displayName: string): Promise<{ id: string; appId: string } | null>;
  /** POST /applications */
  createApplication(displayName: string): Promise<{ id: string; appId: string }>;
  /** GET /servicePrincipals?$filter=appId eq '…' */
  findServicePrincipal(appId: string): Promise<{ id: string } | null>;
  /** POST /servicePrincipals */
  createServicePrincipal(appId: string): Promise<{ id: string }>;
  /** GET /applications/{id}/federatedIdentityCredentials */
  listFederatedCredentials(appObjectId: string): Promise<{ name: string; issuer: string; subject: string }[]>;
  /** POST /applications/{id}/federatedIdentityCredentials */
  addFederatedCredential(appObjectId: string, fic: { name: string; issuer: string; subject: string }): Promise<void>;
}

export interface ArmProvider {
  /** GET /subscriptions (only those the server identity can see) */
  listSubscriptions(): Promise<Subscription[]>;
  /** HEAD …/resourcegroups/{name} */
  resourceGroupExists(subId: string, name: string): Promise<boolean>;
  /** PUT …/resourcegroups/{name} */
  createResourceGroup(subId: string, name: string, location: string, tags: Record<string, string>): Promise<void>;
  /** GET …/roleDefinitions?$filter=roleName eq '…' (or by ID) → full role definition ID */
  resolveRole(subId: string, nameOrId: string): Promise<string>;
  /** GET {scope}/providers/Microsoft.Authorization/roleAssignments/{name} */
  roleAssignmentExists(scope: string, name: string): Promise<boolean>;
  /** PUT {scope}/providers/Microsoft.Authorization/roleAssignments/{name}; may throw ProviderError code PrincipalNotFound */
  createRoleAssignment(scope: string, name: string, roleDefinitionId: string, principalId: string, principalType: 'Group' | 'ServicePrincipal'): Promise<void>;
}

export interface AdoProvider {
  /** GET _apis/projects/{name} */
  getProject(name: string): Promise<{ id: string } | null>;
  /** POST _apis/projects → operation */
  createProject(name: string, description: string): Promise<{ operationId: string }>;
  /** GET _apis/operations/{id} */
  getOperation(id: string): Promise<{ status: 'inProgress' | 'succeeded' | 'failed'; projectId?: string }>;
  /** GET userentitlements (search by UPN) */
  findEntitlement(upn: string): Promise<{ id: string; license: string } | null>;
  /** memberships check: is the user in [Project]\Readers */
  isProjectReader(projectId: string, upn: string): Promise<boolean>;
  /** POST userentitlements { accessLevel: { accountLicenseType: "express" }, projectEntitlements: [{ group: { groupType: "projectReader" } }] } */
  addEntitlement(upn: string, projectId: string): Promise<void>;
  /** memberships add (user already licensed): add to [Project]\Readers */
  addProjectReader(projectId: string, upn: string): Promise<void>;
  /** GET _apis/serviceendpoint/endpoints?endpointNames=… */
  findEndpoint(projectId: string, name: string): Promise<{ id: string; issuer: string; subject: string } | null>;
  /** POST _apis/serviceendpoint/endpoints (AzureRM, WorkloadIdentityFederation) */
  createEndpoint(projectId: string, e: { name: string; subscriptionId: string; subscriptionName: string; scope: string; appId: string; tenantId: string }): Promise<{ id: string; issuer: string; subject: string }>;
}

export interface Providers { kind: 'mock' | 'real'; graph: GraphProvider; arm: ArmProvider; ado: AdoProvider }

/** A provider failure with a stable code. `transient` errors are retried by the engine with backoff. */
export class ProviderError extends Error {
  code: string;
  transient: boolean;
  status: number;
  constructor(code: string, message: string, opts: { transient?: boolean; status?: number } = {}) {
    super(message);
    this.name = 'ProviderError';
    this.code = code;
    this.transient = !!opts.transient;
    this.status = opts.status ?? 500;
  }
}

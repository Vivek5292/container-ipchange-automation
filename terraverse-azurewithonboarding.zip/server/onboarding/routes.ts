/**
 * /api/onboarding/* — the onboarding API (mock providers only; see ./providers.ts). Every route needs the signed session
 * cookie (../session.ts); roles come from the users file on each request, so "approver" is enforced here, not in the
 * browser. Records live in ONBOARDING_DATA_DIR (default data/onboarding). Runs execute in-process; the browser polls
 * GET /requests/:id for live step status and logs.
 *
 *   GET  config                 public settings (never the PAT)
 *   GET  me                     public: whether the session cookie is valid, approver flag, pending count (start page)
 *   GET  subscriptions          subscriptions the onboarding identity can see
 *   GET  directory?q=           people picker
 *   POST plan                   validate + read-only plan (nothing is written)
 *   POST requests               submit a request (pending approval)
 *   GET  requests               list (approvers see all, others their own)
 *   GET  requests/:id           one record with steps and logs
 *   POST requests/:id/approve   approver only
 *   POST requests/:id/reject    approver only, reason required
 *   POST requests/:id/run       requester or approver, once approved
 *   POST requests/:id/retry     resume a failed run at the failed step
 */
import { existsSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import type { IncomingMessage, ServerResponse } from 'node:http';
import { readUsers } from '../auth.ts';
import type { Sessions } from '../session.ts';
import { publicOnboardingConfig, readOnboardingConfig, type OnboardingConfig } from './config.ts';
import { planRequest, runRecord } from './engine.ts';
import { createMockProviders, seedWorld, type MockWorld } from './mock.ts';
import { deriveNames, stepList, validateInput, type OnbInput, type OnbRecord, type Person } from './model.ts';
import { ProviderError, type Providers } from './providers.ts';
import { createRealProviders } from './real.ts';
import { createStore, writeJsonAtomic, type Store } from './store.ts';

type Env = Record<string, string | undefined>;
type Json = (res: ServerResponse, status: number, body: unknown) => void;
type ReadJson = (req: IncomingMessage, res: ServerResponse) => Promise<Record<string, unknown> | null>;
interface Me extends Person { roles: string[] }

const num = (v: string | undefined, d: number) => (v !== undefined && v !== '' && Number.isFinite(Number(v)) ? Number(v) : d);

export function createOnboardingApi(o: { env: Env; root: string; usersFile: string; sessions: Sessions; log: (l: string) => void; json: Json; readJson: ReadJson }) {
  const { env, json, log } = o;
  let state: { store: Store; providers: Providers; backoffMs: number[] } | null = null;
  const running = new Set<string>();

  const config = (): OnboardingConfig => readOnboardingConfig(env.ONBOARDING_CONFIG ?? join(o.root, 'config', 'onboarding.json'), env);

  /** lazy: nothing touches the disk until the first onboarding call */
  function init() {
    if (state) return state;
    const store = createStore(env.ONBOARDING_DATA_DIR ?? join(o.root, 'data', 'onboarding'));
    const worldFile = join(store.dir, 'mock-world.json');
    let world: MockWorld = seedWorld();
    if (existsSync(worldFile)) { try { world = JSON.parse(readFileSync(worldFile, 'utf8')) as MockWorld; } catch { log('onboarding: mock world unreadable, reseeded'); } }
    const providers: Providers = env.ONBOARDING_PROVIDERS === 'real' ? createRealProviders() : createMockProviders({
      world, latencyMs: num(env.ONBOARDING_MOCK_LATENCY_MS, 250), consistencyMs: num(env.ONBOARDING_MOCK_CONSISTENCY_MS, 3000),
      operationPolls: num(env.ONBOARDING_MOCK_OPERATION_POLLS, 2), onChange: (w) => writeJsonAtomic(worldFile, w),
    });
    const backoffMs = (env.ONBOARDING_BACKOFF_MS ?? '800,1600,3200,3200,3200').split(',').map((x) => num(x.trim(), 0));
    // a run cut short by a restart: mark it failed so Retry resumes it
    for (const r of store.list()) {
      if (r.status !== 'running') continue;
      r.status = 'failed';
      for (const s of r.steps) if (s.state === 'running') { s.state = 'failed'; s.error = 'Interrupted by a server restart; Retry resumes here'; s.log.push(`✗ ${s.error}`); }
      r.history.push({ at: new Date().toISOString(), event: 'interrupted by a server restart' });
      store.save(r);
    }
    state = { store, providers, backoffMs };
    return state;
  }

  function me(req: IncomingMessage): Me | null {
    const username = o.sessions.fromRequest(req);
    if (!username) return null;
    const rec = readUsers(o.usersFile)?.find((u) => u.username.toLowerCase() === username.toLowerCase());
    return rec ? { username: rec.username, displayName: rec.displayName || rec.username, roles: Array.isArray(rec.roles) ? rec.roles : [] } : null;
  }
  const isApprover = (u: Me) => u.roles.includes('approver');
  const canSee = (u: Me, r: OnbRecord) => isApprover(u) || r.requestedBy.username.toLowerCase() === u.username.toLowerCase();
  const summary = (r: OnbRecord) => ({
    id: r.id, status: r.status, app: r.input.app, code: r.input.code, env: r.input.env, names: r.names, subscriptions: r.subscriptions,
    requestedBy: r.requestedBy, createdAt: r.createdAt, updatedAt: r.updatedAt, approval: r.approval,
    progress: { done: r.steps.filter((s) => s.state === 'done').length, total: r.steps.length }, members: r.input.members.length,
  });

  async function draft(input: OnbInput, cfg: OnboardingConfig, providers: Providers) {
    const all = await providers.arm.listSubscriptions();
    const subs = all.filter((s) => input.subscriptionIds.includes(s.id.toLowerCase()));
    if (subs.length !== input.subscriptionIds.length) return { fields: { subscriptionIds: 'Unknown subscription' } };
    const names = deriveNames(input, subs);
    const base = { input, names, subscriptions: subs, serviceConnectionRole: cfg.serviceConnectionRole };
    return { base, plan: await planRequest(base, providers), steps: stepList(names, subs, input.members.length) };
  }

  function start(rec: OnbRecord, s: NonNullable<typeof state>) {
    running.add(rec.id);
    void runRecord(rec, { providers: s.providers, save: (r) => s.store.save(r), backoffMs: s.backoffMs })
      .then((r) => log(`onboarding: ${r.id} ${r.status}`))
      .catch((e: unknown) => log(`onboarding: ${rec.id} engine error (${e instanceof Error ? e.name : 'Error'})`))
      .finally(() => running.delete(rec.id));
  }

  /** true when the path was an onboarding route (answered) */
  async function handle(req: IncomingMessage, res: ServerResponse, path: string): Promise<boolean> {
    if (!path.startsWith('/api/onboarding/')) return false;
    const sub = path.slice('/api/onboarding/'.length);
    const get = req.method === 'GET';
    let cfg: OnboardingConfig;
    try { cfg = config(); } catch (e) { log(`onboarding: bad config (${(e as Error).message})`); json(res, 500, { error: 'Onboarding config is invalid' }); return true; }
    if (sub === 'config' && get) { json(res, 200, publicOnboardingConfig(cfg, env)); return true; }

    const u = me(req);
    if (sub === 'me' && get) {
      if (!u) { json(res, 200, { signedIn: false }); return true; }
      const pending = isApprover(u) ? init().store.list().filter((r) => r.status === 'pending').length : 0;
      json(res, 200, { signedIn: true, username: u.username, displayName: u.displayName, approver: isApprover(u), pending });
      return true;
    }
    if (!u) { json(res, 401, { error: 'Sign in again to use onboarding', code: 'signin' }); return true; }
    const s = init();
    const now = () => new Date().toISOString();
    try {
      if (sub === 'subscriptions' && get) { json(res, 200, { subscriptions: await s.providers.arm.listSubscriptions() }); return true; }
      if (sub === 'directory' && get) {
        const q = new URL(req.url ?? '/', 'http://x').searchParams.get('q')?.trim().slice(0, 64) ?? '';
        json(res, 200, { users: q.length < 1 ? [] : (await s.providers.graph.searchUsers(q)).slice(0, 8) });
        return true;
      }
      if (sub === 'plan' || (sub === 'requests' && !get)) {
        const body = await o.readJson(req, res);
        if (!body) return true;
        const v = validateInput(body.input ?? body, { allowInject: publicOnboardingConfig(cfg, env).allowFailureInjection });
        if (!v.input) { json(res, 400, { error: 'Some fields need attention', fields: v.fields }); return true; }
        const d = await draft(v.input, cfg, s.providers);
        if (!d.base) { json(res, 400, { error: 'Some fields need attention', fields: d.fields }); return true; }
        if (sub === 'plan') { json(res, 200, { names: d.base.names, subscriptions: d.base.subscriptions, serviceConnectionRole: cfg.serviceConnectionRole, plan: d.plan }); return true; }
        const t = now();
        const rec: OnbRecord = { id: s.store.nextId(), status: 'pending', ...d.base, requestedBy: { username: u.username, displayName: u.displayName },
          createdAt: t, updatedAt: t, plan: d.plan, steps: d.steps, injectConsumed: false, runs: 0, history: [{ at: t, event: 'submitted', by: u.displayName }] };
        s.store.save(rec);
        log(`onboarding: ${rec.id} submitted by ${u.username}`);
        json(res, 201, rec);
        return true;
      }
      if (sub === 'requests' && get) {
        json(res, 200, { me: { ...u, approver: isApprover(u) }, requests: s.store.list().filter((r) => canSee(u, r)).map(summary) });
        return true;
      }
      const m = /^requests\/(onb-\d{4,})(?:\/(approve|reject|run|retry))?$/.exec(sub);
      if (!m) { json(res, 404, { error: 'Not found' }); return true; }
      const rec = s.store.get(m[1]);
      if (!rec || !canSee(u, rec)) { json(res, 404, { error: 'No such request' }); return true; }
      const action = m[2];
      if (!action) { if (get) json(res, 200, { ...rec, live: running.has(rec.id) }); else json(res, 405, { error: 'Use GET' }); return true; }
      const body = await o.readJson(req, res);
      if (!body) return true;
      if (action === 'approve' || action === 'reject') {
        if (!isApprover(u)) { json(res, 403, { error: 'Only approvers can approve or reject requests' }); return true; }
        if (rec.status !== 'pending') { json(res, 409, { error: `Request is ${rec.status}, not pending` }); return true; }
        if (action === 'approve' && !cfg.allowSelfApproval && rec.requestedBy.username.toLowerCase() === u.username.toLowerCase()) { json(res, 403, { error: 'You cannot approve your own request' }); return true; }
        const reason = typeof body.reason === 'string' ? body.reason.trim().slice(0, 500) : '';
        if (action === 'reject' && reason.length < 3) { json(res, 400, { error: 'Give a reason', fields: { reason: 'Give a reason for the requester' } }); return true; }
        const t = now();
        rec.status = action === 'approve' ? 'approved' : 'rejected';
        rec.approval = { decision: rec.status, by: { username: u.username, displayName: u.displayName }, at: t, ...(reason ? { reason } : {}) };
        rec.history.push({ at: t, event: rec.status, by: u.displayName });
        rec.updatedAt = t;
        s.store.save(rec);
        log(`onboarding: ${rec.id} ${rec.status} by ${u.username}`);
        json(res, 200, rec);
        return true;
      }
      // run / retry
      if (!isApprover(u) && rec.requestedBy.username.toLowerCase() !== u.username.toLowerCase()) { json(res, 403, { error: 'Only the requester or an approver can run this' }); return true; }
      if (running.has(rec.id)) { json(res, 409, { error: 'Already running' }); return true; }
      const want = action === 'run' ? 'approved' : 'failed';
      if (rec.status !== want) { json(res, 409, { error: action === 'run' ? `Request is ${rec.status}; it must be approved first` : `Only a failed run can be retried (this one is ${rec.status})` }); return true; }
      start(rec, s);
      json(res, 202, { ...rec, live: true });
      return true;
    } catch (e) {
      if (e instanceof ProviderError) { json(res, e.status === 501 ? 501 : 502, { error: e.message, code: e.code }); return true; }
      throw e;
    }
  }

  return { handle, /** for tests: wait until no run is active */ idle: async () => { while (running.size) await new Promise((r) => setTimeout(r, 5)); } };
}

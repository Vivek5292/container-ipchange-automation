/**
 * The onboarding step engine. Every step checks first and creates only what is missing, so running a request twice
 * changes nothing the second time. Steps run in order; progress is saved after every step, so a crash, a failure or
 * a server restart resumes at the first step that is not done (Retry). Transient provider errors (e.g. Entra
 * replication: PrincipalNotFound) are retried with backoff. Nothing is ever deleted.
 */
import { REGIONS, uuidv5, type OnbRecord, type PlanItem, type StepState } from './model.ts';
import { ProviderError, type Providers } from './providers.ts';
import { MOCK_TENANT_ID } from './mock.ts';

export interface EngineDeps {
  providers: Providers;
  save: (rec: OnbRecord) => void;
  /** delays between retries of a transient error (ms); its length is the retry budget */
  backoffMs: number[];
  sleep?: (ms: number) => Promise<void>;
  /** max polls of the ADO project-creation operation */
  maxOperationPolls?: number;
  now?: () => Date;
}

const READER = 'Reader';
const tag = (p: Providers) => (p.kind === 'mock' ? ' (mock)' : '');
const rgScope = (subId: string, rg: string) => `/subscriptions/${subId}/resourceGroups/${rg}`;
const short = (id: string) => `${id.slice(0, 4)}…${id.slice(-4)}`;

/** Read-only plan: what a run would create, add or find already there. Never writes. */
export async function planRequest(rec: Pick<OnbRecord, 'input' | 'names' | 'subscriptions' | 'serviceConnectionRole'>, p: Providers): Promise<PlanItem[]> {
  const { input, names, subscriptions: subs } = rec;
  const out: PlanItem[] = [];
  const group = await p.graph.findGroup(names.group);
  out.push({ key: 'group', kind: 'group', title: 'Entra ID security group', target: names.group, action: group ? 'exists' : 'create',
    detail: group ? 'Group already exists; it is reused.' : `No group with mailNickname “${names.group}”; it will be created.` });
  const members = group ? await p.graph.listMemberIds(group.id) : [];
  const users = await Promise.all(input.members.map((m) => p.graph.findUser(m)));
  const unknown = input.members.filter((_, i) => !users[i]);
  const already = users.filter((u) => u && members.includes(u.id)).length;
  const add = input.members.length - already - unknown.length;
  out.push({ key: 'members', kind: 'members', title: 'Group members', target: `${input.members.length} people`, action: add > 0 || unknown.length ? 'add' : 'exists',
    detail: `${already} of ${input.members.length} already members; ${add} will be added.${unknown.length ? ` Not found in the directory: ${unknown.join(', ')}.` : ''}` });
  for (const sub of subs) {
    const has = await p.arm.resourceGroupExists(sub.id, names.rg);
    out.push({ key: `rg:${sub.id}`, kind: 'rg', title: 'Resource group', target: `${names.rg} · ${sub.name}`, action: has ? 'exists' : 'create',
      detail: has ? `Already exists in ${sub.name}; reused (tags merged).` : `Will be created in ${sub.name} (${REGIONS[input.region]?.label ?? input.region}).` });
  }
  for (const sub of subs) {
    let exists = false;
    if (group) {
      const roleId = await p.arm.resolveRole(sub.id, READER);
      exists = await p.arm.roleAssignmentExists(rgScope(sub.id, names.rg), uuidv5(`${rgScope(sub.id, names.rg)}|${roleId}|${group.id}`));
    }
    out.push({ key: `rbac:${sub.id}`, kind: 'rbac', title: 'Reader for the group', target: `${names.rg} · ${sub.name}`, action: exists ? 'exists' : 'create',
      detail: `Reader → ${names.group}. The assignment name is a deterministic GUID.` });
  }
  const project = await p.ado.getProject(names.project);
  let readers = 0;
  if (project) for (const m of input.members) if (await p.ado.isProjectReader(project.id, m)) readers++;
  const missing = input.members.length - readers;
  out.push({ key: 'project', kind: 'project', title: 'Azure DevOps project', target: names.project, action: !project ? 'create' : missing ? 'add' : 'exists',
    detail: !project ? 'Project will be created (private). Members join Readers with a Basic licence.'
      : `Project exists. ${readers} of ${input.members.length} people are in Readers; ${missing} will be added with a Basic licence.` });
  for (const sub of subs) {
    const name = names.connections[sub.id];
    const ep = project ? await p.ado.findEndpoint(project.id, name) : null;
    out.push({ key: `connection:${sub.id}`, kind: 'connection', title: 'ARM service connection', target: name, action: ep ? 'exists' : 'create',
      detail: `Workload identity federation · app registration with ${rec.serviceConnectionRole} on ${names.rg} (${sub.name}).` });
  }
  return out;
}

class InjectedFailure extends Error {}

/** Run (or resume) a request. Resolves when the record is completed or failed; the record is saved throughout. */
export async function runRecord(rec: OnbRecord, d: EngineDeps): Promise<OnbRecord> {
  const sleep = d.sleep ?? ((ms: number) => new Promise<void>((r) => setTimeout(r, ms)));
  const now = () => (d.now ?? (() => new Date()))().toISOString();
  const p = d.providers;
  const m = tag(p);
  rec.status = 'running';
  rec.runs++;
  rec.history.push({ at: now(), event: rec.runs === 1 ? 'run started' : `retry ${rec.runs - 1} started` });
  rec.updatedAt = now();
  d.save(rec);
  const out = (key: string, k: string) => rec.steps.find((s) => s.key === key)?.outputs[k] ?? '';

  /** retry transient provider errors with backoff; logs each retry */
  const withRetry = async <T>(st: StepState, what: string, fn: () => Promise<T>): Promise<T> => {
    for (let attempt = 0; ; attempt++) {
      try { return await fn(); } catch (e) {
        if (!(e instanceof ProviderError) || !e.transient || attempt >= d.backoffMs.length) throw e;
        const ms = d.backoffMs[attempt];
        st.log.push(`${what} → ${e.status} ${e.code}; retry ${attempt + 1}/${d.backoffMs.length} in ${ms >= 1000 ? `${ms / 1000}s` : `${ms}ms`}`);
        rec.updatedAt = now();
        d.save(rec);
        await sleep(ms);
      }
    }
  };

  /** append a log line and save, so the run screen shows each call as it happens */
  const say = (st: StepState, line: string) => { st.log.push(line); rec.updatedAt = now(); d.save(rec); };

  const steps: Record<StepState['kind'], (st: StepState) => Promise<StepState['result']>> = {
    async group(st) {
      const name = rec.names.group;
      const g = await p.graph.findGroup(name);
      say(st, `GET /groups?$filter=mailNickname eq '${name}' → ${g ? '1 result' : '0 results'}${m}`);
      if (g) { st.outputs.groupId = g.id; return 'exists'; }
      const c = await p.graph.createGroup({ displayName: name, mailNickname: name, description: `${rec.input.app} (${rec.input.env}) readers · onboarded by Terraverse ${rec.id}` });
      st.outputs.groupId = c.id;
      say(st, `POST /groups (securityEnabled, not mail-enabled) → 201 ${short(c.id)}${m}`);
      return 'created';
    },
    async members(st) {
      const groupId = out('group', 'groupId');
      const ids = await p.graph.listMemberIds(groupId);
      say(st, `GET /groups/${short(groupId)}/members → ${ids.length} member(s)${m}`);
      let added = 0;
      for (const upn of rec.input.members) {
        const u = await p.graph.findUser(upn);
        if (!u) throw new ProviderError('UserNotFound', `${upn} was not found in the directory`, { status: 404 });
        if (ids.includes(u.id)) { say(st, `skip ${upn} (already a member)`); continue; }
        try { await p.graph.addMember(groupId, u.id); added++; say(st, `POST /groups/${short(groupId)}/members/$ref ${upn} → 204${m}`); } catch (e) {
          if (e instanceof ProviderError && e.code === 'Conflict') { say(st, `skip ${upn} (added meanwhile)`); continue; }
          throw e;
        }
      }
      st.outputs.added = String(added);
      return added ? 'added' : 'exists';
    },
    async rg(st) {
      const sub = st.subId!;
      const name = rec.names.rg;
      const has = await p.arm.resourceGroupExists(sub, name);
      say(st, `HEAD /subscriptions/${short(sub)}/resourcegroups/${name} → ${has ? '204' : '404'}${m}`);
      if (has) return 'exists';
      const tags = { app: rec.input.code, env: rec.input.env, owner: rec.input.owner, ...(rec.input.costCentre ? { costCentre: rec.input.costCentre } : {}), onboardedBy: `terraverse:${rec.id}` };
      await p.arm.createResourceGroup(sub, name, rec.input.region, tags);
      say(st, `PUT /subscriptions/${short(sub)}/resourcegroups/${name} (${rec.input.region}) → 201${m}`);
      return 'created';
    },
    async rbac(st) {
      const sub = st.subId!;
      const scope = rgScope(sub, rec.names.rg);
      const groupId = out('group', 'groupId');
      const roleId = await p.arm.resolveRole(sub, READER);
      const name = uuidv5(`${scope}|${roleId}|${groupId}`);
      if (await p.arm.roleAssignmentExists(scope, name)) { say(st, `GET …/roleAssignments/${name} → 200 (exists)${m}`); return 'exists'; }
      say(st, `GET …/roleAssignments/${name} → 404${m}`);
      try {
        await withRetry(st, `PUT …/roleAssignments/${name.slice(0, 8)}… (Reader, principalType Group)`, () => p.arm.createRoleAssignment(scope, name, roleId, groupId, 'Group'));
      } catch (e) {
        if (e instanceof ProviderError && e.code === 'RoleAssignmentExists') { say(st, 'PUT → 409 RoleAssignmentExists (treated as done)'); return 'exists'; }
        throw e;
      }
      say(st, `PUT …/roleAssignments/${name.slice(0, 8)}… (Reader ${roleId.split('/').pop()!.slice(0, 8)}…) → 201${m}`);
      return 'created';
    },
    async project(st) {
      let proj = await p.ado.getProject(rec.names.project);
      say(st, `GET _apis/projects/${rec.names.project} → ${proj ? '200' : '404'}${m}`);
      let result: StepState['result'] = 'exists';
      if (!proj) {
        const { operationId } = await p.ado.createProject(rec.names.project, `${rec.input.app} · onboarded by Terraverse ${rec.id}`);
        say(st, `POST _apis/projects (private) → 202 operation ${short(operationId)}${m}`);
        const max = d.maxOperationPolls ?? 20;
        for (let i = 0; ; i++) {
          const op = await p.ado.getOperation(operationId);
          say(st, `GET _apis/operations/${short(operationId)} → ${op.status}${m}`);
          if (op.status === 'succeeded' && op.projectId) { proj = { id: op.projectId }; break; }
          if (op.status === 'failed') throw new ProviderError('ProjectCreateFailed', 'Azure DevOps could not create the project', { status: 500 });
          if (i >= max) throw new ProviderError('Timeout', 'Project creation did not finish in time; Retry checks again', { status: 504 });
          d.save(rec);
          await sleep(d.backoffMs[0] ?? 0);
        }
        result = 'created';
      }
      st.outputs.projectId = proj.id;
      let added = 0;
      for (const upn of rec.input.members) {
        if (await p.ado.isProjectReader(proj.id, upn)) { say(st, `skip ${upn} (already in Readers)`); continue; }
        const ent = await p.ado.findEntitlement(upn);
        if (ent) { await p.ado.addProjectReader(proj.id, upn); say(st, `PUT memberships ${upn} → [${rec.names.project}]\\Readers (keeps licence ${ent.license === 'express' ? 'Basic' : ent.license})${m}`); }
        else { await p.ado.addEntitlement(upn, proj.id); say(st, `POST userentitlements ${upn} (Basic, [${rec.names.project}]\\Readers) → 200${m}`); }
        added++;
      }
      return result === 'created' ? 'created' : added ? 'added' : 'exists';
    },
    async connection(st) {
      const sub = st.subId!;
      const subName = rec.subscriptions.find((x) => x.id === sub)?.name ?? sub;
      const name = rec.names.connections[sub];
      const projectId = out('project', 'projectId');
      const scope = rgScope(sub, rec.names.rg);
      let created = false;
      let app = await p.graph.findApplication(`${name}-app`);
      say(st, `GET /applications?$filter=displayName eq '${name}-app' → ${app ? '1' : '0'}${m}`);
      if (!app) { app = await p.graph.createApplication(`${name}-app`); created = true; say(st, `POST /applications → 201 appId ${short(app.appId)}${m}`); }
      let sp = await p.graph.findServicePrincipal(app.appId);
      if (!sp) { sp = await p.graph.createServicePrincipal(app.appId); created = true; say(st, `POST /servicePrincipals → 201 ${short(sp.id)}${m}`); }
      let ep = await p.ado.findEndpoint(projectId, name);
      say(st, `GET _apis/serviceendpoint/endpoints?endpointNames=${name} → ${ep ? '1' : '0'}${m}`);
      if (!ep) {
        ep = await p.ado.createEndpoint(projectId, { name, subscriptionId: sub, subscriptionName: subName, scope, appId: app.appId, tenantId: MOCK_TENANT_ID });
        created = true;
        say(st, `POST _apis/serviceendpoint/endpoints (AzureRM, WorkloadIdentityFederation, scope ${rec.names.rg}) → 200${m}`);
      }
      const fics = await p.graph.listFederatedCredentials(app.id);
      if (!fics.some((f) => f.subject === ep!.subject)) {
        await p.graph.addFederatedCredential(app.id, { name: `ado-${name}`, issuer: ep.issuer, subject: ep.subject });
        created = true;
        say(st, `POST /applications/${short(app.id)}/federatedIdentityCredentials (subject ${ep.subject}) → 201${m}`);
      }
      const roleId = await p.arm.resolveRole(sub, rec.serviceConnectionRole);
      const raName = uuidv5(`${scope}|${roleId}|${sp.id}`);
      if (!(await p.arm.roleAssignmentExists(scope, raName))) {
        try {
          await withRetry(st, `PUT …/roleAssignments/${raName.slice(0, 8)}… (${rec.serviceConnectionRole}, ServicePrincipal)`, () => p.arm.createRoleAssignment(scope, raName, roleId, sp!.id, 'ServicePrincipal'));
          created = true;
          say(st, `PUT …/roleAssignments/${raName.slice(0, 8)}… (${rec.serviceConnectionRole} for the app on ${rec.names.rg}) → 201${m}`);
        } catch (e) { if (!(e instanceof ProviderError && e.code === 'RoleAssignmentExists')) throw e; }
      }
      st.outputs.endpointId = ep.id;
      st.outputs.appId = app.appId;
      return created ? 'created' : 'exists';
    },
  };

  for (const st of rec.steps) {
    if (st.state === 'done') continue;
    st.state = 'running';
    st.attempts++;
    st.error = undefined;
    st.startedAt = now();
    if (st.attempts > 1) st.log.push(`— retry (attempt ${st.attempts}) —`);
    rec.updatedAt = now();
    d.save(rec);
    try {
      if (rec.input.inject === st.kind && !rec.injectConsumed) {
        rec.injectConsumed = true;
        throw new InjectedFailure(`Injected failure (demo): ${st.kind === 'rbac' ? 'PrincipalNotFound after 5 retries' : 'the service returned 503'}. Retry resumes here; finished steps are not repeated.`);
      }
      st.result = await steps[st.kind](st);
      st.state = 'done';
      st.finishedAt = now();
      if (st.result === 'exists') st.log.push('✓ no change: already in place');
    } catch (e) {
      st.state = 'failed';
      st.finishedAt = now();
      st.error = e instanceof ProviderError || e instanceof InjectedFailure ? e.message : 'Unexpected error (see server log)';
      st.log.push(`✗ ${st.error}`);
      rec.status = 'failed';
      rec.history.push({ at: now(), event: `failed at ${st.title} (${st.target})` });
      rec.updatedAt = now();
      d.save(rec);
      return rec;
    }
    rec.updatedAt = now();
    d.save(rec);
  }
  rec.status = 'completed';
  rec.history.push({ at: now(), event: 'completed' });
  rec.updatedAt = now();
  d.save(rec);
  return rec;
}

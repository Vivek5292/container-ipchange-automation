# Terraverse 2.0 on Azure App Service

This zip is the deployment package for an **Azure App Service Web App on Linux**. Deploy it as-is: it is pre-built
(`dist/`) and the server (`server.mjs`) has **no npm dependencies**, so nothing is installed or built on Azure.

| | |
|---|---|
| **Publish** | Code |
| **Operating system** | Linux |
| **Runtime stack** | **Node 24 LTS** (`NODE:24-lts`); Node 22.18+ also works |
| **Startup command** | `node server.mjs` |
| **Port** | none to configure: App Service sets `PORT` and the server listens on it. Do not add `PORT` or `WEBSITES_PORT`. |
| **Health check path** | `/healthz` |

Users reach it only over HTTPS 443 at `https://<app>.azurewebsites.net`. The full guide (hardening, Terraform,
GitHub Actions, Easy Auth, monitoring, rollback) is `docs/DEPLOY-AZURE.md` in the source repository.

## App settings

Portal: the web app > **Settings** > **Environment variables** > **App settings**.

| Name | Value | Needed |
|---|---|---|
| `SCM_DO_BUILD_DURING_DEPLOYMENT` | `false` | yes: the zip is pre-built, skip the Oryx build |
| `NODE_ENV` | `production` | recommended |
| `ADO_TENANT_ID` | Entra tenant ID of the Azure DevOps service principal | for pull requests from app settings |
| `ADO_CLIENT_ID` | its application (client) ID | " |
| `ADO_CLIENT_SECRET` | a **Key Vault reference**, e.g. `@Microsoft.KeyVault(SecretUri=https://<vault>.vault.azure.net/secrets/ado-client-secret/)` | " |

When all three `ADO_*` settings are set, the "Create pull request" dialog hides the Tenant ID, Client ID and Client
secret fields and the server uses these (anything a browser sends is ignored). Without them, users type the
credentials in the dialog for each request; the secret is sent once to this server over HTTPS and never stored or
logged. App Service resolves the Key Vault reference into the environment at start-up: give the web app a
system-assigned managed identity and the **Key Vault Secrets User** role on the vault:

```bash
az webapp identity assign -g "$RG" -n "$APP"
PRINCIPAL=$(az webapp identity show -g "$RG" -n "$APP" --query principalId -o tsv)
az role assignment create --assignee "$PRINCIPAL" --role "Key Vault Secrets User" \
  --scope "$(az keyvault show -n "$KV" --query id -o tsv)"
az webapp config appsettings set -g "$RG" -n "$APP" --settings \
  SCM_DO_BUILD_DURING_DEPLOYMENT=false NODE_ENV=production \
  ADO_TENANT_ID=<tenant-guid> ADO_CLIENT_ID=<client-guid> \
  "ADO_CLIENT_SECRET=@Microsoft.KeyVault(SecretUri=https://$KV.vault.azure.net/secrets/ado-client-secret/)"
```

Outbound, the app must reach `https://login.microsoftonline.com` and `https://dev.azure.com` on 443 (plus
`*.vault.azure.net` for the Key Vault reference). The service principal needs *Contribute*, *Create branch* and
*Contribute to pull requests* on the target repository.

## Deploy with the Azure CLI (zip deploy)

```bash
az login
az account set --subscription "<subscription-id>"
RG=rg-terraverse-aue; PLAN=asp-terraverse-aue; APP=app-terraverse-$(openssl rand -hex 3); LOCATION=australiaeast

# first time only: resource group, Linux plan, web app on Node 24 LTS
az group create -n "$RG" -l "$LOCATION"
az appservice plan create -g "$RG" -n "$PLAN" -l "$LOCATION" --is-linux --sku B1
az webapp create -g "$RG" -p "$PLAN" -n "$APP" --runtime "NODE:24-lts" \
  --startup-file "node server.mjs" --https-only true --basic-auth Disabled
az webapp config set -g "$RG" -n "$APP" --min-tls-version 1.2 --ftps-state Disabled --always-on true \
  --startup-file "node server.mjs" --generic-configurations '{"healthCheckPath": "/healthz"}'
az webapp config appsettings set -g "$RG" -n "$APP" --settings SCM_DO_BUILD_DURING_DEPLOYMENT=false NODE_ENV=production

# every release: upload this zip
az webapp deploy -g "$RG" -n "$APP" --src-path terraverse-azure.zip --type zip --track-status true
az webapp browse -g "$RG" -n "$APP"
```

Check the runtime string with `az webapp list-runtimes --os linux` if `NODE:24-lts` is refused.

## Deploy from the Azure portal

1. **Create a resource** > **Web App**. Publish: **Code**; Runtime stack: **Node 24 LTS**; Operating System:
   **Linux**; pick a region and a plan (B1 or above for Always On). Create it.
2. The web app > **Settings** > **Configuration** > **General settings**: Startup Command `node server.mjs`,
   HTTPS Only **On**, Minimum TLS 1.2, FTP state **Disabled**, Always On **On**. Save.
3. **Environment variables** > **App settings**: add the settings from the table above (at least
   `SCM_DO_BUILD_DURING_DEPLOYMENT=false`). Apply.
4. Upload the zip. Either:
   - **Advanced Tools** > **Go** (Kudu) > **Tools** > **Zip Push Deploy**, then drag `terraverse-azure.zip` onto the
     `/home/site/wwwroot` drop area; or
   - **Deployment Center** is for source control and CI (GitHub Actions, Azure Repos); for a one-off zip use Kudu
     above or the CLI command.
5. **Overview** > **Browse**. Health: **Monitoring** > **Health check** with path `/healthz`.

## Sign in and users

Users come from **`config/users.json`** in this package (salted PBKDF2 hashes only, never passwords); the server
checks them (`POST /api/auth/login`) and re-reads the file on every sign-in. To add or change a user, before
deploying:

```bash
node scripts/hash-password.mjs --add alice "Alice Example"     # type the password; writes config/users.json
```

then re-zip the folder (zip its contents, not the folder) and deploy again. Or edit `/home/site/wwwroot/config/users.json`
in Kudu (it is replaced by the next deployment). The login screen is a gate, not strong security: for real
protection turn on **Authentication** (Easy Auth) with Microsoft Entra ID in front of the app.

## What is in the zip

`server.mjs` and `server/` (static files, `/healthz`, `/api/auth/login`, `/api/ado/config`, `/api/ado/pr`),
`dist/` (the app), `config/users.json`, `scripts/hash-password.mjs`, `package.json` (`"start": "node server.mjs"`),
this file. No `node_modules`, no source, no `.env`, no secrets.
